/*
 *Interfaz para los objetos acci�n, que ejecutar�n las acciones en las que se divide un servlet
 *de control de la p�gina
 */
package bibtex;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Manuel Monge Mart�nez
 *
 */
public abstract class Accion {
    
    

    
    
    public Accion()
    {
        super();

    }
    
    
    
    /**
     * M�todo que contendr� la secuencia de instrucciones de ejecuci�n de la acci�n asociada. 
     * 
     * @param servlet
     * @param request
     * @param response
     * @throws IOException
     * @throws ServletException
     * @throws Exception
     * @throws SQLException
     */
    public abstract void ejecutar(HttpServlet servlet, HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException;
    
    
    
    /*
     *M�todo que env�a la redirecci�n a otra p�gina
     */
    protected void forward(String pagina, HttpServletRequest request,
        HttpServletResponse response, HttpServlet servlet) throws ServletException, IOException
    {
            RequestDispatcher rd=servlet.getServletContext().getRequestDispatcher(pagina);
            rd.forward(request,response);
    }
   
}
