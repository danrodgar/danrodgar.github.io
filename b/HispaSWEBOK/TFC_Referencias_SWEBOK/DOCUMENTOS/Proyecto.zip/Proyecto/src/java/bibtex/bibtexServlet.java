/*
 * bibtexServlet.java
 *
 * Created on 20 de enero de 2006, 16:40
 *
 * Servlet Principal por el que pasan todas las peticiones de p�ginas web
 */

package bibtex;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author Manuel Monge Mart�nez
 * @version
 *
 *
 * �nico Servlet de la aplicaci�n web que recoger� la acci�n correspondiente a ejecutar
 * en cada momento
 */
public class bibtexServlet extends HttpServlet {
    
    ContenedorAccionesPpal CAP;
    

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.close();
    }
    //Inicializaci�n del Servlet
    public void init(){
        //Carga del contenedor de acciones
	    this.CAP=new ContenedorAccionesPpal();
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        this.ejecutar(request,response);
    }
    

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        this.ejecutar(request,response);
    }
    /*
    *  M�todo que recoge el par�metro acci�n y segun sea este, recupera la Accion a ejecutar del Contenedor
    *  y llama al m�todo ejecutar de esta.
    */
    public void ejecutar(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
       
	    //Recogemos el par�metro accion
        String parametroAccion=request.getParameter("accion");

       
       if (parametroAccion != null) 
       {
           
           //Recogemos  el objeto accion
           Accion accion = this.CAP.getAccion(parametroAccion);
           
           //En el caso de que la acci�n sea nula
           if (accion==null)
           {
               response.getOutputStream().print("Error en la llamada a la acci�n!. La acci�n no existe");
           }
           else
           {
               //Llamada al m�todo ejecutar del objeto acci�n, pas�ndole las referencias necesarias
			   accion.ejecutar(this, request, response);
           }
       }
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
