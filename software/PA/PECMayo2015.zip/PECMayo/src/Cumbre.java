
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.Semaphore;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Cumbre extends UnicastRemoteObject implements InterfaceCumbre {
    ListaThreads lista;
    Semaphore caben = new Semaphore(1,true);
    boolean abierto=true;
    JLabel cartel;
    public Cumbre(JTextField jtf, JLabel cartel)throws RemoteException {
        lista=new ListaThreads(jtf);
        this.cartel=cartel;
    }
    public void meter(Escalador id){lista.meter(id);}
    public void sacar(Escalador id){lista.sacar(id);}
    
    public boolean alcanzar(Escalador id, CampoUno campoUno){
        if(abierto){
            try{ caben.acquire(); //Se espera hasta que haya un hueco
                } catch(InterruptedException e){}
            if(abierto){
                campoUno.abandonar(id); //Deja sitio en el campoUno
                this.meter(id);
                return true;  //Ha llegado a la cumbre!
            }
        }
        return false;
    }

    public void bajar(Escalador id, CampoBase campoBase){
        this.sacar(id);
        campoBase.meter(id);
        if(abierto) caben.release(); //Deja sitio a otro si está abierto
    }
    @Override
    public void abrirCumbre()throws RemoteException{
        abierto=true;
        cartel.setText("ASCENSO ABIERTO");
    }
    @Override
    public void cerrarCumbre()throws RemoteException{
        abierto=false;
        cartel.setText("ASCENSO CERRADO");
        while(caben.hasQueuedThreads())caben.release(); //dejamos marchar a los que esperan
        caben.drainPermits(); 
        caben.release(1);      //Y lo dejamos en 1 de capacidad
    }
            
}
