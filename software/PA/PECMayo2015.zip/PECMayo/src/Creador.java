
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Creador extends Thread{
    PicoK8 pk8;
    Escalador escalador;
    public Creador(PicoK8 pk8){
        this.pk8=pk8;
        start();
    }
    @Override
    public void run(){
        for(int i=1;i<=100;i++) new Escalador(i,pk8);
        try {
          Registry registry = LocateRegistry.createRegistry(1099); //Arranca rmiregistry local en el Puerto 1099
          Naming.rebind("//localhost/cumbre",pk8.cumbre); //rebind solo funciona sobre una url del equipo local
          System.out.println("El Objeto cumbre ha quedado registrado");
        } catch (Exception e) {
          System.out.println(" Error: " + e.getMessage());
          e.printStackTrace();
        }
    }
}
