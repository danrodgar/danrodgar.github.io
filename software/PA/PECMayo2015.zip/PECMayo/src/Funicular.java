
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Funicular extends Thread{
    private int totalViajeros=0;
    private int dentro=0;
    private boolean subiendo=true;
    private boolean puertaAbierta=true;
    JLabel sentido;
    Paso paso;
    ListaThreads lista;
    public Funicular(JTextField jtf, JLabel sentido, Paso paso){
        this.lista=new ListaThreads(jtf);
        this.sentido=sentido;
        this.paso=paso;
        start();
    }
    @Override
    public void run(){
        int tiempoParado=1000;
        int tiempoMarcha=1000;
        while(true){
            paso.mirar();
            llegaAbajo(); //El funicular llega abajo y abre la puerta
            try{sleep(tiempoParado);}catch(InterruptedException e){}
            enMarcha(); //Cierra la puerta para subir
            try{sleep(tiempoMarcha);}catch(InterruptedException e){}
            paso.mirar();
            llegaArriba(); //Abre la puerta para descender
            try{sleep(tiempoParado);}catch(InterruptedException e){}          
            enMarcha(); //Cierra la puerta para bajar
            try{sleep(tiempoMarcha);}catch(InterruptedException e){}
            //Cada vez que completa un ciclo, envía el totalViajeros
            //al servidor monitor por un nuevo socket
            enviaDatosAlServidor(totalViajeros);
        }
    }
    private synchronized void llegaAbajo(){
        sentido.setText("SUBIENDO");
        subiendo=true;
        puertaAbierta=true;
        dentro=0;    //Se vacía la cabina
        notifyAll(); //Despierta a los escaladores que esperan para montar
    }
    private synchronized void llegaArriba(){
        sentido.setText("BAJANDO");
        subiendo=false;
        puertaAbierta=true;
        dentro=0;    //Se vacía la cabina
        notifyAll(); //Despierta a los escaladores que esperan para montar
    }
    private synchronized void enMarcha(){
        puertaAbierta=false;
    }
    public synchronized void subir(Escalador id, Llano llano, CampoBase campoBase){
        //puedeMontar=(subiendo & puertaAbierta & dentro<4)
        while(!(subiendo & puertaAbierta & dentro<4)){
            try{wait();}catch(InterruptedException e){}
        }
        System.out.println(id+" Se ha montado en el funicular para subir");
        dentro++;        //Uno más dentro...
        llano.sacar(id);
        this.meter(id);
        totalViajeros++; //Se actualiza el número total de viajeros
        // Y ahora se espera hasta que el funicular llegue arriba y le eche
        try{wait();}catch(InterruptedException e){}
        this.sacar(id);
        campoBase.meter(id);
    }
    
    public synchronized void bajar(Escalador id, CampoBase campoBase, Llano llano){
        //puedeMontar=(!subiendo & puertaAbierta & dentro<4)
        while(!(!subiendo & puertaAbierta & dentro<4)) {
            try{wait();}catch(InterruptedException e){}
        }
        System.out.println(id+" Se ha montado en el funicular para bajar");
        dentro++;        //Uno más dentro...
        campoBase.sacar(id);
        this.meter(id);
        totalViajeros++; //Se actualiza el número total de viajeros
        // Y ahora se espera hasta que el funicular se detenga abajo
        try{wait();}catch(InterruptedException e){}
        this.sacar(id);
        llano.meter(id);
    }
    private void enviaDatosAlServidor(int total){
        try {
            Socket cliente=new Socket(InetAddress.getLocalHost(),5000);
            DataOutputStream salida=new DataOutputStream(cliente.getOutputStream());
            salida.writeUTF(""+total);
            cliente.close();
        } catch (IOException ex) {return;} //Si el servidor no escucha, no hacemos nada

    }
    public void meter(Escalador id){lista.meter(id);}
    public void sacar(Escalador id){lista.sacar(id);}

}
