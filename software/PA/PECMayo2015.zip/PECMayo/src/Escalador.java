
public class Escalador extends Thread{
    Llano llano;
    Funicular funicular;
    CampoBase campoBase;
    CampoUno campoUno;
    Cumbre cumbre;
    Paso paso;
    public Escalador(int id, PicoK8 pk8){
        super(""+id);
        llano=pk8.llano;
        funicular=pk8.funicular;
        campoBase=pk8.campoBase;
        campoUno=pk8.campoUno;
        cumbre=pk8.cumbre;
        paso=pk8.paso;
        start();       
    }
    @Override
    public void run(){
        llano.meter(this);
        esperar(100,400); //Espera en el llano
        paso.mirar();
        funicular.subir(this,llano,campoBase);
        esperar(300,600); //Espera en el campo base
        paso.mirar();
        campoUno.subir(this,campoBase);
        esperar(1000); //Espera en el campo uno
        paso.mirar();
        if(cumbre.alcanzar(this,campoUno)){
            esperar(1000,3000); //Espera en la cumbre
            paso.mirar();
            cumbre.bajar(this,campoBase);
        }
        else campoUno.bajar(this,campoBase);
        esperar(100,300); //Espera en el campo base
        paso.mirar();
        funicular.bajar(this,campoBase,llano);
        System.out.println("El escalador "+this+" ha finalizado su escalada");
    }
    private void esperar(long min, long max){
        long tiempo= (long) (min + (max-min) * Math.random());
        try{sleep(tiempo);}catch(InterruptedException e){}
    }
    private void esperar(long tiempo){
        try{sleep(tiempo);}catch(InterruptedException e){}
    }
}
