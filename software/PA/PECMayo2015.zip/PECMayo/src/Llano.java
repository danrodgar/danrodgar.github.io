
import javax.swing.JTextField;

public class Llano {
    ListaThreads lista;
    public Llano(JTextField jtf){
        lista=new ListaThreads(jtf);
    }
    public void meter(Escalador id){lista.meter(id);}
    public void sacar(Escalador id){lista.sacar(id);}
}
