import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceCumbre extends Remote {
   void abrirCumbre() throws RemoteException;
   void cerrarCumbre() throws RemoteException;    
}
