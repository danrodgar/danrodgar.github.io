
import javax.swing.JTextField;

public class CampoBase {
    ListaThreads lista;
    public CampoBase(JTextField jtf){
        lista=new ListaThreads(jtf);
    }
    public void meter(Escalador id){lista.meter(id);}
    public void sacar(Escalador id){lista.sacar(id);}
}
