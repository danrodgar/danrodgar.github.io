import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JTextField;
public class ServidorMonitor extends Thread{
    private JTextField jtf;
    public ServidorMonitor(JTextField jtf){
        this.jtf=jtf;
        start();
    }
    @Override
    public void run() {
        try {
            Socket conexion;
            DataInputStream  entrada;
            ServerSocket servidor= new ServerSocket(5000);
            while(true){
                conexion = servidor.accept();
                entrada = new DataInputStream(conexion.getInputStream());
                jtf.setText(entrada.readUTF());
                conexion.close();
            }
        }catch(Exception e){}
    }
}
