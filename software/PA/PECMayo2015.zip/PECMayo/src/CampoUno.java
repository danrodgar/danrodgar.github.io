
import java.util.concurrent.Semaphore;
import javax.swing.JTextField;

public class CampoUno {
    ListaThreads lista;
    Semaphore caben = new Semaphore(10,true);
    public CampoUno(JTextField jtf){
        lista=new ListaThreads(jtf);
    }
    public void meter(Escalador id){lista.meter(id);}
    public void sacar(Escalador id){lista.sacar(id);}
    
    public void subir(Escalador id, CampoBase campoBase) {
        System.out.println(id+" va a subir al campoUno");
        try{
            caben.acquire(); //Se espera hasta que haya un hueco
        } catch(InterruptedException e){}
        campoBase.sacar(id);
        this.meter(id);
    }
    public void abandonar(Escalador id){
        sacar(id);
        caben.release();
    }
    public void bajar(Escalador id, CampoBase campoBase) {
        this.sacar(id);
        campoBase.meter(id);
        caben.release(); //Deja su sitio libre
    }
}
