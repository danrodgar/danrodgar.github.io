/*
 * SoapAttributeEval.java
 *
 * Created on 17 de noviembre de 2003, 9:09
 */

package weka.attributeSelection;

import  java.util.*;

import  weka.core.*;

//import pruebas.utilesFich;

public class SoapAllAttributeEval 
  extends ASEvaluation
  implements AttributeEvaluator,
             OptionHandler {

    private static final long serialVersionUID = -5566628444311446488L;

  /** The training instances */
  private Instances m_trainInstances;

  /** The class index */
  private int m_classIndex;

  /** The number of classes if class is nominal */
  private int m_numClasses;

  /** The number of attributes */
  private int m_numAttribs;

  /** The number of instances */
  private int m_numInstances;

  /** Holds the weights that soap assigns to attributes */
  private double[] m_weights;
  
  private int m_formulaSoap;
    /** search directions */
  private static final int SOAP_REAL = 0;
  private static final int SOAP_ORIGINAL = 1;
  private static final int SOAP_CONS = 2;
  public static final Tag [] TAGS_SOAP = {
    new Tag(SOAP_REAL, "Real"),
    new Tag(SOAP_ORIGINAL, "Original"),
    new Tag(SOAP_CONS, "Consistencia"),
  };

  
    /** Creates a new instance of SoapAttributeEval */
    public SoapAllAttributeEval() {
    }
    
    /**
    * Returns a string describing this attribute evaluator
    * @return a description javaMLG.of the evaluator suitable for
    * displaying in the explorer/experimenter gui
    */
    public String globalInfo() {
        return "SoapAllAttributeEval :\n\nEvaluates the worth of an attribute by "
            +"ordenando los ejemplos y contando el n�mero de cambios.\n ";
    }
    
    /** Inicializa Soap con el evaluador de atributos
    *
    * @param data set of instances serving as training data 
    * @exception Exception if the evaluator has not been 
    * generated successfully
    */
    public void buildEvaluator (Instances data) throws Exception {
        m_trainInstances = data;
        m_classIndex = m_trainInstances.classIndex();
        m_numClasses = m_trainInstances.numClasses();
        m_numAttribs = m_trainInstances.numAttributes()-1;
        m_numInstances = m_trainInstances.numInstances();

        if (m_trainInstances.checkForStringAttributes()) 
          throw  new UnsupportedAttributeTypeException("Can't handle string attributes!");
        if (m_trainInstances.attribute(m_classIndex).isNumeric())
          throw  new Exception("Class must be nominal!");  
        
        m_weights = new double[m_numAttribs];
        for (int i = 0; i < m_weights.length; i++) {
            m_trainInstances.sort(i);
            if (m_trainInstances.attribute(i).type() == Attribute.NOMINAL)
                m_weights[i] = calcularCambiosPorAtributoNominal(i);
            else
                m_weights[i] = calcularCambiosPorAtributoMaximo(i);
//            System.out.println(m_trainInstances.attribute(i).name() + "-NCE: " + m_weights[i]);    
        }
        for (int i = 0; i < m_weights.length; i++)
            m_weights[i] = ( 1 - m_weights[i] / m_numInstances); 
    }
   
    /** Calcula el NCE a lo largo de la proyecci�n 
     * @param ind, �ndice del atributo a tratar
     * @return el n�mero de cambios m�ximo
     */
  public double calcularCambiosPorAtributoMaximo(int ind) {  
    
    int i; 
    double cambiosClase = -1.0;
    double claseAnterior = -1.0;

    for (i = 0 ; i < m_numInstances ; i++)
      if (m_trainInstances.instance(i).isMissing(ind)) {
        int numMis=0;
        for (; i < m_numInstances ; i++) 
            numMis++;
        cambiosClase += numMis;
      } else if (i < (m_numInstances-1)) {
        if (m_trainInstances.instance(i).value(ind) != m_trainInstances.instance(i+1).value(ind)) {
          if (claseAnterior != m_trainInstances.instance(i).classValue()) {
            cambiosClase++; 
            claseAnterior = m_trainInstances.instance(i).classValue();
          }
        }
        else { // m.o.s.
          int [] tablaTotalClases = new int[m_numClasses];
                
          while ((i < (m_numInstances-1)) && 
             (m_trainInstances.instance(i).value(ind) == m_trainInstances.instance(i+1).value(ind))) {
            tablaTotalClases[(int)m_trainInstances.instance(i).classValue()]++; //incrementa en uno esa clase
            i++;
          }
          tablaTotalClases[(int)m_trainInstances.instance(i).classValue()]++;
          // Sumar todos los elementos y restar el m�ximo
          int elemMaximo = Utils.maxIndex(tablaTotalClases);
          cambiosClase += cuentaCambios(tablaTotalClases);
          if (claseAnterior != -1) {
              if (tablaTotalClases[elemMaximo] !=
                    tablaTotalClases[(int)claseAnterior])
                cambiosClase++;       
          }
          else
                cambiosClase++;
          claseAnterior = elemMaximo;
        }
      }
      else
        if (claseAnterior != m_trainInstances.instance(i).classValue())
          cambiosClase++;
    return cambiosClase;           
  }    

  /** Calcula el NCE a lo largo de la proyecci�n 
     *
     * @param ind, �ndice del atributo a tratar
     * @return el n�mero de cambios m�ximo
     */
  public double calcularCambiosPorAtributoNominal(int ind) {  

    double cambiosClase = 0;

    int [] tablaTotalClases = new int[m_numClasses];
    tablaTotalClases[(int)m_trainInstances.instance(0).classValue()]++;
    for (int i = 1; i < m_numInstances; i++) {
        if (m_trainInstances.instance(i).value(ind) == m_trainInstances.instance(i-1).value(ind))
            tablaTotalClases[(int)m_trainInstances.instance(i).classValue()]++;
        else {
            cambiosClase += cuentaCambios(tablaTotalClases);   
            tablaTotalClases = new int[m_numClasses];
            if (m_trainInstances.instance(i).isMissing(ind)) {
                int numMis=0;
                for (; i < m_numInstances; i++) {
                    numMis++;
                }
                cambiosClase += numMis;
            }
            else
                tablaTotalClases[(int)m_trainInstances.instance(i).classValue()]++;
        }
    }
    if (!m_trainInstances.instance(m_numInstances-1).isMissing(ind))
            cambiosClase += cuentaCambios(tablaTotalClases); 
    return cambiosClase;           
  }

//  private int cuentaCambios(int [] tab) {
//        int numCambios=0;
//        // Sumar todos los elementos y restar el m�ximo
//        int elemMaximo = Utils.maxIndex(tab);
//        int suma = Utils.sum(tab);
//        int resto = suma - tab[elemMaximo];
//        if (tab[elemMaximo] > resto)
//            numCambios += (resto * 2);
//        else
//            numCambios += suma;                                        
//        
//        return(numCambios);
//    }

   /** Devuelve el n�mero de cambios de etiqueta en la tabla*/
    private double cuentaCambios(int [] tab) {
        double numCambios=0;
        int suma = Utils.sum(tab);
        int [] tabOrd = Utils.sort(tab);
        int elemMaximo = Utils.maxIndex(tab);
        int dif=0,cont=0;
        int i;       
        int resto = suma - tab[elemMaximo];

        switch (m_formulaSoap) {
            case 0:
                if (tab[elemMaximo] > resto)
                    numCambios = (resto * 2);
                else {
                    for (i=0; (i < tabOrd.length-2) && (tab[tabOrd[i]] == 0); i++ );
                    for (; i < tabOrd.length-1; i++,cont++)
                        dif += (tab[tabOrd[i+1]] - tab[tabOrd[i]]);
                    numCambios = (suma-(double)dif/cont);
                }
                break;
            case 1:
                if (tab[elemMaximo] > resto)
                    numCambios += (resto * 2);
                else
                    numCambios += suma - 1;                                        
                break;
            case 2:
                numCambios = suma-tab[elemMaximo]; // dif / 2
        }
        
        return (numCambios); // dif / 2
    }  

  /** Eval�a un atributo individual con Soap.
    * The actual work is done by buildEvaluator which evaluates all features.
    *
    * @param attribute the index of the attribute to be evaluated
    * @exception Exception if the attribute could not be evaluated
    */
    public double evaluateAttribute (int attribute)
        throws Exception {
        return  m_weights[attribute];
    }

  /**
   * Return a description of the ReliefF attribute evaluator.
   *
   * @return a description of the evaluator as a String.
   */
  public String toString () {
    StringBuffer text = new StringBuffer();

    if (m_trainInstances == null) {
      text.append("\tSoapAllAtributeEval feature evaluator no se ha construido");
    }
    else {
      text.append("\tSoapAllAtributeEval feature evaluator\nFormula: ");
      switch  (m_formulaSoap) {
          case 0: text.append("0. Real.");
              break;
          case 1: text.append("1. Original.");
              break;
          case 2: text.append("2. Consistencia.");
      }
    }

    text.append("\n");
    return  text.toString();
  }

  /** Para probar las distintas funciones de la clase */
 /*   public static void main(String[] args) {
        File f = utilesFich.dialogoAbrirBD();
        try {
            if (f != null) {
                Reader lectorBD = new FileReader(f);
                Instances datos = new Instances(lectorBD);
                datos.setClassIndex(datos.numAttributes()-1);
                
                SoapAllAttributeEval pru = new SoapAllAttributeEval();
                pru.buildEvaluator(datos);
                                   
                for (int i=0; i<datos.numAttributes()-1; i++)
                    System.out.println("Att. " + (i+1) + ": " 
                    + pru.evaluateAttribute(i));
            }
        } catch (Exception e) {System.err.println(e.toString());}                
    }
   */ 
    public String[] getOptions() {
        String[] options = new String[2];
        int current = 0;

        options[current++] = "-D";
        options[current++] = "" + m_formulaSoap;

    return  options;    
    }
    
    public Enumeration listOptions() {
        Vector newVector = new Vector(4);
    
        newVector.addElement(new Option("\tForma de contar las inconsistencias. (default = 0)."
				    , "D", 1
				    , "-D <0 = Real | 1 = Original " 
				    + "| 2 = Consistencia>"));
        return  newVector.elements();
    }
    
    public void setOptions(String[] options) throws Exception {
        String optionString;
        resetOptions();

        optionString = Utils.getOption('D', options);

        if (optionString.length() != 0) {
          setFormulaSoap(new SelectedTag(Integer.parseInt(optionString),
				   TAGS_SOAP));
        } else {
            setFormulaSoap(new SelectedTag(SOAP_REAL, TAGS_SOAP));
        }

    }
  private void resetOptions () {
    m_formulaSoap = SOAP_REAL;
  }    
  
  public String formulaSoapTipText() {
    return "Establece la formula para contar la inconsistencia.";
  }

  public void setFormulaSoap (SelectedTag d) {
    
    if (d.getTags() == TAGS_SOAP) {
      m_formulaSoap = d.getSelectedTag().getID();
    }
  }
  
  public SelectedTag getFormulaSoap () {

    return new SelectedTag(m_formulaSoap, TAGS_SOAP);
  }

  
}
