package weka.attributeSelection;

import  java.io.*;
import  java.util.*;
import  weka.core.*;

/** 
 * Class for evaluating a attribute ranking (given by a specified
 * evaluator) using a specified subset evaluator. <p>
 *
 * Valid options are: <p>
 *
 * -A <attribute/subset evaluator> <br>
 * Specify the attribute/subset evaluator to be used for generating the 
 * ranking. If a subset evaluator is specified then a forward selection
 * search is used to produce a ranked list of attributes.<p>
 *
 * @author Roberto Ruiz (rruiz@lsi.us.es)
 * @version $1.0 Resumen de las individuales$
 */
public class BIRSSearch extends ASSearch implements OptionHandler {
    private static final long serialVersionUID = 7885144179492975227L;

  /** does the data have a class */
  private boolean m_hasClass;
 
  /** holds the class index */
  private int m_classIndex;
 
  /** number of attributes in the data */
  private int m_numAttribs;

  /** the best subset found */
  private BitSet m_best_group;

  /** the attribute evaluator to use for generating the ranking */
  private ASEvaluation m_ASEval;

  /** the subset evaluator with which to evaluate the ranking */
  private ASEvaluation m_SubsetEval;

  /** the training instances */
  private Instances m_Instances;

  /** the merit of the best subset found */
  private double m_bestMerit;

  /** will hold the attribute ranking */
  private int [] m_Ranking;

  /** Determina el umbral para incorporar un nuevo att al subconj. */
  private double m_delta;
  
  /** Use a backwards search instead of a forwards one */
  protected boolean m_backward = false;
  
  /** Use a backwards search with each subset */
  protected boolean m_backEach = false;

  /** Use a backwards search with the final subset */
  protected boolean m_purge = false;

  /** Determina el porcentaje de ranking para formar subconjuntos */
  private int m_porc;

  /** if true, then ouput new best subsets as the search progresses */
  private boolean m_verbose;
  
  /** total number of subsets evaluated during a search */
  protected int m_totalEvals;

  /**
   * Returns a string describing this search method
   * @return a description of the search method suitable for
   * displaying in the explorer/experimenter gui
   */
  public String globalInfo() {
    return "RankSemiSearch : \n\n"
      +"Utiliza un evaluador/subEvaluador de atributos para evaluarlos "
      +"individualmente y elaborar un ranking,"
      +"Si se introduce un evaluador de subconjuntos genera una excepci�n. "
      +"Se eval�a el primer atributo con el evaluador de subconjuntos, "
      +"se eval�an los dos primeros, y se a�adir� si se mejora la evaluaci�n,"
      +"y as� sucesivamente se recorre la lista completa de atributos.\n";
  }

  public BIRSSearch() {
    resetOptions();
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String attributeEvaluatorTipText() {
    return "Medida de evaluaci�n para generar el ranking.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setAttributeEvaluator(ASEvaluation newEvaluator) {
    m_ASEval = newEvaluator;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public ASEvaluation getAttributeEvaluator() {
    return m_ASEval;
  }

  public String deltaTipText() {
    return "Valor que tendra que superar para a�adir un att.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setDelta(double val) {
    m_delta = val;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public double getDelta() {
    return m_delta;
  }

    public String porcTipText() {
    return "Valor que tendra que superar para a�adir un att.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setPorc(int val) {
    m_porc = val;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public int getPorc() {
    return m_porc;
  }

   /**
   * Set whether to search backwards instead of forwards
   *
   * @param back true to search backwards
   */
  public void setSearchBackwards(boolean back) {
    m_backward = back;
  }

  /**
   * Get whether to search backwards
   *
   * @return true if the search will proceed backwards
   */
  public boolean getSearchBackwards() {
    return m_backward;
  } 
  
   /**
   * Set whether to search backwards with the final subset
   *
   * @param back true to purge
   */
  public void setSearchPurge(boolean back) {
    m_purge = back;
  }

  /**
   * Get whether to search backwards with the final subset
   *
   * @return true if the purge will proceed
   */
  public boolean getSearchPurge() {
    return m_purge;
  } 

  public String purgeTipText() {
    return "Realizar una purga con el subconjunto final";    
  }  
  
   /**
   * Set whether to search backwards with the final subset
   *
   * @param back true to purge
   */
  public void setSearchBackEach(boolean back) {
    m_backEach = back;
  }

  /**
   * Get whether to search backwards with each subset
   *
   * @return true if the purge will proceed
   */
  public boolean getSearchBackEach() {
    return m_backEach;
  } 

  public String backEachTipText() {
    return "Realizar un backward con cada nuevo subconjunto incremental";    
  }  

  public String verboseTipText() {
    return "Muestra informaci�n del progreso.";
  }

  /**
   * set whether or not to output new best subsets as the search proceeds
   * @param v true if output is to be verbose
   */
  public void setVerbose(boolean v) {
    m_verbose = v;
  }

  /**
   * get whether or not output is verbose
   * @return true if output is set to verbose
   */
  public boolean getVerbose() {
    return m_verbose;
  }
  
   /**
   * Returns an enumeration describing the available options.
   * @return an enumeration of all the available options.
   **/
  public Enumeration listOptions () {
    Vector newVector = new Vector(4);
    newVector.addElement(new Option("\tUmbral para a�adir un nuevo att."
				    ,"-D", 0, "-D"));
    newVector.addElement(new Option("\tPorcentaje del ranking a tratar"
				    ,"-J", 0, "-J"));
    newVector.addElement(new Option("\tUse a backward search instead  of a"
				    +"\n\tforward one."
				    ,"-B", 0, "-B"));
    newVector.addElement(new Option("\tUse a backwards search with each subset."
				    ,"-E", 0, "-E"));
    newVector.addElement(new Option("\tse a backwards search with the final subset."
				    ,"-P", 0, "-P"));
    newVector.addElement(new Option("\tOutput subsets as the search progresses."
				    +"\n\t(default = false)."
				    , "V", 0
				    , "-V"));
    newVector.addElement(new Option("\tclass name of attribute evaluator to" 
			       + "\n\tuse for ranking. Place any" 
			       + "\n\tevaluator options LAST on the" 
			       + "\n\tcommand line following a \"--\"." 
			       + "\n\teg. -A weka.attributeSelection."
			       +"GainRatioAttributeEval ... " 
			       + "-- -M", "A", 1, "-A <attribute evaluator>"));

    if ((m_ASEval != null) && 
	(m_ASEval instanceof OptionHandler)) {
      newVector.addElement(new Option("", "", 0, "\nOptions specific to" 
				      + "evaluator " 
				      + m_ASEval.getClass().getName() 
				      + ":"));
      Enumeration enumera = ((OptionHandler)m_ASEval).listOptions();

      while (enumera.hasMoreElements()) {
        newVector.addElement(enumera.nextElement());
      }
    }

    return newVector.elements();
  }


  /**
   * Parses a given list of options.
   *
   * Valid options are:<p>
   *
   * -A <attribute evaluator> <br>
   *
   * @param options the list of options as an array of strings
   * @exception Exception if an option is not supported
   *
   **/
  public void setOptions (String[] options)
    throws Exception {
    String optionString;
    resetOptions();
    optionString = Utils.getOption('D', options);
    if (optionString.length() != 0) {
      Double temp;
      temp = Double.valueOf(optionString);
      setDelta(temp.doubleValue());
    }
    optionString = Utils.getOption('J', options);
    if (optionString.length() != 0) {
      Integer temp;
      temp = Integer.valueOf(optionString);
      setPorc(temp.intValue());
    }
   
    setSearchBackwards(Utils.getFlag('B', options));
    setSearchBackEach(Utils.getFlag('E', options));
    setSearchPurge(Utils.getFlag('P', options));
    setVerbose(Utils.getFlag('V',options));
    
    optionString = Utils.getOption('A', options);
    if (optionString.length() == 0) {
      throw  new Exception("An attribute evaluator  must be specified with" 
			   + "-A option");
    }

    setAttributeEvaluator(ASEvaluation.forName(optionString, 
				     Utils.partitionOptions(options)));
  }

  /**
   * Gets the current settings of WrapperSubsetEval.
   *
   * @return an array of strings suitable for passing to setOptions()
   */
  public String[] getOptions () {
    String[] evaluatorOptions = new String[0];

    if ((m_ASEval != null) && 
	(m_ASEval instanceof OptionHandler)) {
      evaluatorOptions = ((OptionHandler)m_ASEval).getOptions();
    }

    String[] options = new String[7 + evaluatorOptions.length];
    int current = 0;

    options[current++] = "-D";
    options[current++] = "" + getDelta();

    options[current++] = "-J";
    options[current++] = "" + getPorc();
    
    if (getSearchBackwards()) {
      options[current++] = "-B";
    }
    
    if (getSearchBackEach()) {
      options[current++] = "-E";
    }

    if (getSearchPurge()) {
      options[current++] = "-P";
    }

    if (m_verbose) {
      options[current++] = "-V";
    }
    
    if (getAttributeEvaluator() != null) {
      options[current++] = "-A";
      options[current++] = getAttributeEvaluator().getClass().getName();
    }

    options[current++] = "--";
    System.arraycopy(evaluatorOptions, 0, options, current, 
		     evaluatorOptions.length);
    current += evaluatorOptions.length;

    while (current < options.length) {
      options[current++] = "";
    }

    return  options;
  }

  /**
   * Reset the search method.
   */
  protected void resetOptions () {
    m_ASEval = new SoapAllAttributeEval();
    m_Ranking = null;
    m_delta = 0.0;  //modificado desde 1.0 al pasar de divsion a resta
    m_porc = 100;    
    m_backward = false;
    m_backEach= false;
    m_purge = false;
    m_verbose = false;
  }

  /**
   * Ranks attributes using the specified attribute evaluator and then
   * searches the ranking using the supplied subset evaluator.
   *
   * @param ASEvaluator the subset evaluator to guide the search
   * @param data the training instances.
   * @return an array (not necessarily ordered) of selected attribute indexes
   * @exception Exception if the search can't be completed
   */
  public int[] search (ASEvaluation ASEval, Instances data)
    throws Exception {
        
    if (!(ASEval instanceof SubsetEvaluator)) {
      throw  new Exception(ASEval.getClass().getName() 
			   + " is not a " 
			   + "Subset evaluator!");
    }
    m_totalEvals = 0;
    m_SubsetEval = ASEval;
    m_Instances = data;
    m_numAttribs = m_Instances.numAttributes();
    
    if (m_ASEval instanceof UnsupervisedAttributeEvaluator || 
	m_ASEval instanceof UnsupervisedSubsetEvaluator) {
      m_hasClass = false;
    }
    else {
      m_hasClass = true;
      m_classIndex = m_Instances.classIndex();
    }

    RankerAll ranker = new RankerAll();
    m_ASEval.buildEvaluator(m_Instances);
//    ((AttributeEvaluator)m_ASEval).buildEvaluator(m_Instances);

//  NOTA: se ha comentado estas líneas porque parece que en esta versión no
//        se reconoce. Modificar dejando sólo un evaluador, el de subconjunto.

//    if (m_ASEval instanceof AttributeTransformer) {
//    // get the transformed data a rebuild the subset evaluator
//	m_Instances = ((AttributeTransformer)m_ASEval).
//	  transformedData();
//	((SubsetEvaluator)m_SubsetEval).buildEvaluator(m_Instances);
//    }
    m_Ranking = ranker.search(m_ASEval, m_Instances);

    double best_merit = -Double.MAX_VALUE;
    double temp_merit;
    BitSet best_group=new BitSet(m_numAttribs);

    int linea=0;
    if (m_backward) {
        for (int j = 0; j < m_numAttribs-1; j++)
            best_group.set(j);
        best_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
        m_totalEvals++;
        if (m_verbose)
            System.out.println("L�nea: "+ (linea++) +" Con todos los atributos: " + best_merit);
        for (int i=m_Ranking.length-1;i>=0;i--) {
            best_group.clear(m_Ranking[i]);
            temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
            m_totalEvals++;
            if (m_verbose)
	       System.out.println("L�nea: "+ (linea++) +" Sin Att: "+(m_Ranking[i]+1)+" valor: "+temp_merit);
//            if (m_SubsetEval instanceof WrapperSubsetEval 
//                    || m_SubsetEval instanceof ClassifierSubsetEval)
//                temp_merit = 1 + temp_merit;           
            if ((temp_merit - best_merit) >= m_delta) {
                best_merit = temp_merit; //((temp_merit < best_merit) ? best_merit : temp_merit); //permite que empeore un poco, pero se mantenga el mejor anterior
		if (m_verbose) 
		   System.out.println("Mismo valor que l�nea: "+ (linea-1) +" New best subset ("
			+Utils.doubleToString(Math.abs(best_merit),8,5)
			+"): "+printSubset(best_group));            
            }
            else
                best_group.set(m_Ranking[i]);
        }
    } else {
        if (m_backEach) { // mejorar recorrido y explicar lo que hace en comentarios
            best_group.set(m_Ranking[0]);
            best_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group); 
            m_totalEvals++;
            if (m_verbose)
                    System.out.println("------------1� Evaluaci�n con el atributo ("
			+Utils.doubleToString(Math.abs(best_merit),8,5)
			+"): "+printSubset(best_group));      
            for (int i=1;i<m_Ranking.length;i++) {
                int suprimir = -1;
                best_group.set(m_Ranking[i]);
                temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
                m_totalEvals++;
                if (m_verbose)
                    System.out.println("1� Evaluaci�n local con el subconjunto ("
			+Utils.doubleToString(Math.abs(temp_merit),8,5)
			+"): "+printSubset(best_group));      
                if ((temp_merit - best_merit) > m_delta) {
                    best_merit = temp_merit;
                    suprimir = -2;
                }
                for (int j=0; j<m_numAttribs-1; j++) {
                    if (best_group.get(j) && (j != m_Ranking[i])) {
                        best_group.clear(j);
                        temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
                        m_totalEvals++;
                        if (m_verbose)
                            System.out.println("Evaluaci�n sin el atributo "+ (j+1) + "con el subconjunto ("
                        	+Utils.doubleToString(Math.abs(temp_merit),8,5)
                                +"): "+printSubset(best_group));      
                        if ((temp_merit - best_merit) >= m_delta) {
                            best_merit = temp_merit;
                            suprimir = j;
                        }
                        best_group.set(j);
                    }
                }
                if (suprimir == -1)
                    best_group.clear(m_Ranking[i]);
                else if (suprimir >= 0)
                    best_group.clear(suprimir);               
                if (m_verbose)
                    System.out.println("Tras la b�squeda local tenemos el subconjunto ("
			+Utils.doubleToString(Math.abs(best_merit),8,5)
			+"): "+printSubset(best_group));      
            }
        }
        else {
          for (int i=0;i<m_Ranking.length*m_porc/100;i++) {
            best_group.set(m_Ranking[i]);
            temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
            m_totalEvals++;
//            if (m_SubsetEval instanceof WrapperSubsetEval 
//                    || m_SubsetEval instanceof ClassifierSubsetEval)
//                temp_merit = 1 + temp_merit;           
            if (m_verbose)
	       System.out.println("L�nea: "+ (linea++) +" Con Att: "+(m_Ranking[i]+1)+" valor: "+temp_merit);
            if ((temp_merit - best_merit) > m_delta){
                best_merit = temp_merit; //((temp_merit < best_merit) ? best_merit : temp_merit); //permite que empeore un poco, pero se mantenga el mejor anterior
		if (m_verbose) 
		   System.out.println("Mismo valor que l�nea: "+ (linea-1)+" New best subset ("
			+Utils.doubleToString(Math.abs(best_merit),8,5)
			+"): "+printSubset(best_group));            
            }
            else
                best_group.clear(m_Ranking[i]);
          }
        }
    }
    
    if (m_purge && !m_backEach) {
        double tempBestMerit;
        boolean done = false;
        do {
            tempBestMerit = best_merit;
            int j,elimAtt=-1;
            for (j = 0; j < m_numAttribs-1; j++) {
              if (best_group.get(j)) {
                  best_group.clear(j);
                  temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);
                  m_totalEvals++;
                  if (m_verbose)
                      System.out.println("Final: "+ (linea++) +" Sin Att: "+(j+1)+" valor: "+temp_merit);
                  if ((temp_merit - tempBestMerit) >= m_delta) {
                      tempBestMerit = temp_merit;
                      elimAtt = j;
                      if (m_verbose) 
                            System.out.println("Mismo valor que l�nea: "+ (linea-1)+" New best subset ("
                                +Utils.doubleToString(Math.abs(tempBestMerit),8,5)
                                +"): "+printSubset(best_group));            
                  }
                  best_group.set(j);
              }
            }
            if (tempBestMerit != best_merit) {
                  best_group.clear(elimAtt);
                  best_merit = tempBestMerit;
                  if (m_verbose) {
                      System.out.println("------------ Se elimina: "+ (elimAtt+1));
                  }
             } else {
                done = true;
             }
        } while (!done);
    }
    m_bestMerit = best_merit;
    return attributeList(best_group);
  }

    private String printSubset(BitSet temp) {
    StringBuffer text = new StringBuffer();

    for (int j=0;j<m_numAttribs;j++) {
      if (temp.get(j)) {
        text.append((j+1)+" ");
      }
    }
    return text.toString();
  }
  
  /**
   * converts a BitSet into a list of attribute indexes 
   * @param group the BitSet to convert
   * @return an array of attribute indexes
   **/
  private int[] attributeList (BitSet group) {
    int count = 0;
    
    // count how many were selected
    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	count++;
      }
    }

    int[] list = new int[count];
    count = 0;

    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	list[count++] = i;
      }
    }

    return  list;
  }

   /**
   * returns a description of the search as a String
   * @return a description of the search
   */
  public String toString () {
    StringBuffer text = new StringBuffer();
    text.append("\tRankAllSemiSearch :\n"+ ((m_backward)
		      ? "backwards)" : "forwards)"));
    text.append("\tAttribute evaluator : "
		+ getAttributeEvaluator().getClass().getName() +" ");
    if (m_ASEval instanceof OptionHandler) {
      String[] evaluatorOptions = new String[0];
      evaluatorOptions = ((OptionHandler)m_ASEval).getOptions();
      for (int i=0;i<evaluatorOptions.length;i++) {
	text.append(evaluatorOptions[i]+' ');
      }
    }
    text.append("\n");
    text.append("\tAttribute ranking : \n");
    int rlength = (int)(Math.log(m_Ranking.length) / Math.log(10) + 1);
    for (int i=0;i<m_Ranking.length;i++) {
      text.append("\t "+Utils.doubleToString((double)(m_Ranking[i]+1),
					     rlength,0)
		  +" "+m_Instances.attribute(m_Ranking[i]).name()+'\n');
    }
   text.append("\tTotal number of subsets evaluated: " 
		    + m_totalEvals + "\n");
   text.append("\tMerit of best subset found : ");
    int fieldwidth = 3;
    double precision = (m_bestMerit - (int)m_bestMerit);
    if (Math.abs(m_bestMerit) > 0) {
      fieldwidth = (int)Math.abs((Math.log(Math.abs(m_bestMerit)) / Math.log(10)))+2;
    }
    if (Math.abs(precision) > 0) {
      precision = Math.abs((Math.log(Math.abs(precision)) / Math.log(10)))+3;
    } else {
      precision = 2;
    }

    text.append(Utils.doubleToString(Math.abs(m_bestMerit),
				     fieldwidth+(int)precision,
				     (int)precision)+"\n");
    return text.toString();
  }
}
