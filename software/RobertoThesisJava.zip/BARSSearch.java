/* Pendiente:
 *    implements RankedOutputSearch, StartSetHandler, 
 *          TechnicalInformationHandler
 * Extraido del algoritmo FCBF
 * 
 * Dependencias con otras clases java propias: RankerAll, 
 * 
 * Integrar con la clase Soluciones de Miguel
 * /

/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

 /*
 *    RELEASE INFORMATION (January 23, 2008)
 *    
 *    BARS algorithm:
 *      Template obtained from Weka
 *      Developed by Roberto Ruiz   
 *      January 23, 2008
 *
 *    BARS algorithm is a feature selection method based on relevance redundancy
 *    analysis. The details of BARS algorithm are in:
 *
 <!-- technical-plaintext-start -->
 * 
 <!-- technical-plaintext-end -->
 *    
 *    
 *    CONTACT INFORMATION
 *    
 *    Roberto Ruiz: robertoruiz at upo.es
 *     
 *    School of Engineering
 *    Pablo de Olavide University
 *    Ctra. Utrera km. 1
 *    41013 Seville (Spain)
 *
 *    BARSSearch.java
 *
 *    Copyright (C) 
 *
 */


package weka.attributeSelection;

import  java.io.*;
import  java.util.*;
import  weka.core.*;


/**
 <!-- globalinfo-start -->
 * BARS : <br/>
 * 
 <!-- options-end -->
 * 
 *
 * @author Roberto Ruiz (robertoruiz at upo.es)
 * @version $Revision 1.5$
 */
public class BARSSearch
        extends ASSearch 
        implements OptionHandler {
    private static final long serialVersionUID = -711870119827871135L;

  /** does the data have a class */
  private boolean m_hasClass;
 
  /** holds the class index */
  private int m_classIndex;
 
  /** number of attributes in the data */
  private int m_numAttribs;

  /** the best subset found */
  private BitSet m_best_group;

  /** the attribute evaluator to use for generating the ranking */
  private ASEvaluation m_ASEval;

  /** the subset evaluator with which to evaluate the ranking */
  private ASEvaluation m_SubsetEval;

  /** the training instances */
  private Instances m_Instances;

  /** the merit of the best subset found */
  private double m_bestMerit;

  /** will hold the attribute ranking */
  private int [] m_Ranking;

  /** Determina el umbral para formar subconjuntos */
  private int m_delta;
  
  /** Determina el porcentaje de ranking para formar subconjuntos */
  private int m_porc;

  /** Use two thresholds instead of the best previous subset */
  protected boolean m_twoThres = false;

  /** if true, then ouput new best subsets as the search progresses */
  private boolean m_verbose;
  
  /** total number of subsets evaluated during a search */
  protected int m_totalEvals;

  /** Determina el número de subconjuntos soluciones a guardar */
  private int m_numMejoresSubconjuntos;
          
  /** Subconjuntos soluciones */
  private List m_listaMejoresSubconjuntos;

  /**
   * Returns a string describing this search method
   * @return a description of the search method suitable for
   * displaying in the explorer/experimenter gui
   */
  public String globalInfo() {
    return "RankKSemiSearch : \n\n"
      +"Utiliza un evaluador/subEvaluador de atributos para evaluarlos "
      + "individualmente y elaborar un ranking,"
      +"Si se introduce un evaluador de subconjuntos genera una excepci�n. "
      +"Se eval�a el primer atributo con el evaluador de subconjuntos, "
      +"se eval�an las parejas con los k primeros atributos, y se escoger�n" +
        "para la siguiente fase aquellas que mejoren al mejor atributo individual."
      +"En el siguiente paso, se seleccionan las ternas, formadas con los atributos" +
      " que est�n entre los elegidos, que mejoren a la mejor pareja, y as� sucesivamente.\n";
  }

  public BARSSearch() {
    resetOptions();
  }

  /**
   * Returns the tip text for this property
   * @return tip text for this property suitable for
   * displaying in the explorer/experimenter gui
   */
  public String attributeEvaluatorTipText() {
    return "Medida de evaluaci�n para generar el ranking.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setAttributeEvaluator(ASEvaluation newEvaluator) {
    m_ASEval = newEvaluator;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public ASEvaluation getAttributeEvaluator() {
    return m_ASEval;
  }

  public String deltaTipText() {
    return "Valor que tendra que superar para a�adir un att.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setDelta(int val) {
    m_delta = val;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public int getDelta() {
    return m_delta;
  }
  
  public String porcTipText() {
    return "Valor que tendra que superar para a�adir un att.";    
  }

  /**
   * Set the attribute evaluator to use for generating the ranking.
   * @param newEvaluator the attribute evaluator to use.
   */
  public void setPorc(int val) {
    m_porc = val;
  }

  /**
   * Get the attribute evaluator used to generate the ranking.
   * @return the evaluator used to generate the ranking.
   */
  public int getPorc() {
    return m_porc;
  }

  
  /**
   * Set two thresholds
   *
   * @param back true to set
   */
  public void setTwoThres(boolean back) {
    m_twoThres = back;
  }

  /**
   * Get whether to search backwards
   *
   * @return true if the search will proceed backwards
   */
  public boolean getTwoThres() {
    return m_twoThres;
  } 

  public String verboseTipText() {
    return "Muestra informaci�n del progreso.";
  }

  /**
   * set whether or not to output new best subsets as the search proceeds
   * @param v true if output is to be verbose
   */
  public void setVerbose(boolean v) {
    m_verbose = v;
  }

  /**
   * get whether or not output is verbose
   * @return true if output is set to verbose
   */
  public boolean getVerbose() {
    return m_verbose;
  }
  
  public int getNumMejoresSubconjuntos() {
      return m_numMejoresSubconjuntos;
  }
  
  public void setNumMejoresSubconjuntos(int n) {
      m_numMejoresSubconjuntos = n;
  }

  /**
   * Returns an enumeration describing the available options.
   * @return an enumeration of all the available options.
   **/
  public Enumeration listOptions () {
    Vector newVector = new Vector(4);
    newVector.addElement(new Option("\tUmbral para a�adir un nuevo att."
				    ,"-D", 0, "-D"));
    newVector.addElement(new Option("\tPorcentaje del ranking a tratar"
				    ,"-P", 0, "-P"));
    newVector.addElement(new Option("\tUse two threshold."
				    ,"-B", 0, "-B"));
    newVector.addElement(new Option("\tOutput subsets as the search progresses."
				    +"\n\t(default = false)."
				    , "V", 0
				    , "-V"));
    newVector.addElement(new Option("\tclass name of attribute evaluator to" 
			       + "\n\tuse for ranking. Place any" 
			       + "\n\tevaluator options LAST on the" 
			       + "\n\tcommand line following a \"--\"." 
			       + "\n\teg. -A weka.attributeSelection."
			       +"GainRatioAttributeEval ... " 
			       + "-- -M", "A", 1, "-A <attribute evaluator>"));

    if ((m_ASEval != null) && 
	(m_ASEval instanceof OptionHandler)) {
      newVector.addElement(new Option("", "", 0, "\nOptions specific to" 
				      + "evaluator " 
				      + m_ASEval.getClass().getName() 
				      + ":"));
      Enumeration enumera = ((OptionHandler)m_ASEval).listOptions();

      while (enumera.hasMoreElements()) {
        newVector.addElement(enumera.nextElement());
      }
    }

    return newVector.elements();
  }


  /**
   * Parses a given list of options.
   *
   * Valid options are:<p>
   *
   * -A <attribute evaluator> <br>
   *
   * @param options the list of options as an array of strings
   * @exception Exception if an option is not supported
   *
   **/
  public void setOptions (String[] options)
    throws Exception {
    String optionString;
    resetOptions();
    optionString = Utils.getOption('D', options);
    if (optionString.length() != 0) {
      Integer temp;
      temp = Integer.valueOf(optionString);
      setDelta(temp.intValue());
    }
    optionString = Utils.getOption('P', options);
    if (optionString.length() != 0) {
      Integer temp;
      temp = Integer.valueOf(optionString);
      setPorc(temp.intValue());
    }
    setTwoThres(Utils.getFlag('B', options));    
    setVerbose(Utils.getFlag('V',options));
    
    optionString = Utils.getOption('A', options);
    if (optionString.length() == 0) {
      throw  new Exception("An attribute evaluator  must be specified with" 
			   + "-A option");
    }

    setAttributeEvaluator(ASEvaluation.forName(optionString, 
				     Utils.partitionOptions(options)));
  }

  /**
   * Gets the current settings of WrapperSubsetEval.
   *
   * @return an array of strings suitable for passing to setOptions()
   */
  public String[] getOptions () {
    String[] evaluatorOptions = new String[0];

    if ((m_ASEval != null) && 
	(m_ASEval instanceof OptionHandler)) {
      evaluatorOptions = ((OptionHandler)m_ASEval).getOptions();
    }

    String[] options = new String[9 + evaluatorOptions.length];
    int current = 0;

    options[current++] = "-D";
    options[current++] = "" + getDelta();
      
    options[current++] = "-P";
    options[current++] = "" + getPorc();

    if (getTwoThres()) {
      options[current++] = "-B";
    }
    if (m_verbose) {
      options[current++] = "-V";
    }
    
    if (getAttributeEvaluator() != null) {
      options[current++] = "-A";
      options[current++] = getAttributeEvaluator().getClass().getName();
    }

    options[current++] = "--";
    System.arraycopy(evaluatorOptions, 0, options, current, 
		     evaluatorOptions.length);
    current += evaluatorOptions.length;

    while (current < options.length) {
      options[current++] = "";
    }

    return  options;
  }

  /**
   * Reset the search method.
   */
  protected void resetOptions () {
    m_ASEval = new SymmetricalUncertAttributeEval();
    m_Ranking = null;
    m_delta = 3; 
    m_porc = 100;
    m_twoThres = false;
    m_verbose = false;
    m_numMejoresSubconjuntos = 100;
  }

  /**
   * Ranks attributes using the specified attribute evaluator and then
   * searches the ranking using the supplied subset evaluator.
   *
   * @param ASEvaluator the subset evaluator to guide the search
   * @param data the training instances.
   * @return an array (not necessarily ordered) of selected attribute indexes
   * @exception Exception if the search can't be completed
   */
  public int[] search (ASEvaluation ASEval, Instances data)
    throws Exception {
        
    if (!(ASEval instanceof SubsetEvaluator)) {
      throw  new Exception(ASEval.getClass().getName() 
			   + " is not a " 
			   + "Subset evaluator!");
    }
    m_totalEvals = 0;
    m_SubsetEval = ASEval;
    m_Instances = data;
    m_numAttribs = m_Instances.numAttributes();
    
    if (m_ASEval instanceof UnsupervisedAttributeEvaluator || 
	m_ASEval instanceof UnsupervisedSubsetEvaluator) {
      m_hasClass = false;
    }
    else {
      m_hasClass = true;
      m_classIndex = m_Instances.classIndex();
    }

    RankerAll ranker = new RankerAll();
    m_ASEval.buildEvaluator(m_Instances);
//    ((AttributeEvaluator)m_ASEval).buildEvaluator(m_Instances);

//  NOTA: se ha comentado estas líneas porque parece que en esta versión no
//        se reconoce. Modificar dejando sólo un evaluador, el de subconjunto.

//    if (m_ASEval instanceof AttributeTransformer) {
//    // get the transformed data a rebuild the subset evaluator
//	m_Instances = ((AttributeTransformer)m_ASEval).transformedData();
//	((SubsetEvaluator)m_SubsetEval).buildEvaluator(m_Instances);
//    }
    m_Ranking = ranker.search(m_ASEval, m_Instances);

    double best_merit = -Double.MAX_VALUE;
    double temp_merit;
    BitSet best_group=new BitSet(m_numAttribs);

    //Inicializa el mejor subconjunto con el 1er att y su evaluación
    best_group.set(m_Ranking[0]); 
    double lim_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(best_group);

    if (m_delta > m_numAttribs-1)
        m_delta = m_numAttribs-1;
    
    List lisConEval = new LinkedList();
    for (int i=0;i<m_Ranking.length;i++) {
        BitSet conjunto = new BitSet();
        conjunto.set(m_Ranking[i]);
        lisConEval.add(new ConjuntoEvaluado(conjunto,0.0));
    }
    m_listaMejoresSubconjuntos = new ArrayList();
    
    Set tempLisConEval = new HashSet();
    int nIt=0;
    while (lisConEval.size() > 1) {
        nIt++;
        //System.out.println("-------- Iteración: " + nIt);
        m_listaMejoresSubconjuntos.addAll(0,lisConEval);
        int tam = m_listaMejoresSubconjuntos.size();
        if (tam > m_numMejoresSubconjuntos) {
            m_listaMejoresSubconjuntos.subList(m_numMejoresSubconjuntos,tam).clear();
        }

        List lisConEvalTemp = lisConEval;
        lisConEval = new ArrayList();
        double menorMayorLocal = Double.MAX_VALUE;

        for (int i=0; (i<m_delta) && (i<lisConEvalTemp.size()); i++) {
            double mayorLocal = -Double.MAX_VALUE;
            for (int j=i+1; j<lisConEvalTemp.size()*m_porc/100; j++) {
                BitSet fusion = (BitSet)((ConjuntoEvaluado)lisConEvalTemp.get(i)).conjunto.clone();
                fusion.or(((ConjuntoEvaluado)lisConEvalTemp.get(j)).conjunto);
                //System.out.println("Fusioned Subset: " + printSubset(fusion)
                //        + " --coordenadas: " + i + ", " +j);
                if (tempLisConEval.add(fusion)) {
                    temp_merit = ((SubsetEvaluator)m_SubsetEval).evaluateSubset(fusion);
                    m_totalEvals++;
                    if (temp_merit > lim_merit) {
                        lisConEval.add(new ConjuntoEvaluado(fusion,temp_merit));
//                        System.out.println("Evaluated Subset (" +
//                                    Utils.doubleToString(Math.abs(temp_merit),8,5)
//                                    + "): " + printSubset(fusion) + " -Added- ");
                        if (m_verbose)
                            System.out.println("Evaluated Subset (" + 
                                    Utils.doubleToString(Math.abs(temp_merit),8,5)
                                    + "): " + printSubset(fusion) + " -Added- ");
                    }
                    if (temp_merit > mayorLocal) { 
                        mayorLocal = temp_merit;
                    }
                }
            }
            if (mayorLocal < menorMayorLocal) {
                menorMayorLocal = mayorLocal;
            }
        }
        if (lisConEval.size() > 0) {
            if (m_twoThres) {
                sacarMenoresQue(lisConEval,menorMayorLocal);
            }
            Collections.sort(lisConEval, Collections.reverseOrder());
            lim_merit = ((ConjuntoEvaluado)lisConEval.get(0)).eval;
        } else
            lisConEval.add(lisConEvalTemp.get(0));
    }
    
    if (lisConEval.get(0) != m_listaMejoresSubconjuntos.get(0)) {
        m_listaMejoresSubconjuntos.add(0,lisConEval.get(0));
    }
    m_bestMerit = lim_merit;

    //
    int[][] subsets = getBestSubsetsList(); 
    double[] values = getBestEvaluationsList();

//    for (int i = 0; i < subsets.length; i++) {
//        System.out.print("subset #" + (i + 1) + ":" + values[i] + "{");
//        for (int j = 0; j < subsets[i].length - 1; j++) {
//            System.out.print((subsets[i][j]+1) + ",");
//        }
//        System.out.println((subsets[i][subsets[i].length - 1]+1) + "}");
//    }
    return attributeList(((ConjuntoEvaluado)lisConEval.get(0)).conjunto);
  }

  private void muestraPosicion (BitSet group) {
    StringBuffer text = new StringBuffer();
      
    for (int i = 0; i < m_numAttribs; i++)
      if (group.get(i))
          for (int j=0; j<m_Ranking.length; j++)
              if (m_Ranking[j] == i)
                text.append("Atributo: "+ (i+1) + " posición: " + (j+1) +"\n");
    System.out.println(text.toString());
  }
  
  
  private void sacarMenoresQue(List l, double lim) {
      Iterator it = l.iterator();
      while (it.hasNext()) {
          ConjuntoEvaluado c = (ConjuntoEvaluado)it.next();
          if (c.eval < lim) {
              it.remove();
              if (m_verbose) {
                System.out.println("subconjunto eliminado: "
                    +printSubset(c.conjunto));            
              }
          }
      }
  }
  
    private String printSubset(BitSet temp) {
    StringBuffer text = new StringBuffer();

    for (int j=0;j<m_numAttribs;j++) {
      if (temp.get(j)) {
        text.append((j+1)+" ");
      }
    }
    return text.toString();
  }
  
  /**
   * converts a BitSet into a list of attribute indexes 
   * @param group the BitSet to convert
   * @return an array of attribute indexes
   **/
  private int[] attributeList (BitSet group) {
    int count = 0;
    
    // count how many were selected
    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	count++;
      }
    }

    int[] list = new int[count];
    count = 0;

    for (int i = 0; i < m_numAttribs; i++) {
      if (group.get(i)) {
	list[count++] = i;
      }
    }

    return  list;
  }

  public int[][] getBestSubsetsList() {
      int numSubsets = m_listaMejoresSubconjuntos.size();
      int [][] temp = new int[numSubsets][];
      
      for (int i=0; i < numSubsets ; i++) {
          temp[i] = attributeList(((ConjuntoEvaluado)m_listaMejoresSubconjuntos.get(i)).conjunto);
      }
      
      return temp;
  }

  public double [] getBestEvaluationsList() {
    int numSubsets = m_listaMejoresSubconjuntos.size();
    double [] temp = new double[numSubsets];

    for (int i=0; i < numSubsets ; i++) {
      temp[i] = ((ConjuntoEvaluado)m_listaMejoresSubconjuntos.get(i)).eval;
    }

    return temp;
  }
  
  /**
   * returns a description of the search as a String
   * @return a description of the search
   */
  public String toString () {
    StringBuffer text = new StringBuffer();
    text.append("\tRankKSemiSearch :\n"+ ((m_twoThres)
		      ? "twoThres)" : "twoThres)"));
    text.append("\tAttribute evaluator : "
		+ getAttributeEvaluator().getClass().getName() +" ");
    if (m_ASEval instanceof OptionHandler) {
      String[] evaluatorOptions = new String[0];
      evaluatorOptions = ((OptionHandler)m_ASEval).getOptions();
      for (int i=0;i<evaluatorOptions.length;i++) {
	text.append(evaluatorOptions[i]+' ');
      }
    }
    text.append("\n");
    text.append("\tAttribute ranking : \n");
    int rlength = (int)(Math.log(m_Ranking.length) / Math.log(10) + 1);
    for (int i=0;i<m_Ranking.length;i++) {
      text.append("\t "+Utils.doubleToString((double)(m_Ranking[i]+1),
					     rlength,0)
		  +" "+m_Instances.attribute(m_Ranking[i]).name()+'\n');
    }
   text.append("\tTotal number of subsets evaluated: " 
		    + m_totalEvals + "\n");
   text.append("\tMerit of best subset found : ");
    int fieldwidth = 3;
    double precision = (m_bestMerit - (int)m_bestMerit);
    if (Math.abs(m_bestMerit) > 0) {
      fieldwidth = (int)Math.abs((Math.log(Math.abs(m_bestMerit)) / Math.log(10)))+2;
    }
    if (Math.abs(precision) > 0) {
      precision = Math.abs((Math.log(Math.abs(precision)) / Math.log(10)))+3;
    } else {
      precision = 2;
    }

    text.append(Utils.doubleToString(Math.abs(m_bestMerit),
				     fieldwidth+(int)precision,
				     (int)precision)+"\n");
    return text.toString();
  }
}
class ConjuntoEvaluado implements Comparable, Serializable{
    BitSet conjunto;
    double eval;
    
    public ConjuntoEvaluado(BitSet s, double e) {
        conjunto = s;
        eval = e;
    }
    
    public int compareTo(Object o) {
        int res=0;
        if (eval > ((ConjuntoEvaluado)o).eval )
            res = 1;
        else if (eval < ((ConjuntoEvaluado)o).eval )
            res = -1;
        else
            res = 0;
        return res;
    }
    
    public String toString () {
        StringBuffer text = new StringBuffer();
        text.append("\tEvaluación conjunto: "+ eval);
        return text.toString();
    }
   
}