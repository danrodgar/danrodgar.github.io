/*
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *   
 *   
 */


package weka.filters.unsupervised.instance;

import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import weka.core.Capabilities;
import weka.core.Capabilities.Capability;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.Utils;
import weka.filters.SimpleBatchFilter;
import weka.filters.UnsupervisedFilter;

/**
<!-- globalinfo-start -->
* A filter that eliminates some random majority instances until the total amount of majority instances reaches the percentage given.
* <p/>
<!-- globalinfo-end -->
* 
<!-- options-start -->
* Valid options are: <p/>
* 
* <pre> -P &lt;Percent&gt;
*  Specifies the proportion of final majority class respecting the minority class. (default 60).
*  If the percentage specified is higher than the current majority percentage, the filter does nothing,
*  else, the filter eliminates majority classes randomly until the majority proportion reaches the percentage specified.
* </pre>
* 
<!-- options-end -->
*
* @author Sergio Garc�a Charameli
* @author Daniel Rodr�guez - University of Alcal�
* @version $Revision: 1 $ 
*/

public class RandomUnderSampling
extends SimpleBatchFilter
implements UnsupervisedFilter, OptionHandler {

	private static final long serialVersionUID = -3716982132030776739L;
	
	protected double m_Percent = 60.0;
	
	public double getPercent() {
		return m_Percent;
	}

	public void setPercent(double percentage) {
		
		if (percentage < 1 || percentage > 99) {
			throw new IllegalArgumentException("Percentage must be between 1 and 99.");
		}
		
		this.m_Percent = percentage;
	}

	public String percentTipText() {
		return "Specifies the proportion of majority class desired.";
	}
	  
	@Override
	public Capabilities getCapabilities() {
		Capabilities result = super.getCapabilities();

		result.disableAll();

		// attributes
		result.enableAllAttributes();

		// class
		result.enable(Capability.BINARY_CLASS);


		return result;
	}	

	@Override
	public Enumeration listOptions() {

		Vector newVector = new Vector(1);

		newVector.addElement(new Option(
				"\tSpecifies the final proportion of the majority class in %.\n", "P", 1, "-P <percentage>"));
	    
		return newVector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {

		String percentString = Utils.getOption('P', options);
		
		if (percentString.length() != 0)
			setPercent(Double.parseDouble(percentString));
		else 
			setPercent(50.0);

		if (getInputFormat() != null)
			setInputFormat(getInputFormat());
	}


	@Override
	public String[] getOptions() {

		String [] options = new String [2];
		int current = 0;

		options[current++] = "-P";

		options[current++] = "" + getPercent();

		while (current < options.length) {
			options[current++] = "";
		}
		return options;
	}


	public String globalInfo() {
		return "A filter that eliminates some random majority instances until the total amount of majority instances reaches the percentage given.";
	}

	protected Instances determineOutputFormat(Instances inputFormat)
			throws Exception {
		Instances result = new Instances(inputFormat, 0);

		return result;
	}


	protected Instances process(Instances instances) throws Exception {

		Instances subInstancesA = new Instances(determineOutputFormat(instances), 0);
		Instances subInstancesB = new Instances(determineOutputFormat(instances), 0);

		int classIndex = instances.classIndex();

		String classAttributeA = instances.classAttribute().enumerateValues().nextElement().toString();

		//The instances will be splitted in two groups to identify the majority class later.
		for ( int i = 0 ; i < instances.size() ; i++ ){
			if ( classAttributeA.equalsIgnoreCase( instances.instance(i).stringValue(classIndex)))
				subInstancesA.add(instances.instance(i));
			else
				subInstancesB.add(instances.instance(i));
		}

		//It is evaluated which one is the majority class, and it is sent to RandomUnderSample
		//The minority class instance number is required by the function in order to calculate
		//the amount of UnderSampling to apply.
		if ( subInstancesA.size() > subInstancesB.size() )
			subInstancesA = RandomUnderSample(subInstancesA, subInstancesB.size());
		else
			subInstancesB = RandomUnderSample(subInstancesB, subInstancesA.size());

		//The minority class is merged with the new majority class into a final instance set.
		for ( int i = 0 ; i < subInstancesB.size() ; i++ ) {
			subInstancesA.add(subInstancesB.instance(i));
		}

		//Just a check to prevent weka exception when 0 instances are returned by the filter.
		if ( subInstancesA.size() == 0 ) 
			throw new Exception( getExceptionMsg() );
	
		return subInstancesA;
	}
	
	//This function will return a new reduced instance set depending on the percentage provided
	//and the number of minority instances. If the percentage given is higher than the current
	//majority instances number, the function will not eliminate any majority instance.
	private Instances RandomUnderSample (Instances subInstances, int oppositeSubInstancesNumer) {
		
		Random r = new Random ();
		
		int finalInstancesNumber = oppositeSubInstancesNumer * (int) m_Percent / (100 - (int) m_Percent);
		int toDeleteNumber = subInstances.size() - finalInstancesNumber;
		
		for ( int i = 0 ; i < toDeleteNumber ; i++ ) {
			
			subInstances.remove(r.nextInt(subInstances.size()));
		}
		
		return subInstances;
	}

	private String getExceptionMsg(){
		
		return "0 instances will be returned.";		
	}

	/**
	 *
	 * @param args	the command-line attributes
	 * @throws Exception	if something goes wrong
	 */
	public static void main(String[] argv) {
		runFilter(new RandomUnderSampling(), argv);
	}
}
