/*
 * Created on Dec 2, 2004
 */
package weka.classifiers.functions.geneticprogramming;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;
import weka.core.Instance;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;

public abstract class Program implements Serializable, Cloneable {
	
// 	The fitness represents the program performance on the specified task.
	protected double trainingFitness;			// The program's fitness, for training purposes
	protected double validationFitness; 		// The program's fitness with validation database
	protected double totalFitness;				// From both training and validation, with proportion to nb of ins
	protected double error = Double.NaN;		// Total error proportion from training and validation
	protected boolean wasValidated;				// Indicates if validation fitness was computed
	
	protected int size;							// The whole program's size
	
//  IMPORTANT : Here fitness must be computed at Program creation or right after genetic operation
	
	public abstract Program clone(ProgramRules PR);
    public abstract void growInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp);
    public abstract void fullInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp);
    public abstract void crossover(ProgramRules PR, Program otherProgram, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp) throws Exception;
    public abstract void mutation(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp);
    public abstract double execute(double inputArgs[]);
    protected abstract void recompute();
    public abstract int getSize();
    public abstract void simplify(ProgramRules PR, Instances trainingInstances);
    public abstract String toString(String inputNames[], String classNames[], ProgramRules PR);
    
    protected double computeFitness(Instances trainIns, Instances valIns, FitnessEvaluator fe, double valProp){
    	trainingFitness = fe.measureFitness(trainIns,this);
    	if(valIns != null){
    		validationFitness = fe.measureFitness(valIns,this);
    		totalFitness = valProp * validationFitness + ((1-valProp) * trainingFitness);
    		wasValidated = true;
    	}else{
    		totalFitness = trainingFitness;
    		wasValidated = false;
    	}

    	return totalFitness;
    }
    
    public double getFitness(){
    	return totalFitness;
    }
    
    public double getTrainingFitness(){
        return trainingFitness;        
    }
    
    public double getValidationFitness(){
        return validationFitness;        
    }
    
    public double getError(){
        return error;        
    }
    
    public boolean wasValidated(){
    	return wasValidated;
    }
    
    public void computeError(int classNo, FitnessEvaluator FE, Instances trainIns, Instances valIns){
		
    	Enumeration enu = trainIns.enumerateInstances();	
    	double success = 0.0;
		
    	while(enu.hasMoreElements()){
			Instance instance = (Instance)enu.nextElement();
			double score = FE.measureFitness(instance, this);
			
			if( (score >= 0.5 && instance.classValue() == classNo) || 
					(score < 0.5 && instance.classValue() != classNo) ){
				success += 1.0;
			}
		}		
    	
    	if(valIns != null){
	    	enu = valIns.enumerateInstances();		
			
	    	while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
				double score = FE.measureFitness(instance, this);
	            
				if( (score >= 0.5 && instance.classValue() == classNo) || 
						(score < 0.5 && instance.classValue() != classNo) ){
					success += 1.0;
				}
			}	
	    	success = success /= (double)(trainIns.numInstances() + valIns.numInstances());
    	}else
    		success = success /= (double)(trainIns.numInstances());
    	
    	error = 1.0 - success;
    }
    
    public void computeErrorRegression(Instances valIns){
       	error = trainingFitness;
       	if(valIns != null)
       		error += validationFitness;
    }

    public static Vector cloneVectorOfPrograms(Vector toCopy, ProgramRules PR){
    	Vector theClone = new Vector();
    	for(int i = 0;i<toCopy.size();i++){
    		theClone.add(((Program)toCopy.get(i)).clone(PR));
    	}
    	return theClone;
    	
    }
    
    public String toString(){
    	String validation = "";
    	if(wasValidated){
    		validation = "Validation fitness = " + validationFitness + "\n";
    	}
    	
    	return ("Program\n" + "Train fitness = " + trainingFitness +  "\n" +
    			validation + "Error = " + error + "\n" +
    			"Size = " + size + "\n");
    }
}

