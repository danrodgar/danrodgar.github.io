package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Square extends Function {

	public Square(ArgumentType AT){
		super(AT);
		name = "Sq";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 1;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		return argVal[0] * argVal[0];
	}
}
