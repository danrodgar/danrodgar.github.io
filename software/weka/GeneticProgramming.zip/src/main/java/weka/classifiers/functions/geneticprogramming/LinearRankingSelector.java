package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;

public class LinearRankingSelector extends ProgramSelector {

	double probability[];
	double pMinus;
	double pPlus;

	public LinearRankingSelector(double pMin, double mPl) throws Exception{
	// pMin / N is the probability for worst program, pPl / N is the probability for best program
		if(pMin + mPl != 2.0){
			Exception e = new Exception("The sum of the two parameters for LinearRankingSelector must be equal to 2.0.\n");
			throw e;
		}
		if(pMin > mPl){
			Exception e = new Exception("The first argument for LinearRankingSelector must be less than the second.\n");
			throw e;
		}
		pMinus = pMin;
		pPlus = mPl;
	}
	
	public void prepareRanking(Vector pop, FitnessEvaluator FE, double pV) {		
		int rank,popSize = pop.size();
		double n = (double) popSize;
		double nMinusOne = n - 1.0;
		probability = new double[popSize];
		
		ProgramSelector.sortProgramPopulation(pop, FE, pV);
		double sum = 0;;
		for(rank=0;rank<popSize;rank++){
			probability[rank] = (1.0 / n)*(pMinus+(pPlus - pMinus)*((((double)rank+1)-1.0)/nMinusOne));
			sum += probability[rank];
		}
		probability[popSize-1] += Math.max(1.0 - sum, 0.0);
	}
		
	public Vector selectPrograms(Vector pop, FitnessEvaluator FE, int number, double pV) {
		Vector programPositions = new Vector();
		for(int i = 0;i<number;i++){
			int selected = -1;
			double sum = 0;
			double random = Math.random();
			do{
				selected++;
				sum += probability[selected];
			}
			while(sum < random);
			
			programPositions.add(new ProgramPosition(selected, (Program)pop.get(selected)));
		}
		ProgramSelector.sortProgramPositions(programPositions, FE, pV);
		return programPositions;
	}

	public boolean usuallyReplaces() {
		return false;
	}
	
	public Object clone(){
		try{
			return new LinearRankingSelector(pMinus, pPlus);
		}catch(Exception E){
			E.printStackTrace();
		}
		return null;
	}
	
	
	public String toString(){
		return new String("Linear Ranking Selector : selects programs with probability based on " +
				"linear approximation after ranking programs with fitness. Min probability is " +
				pMinus + " / N, and Max probabilty is " + pPlus + " / N.");
	}

}
