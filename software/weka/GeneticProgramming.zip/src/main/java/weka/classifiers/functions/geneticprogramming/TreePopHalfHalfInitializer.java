package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.PopulationInitializer;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class TreePopHalfHalfInitializer implements PopulationInitializer, java.io.Serializable {

	public Program createProgram(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double pV){
		MainProgramTree program = new MainProgramTree(PR);
		if(Math.random()<=0.5)
			program.fullInit(PR, fe, trainIns, valIns, pV);
		else
			program.growInit(PR, fe, trainIns, valIns, pV);
		return program;
	}
		
	public Vector createPopulation(int popSize, ProgramRules PR, FitnessEvaluator fe, EliteManager EM, Instances trainIns, Instances valIns, double pV) {
		
		Vector pop = new Vector();
		MainProgramTree program;
		
		int minDepth = 1;
		int maxDepth = PR.getMaxDepth();
		
		int jump = popSize / (maxDepth - minDepth + 1);
		int halfJump = jump - (jump / 2);
		int tmpMaxDepth = minDepth;
		
		PR.setMaxDepth(tmpMaxDepth);
		int j=1;
		
		for(int i=0;i<popSize;i++, j++){
			if(j>jump && tmpMaxDepth < maxDepth){
				tmpMaxDepth++;
				PR.setMaxDepth(tmpMaxDepth);
				j = 1;
			}
									
			program = new MainProgramTree(PR);
			
			if(j>=halfJump)
				program.fullInit(PR, fe, trainIns, valIns, pV);
			else
				program.growInit(PR, fe, trainIns, valIns, pV);
			
			pop.add(program);
		}
		PR.setMaxDepth(maxDepth);
		EM.manageElite(pop, fe, PR, trainIns, pV);
		return pop;
	}

	public String getProgramTypeString(){
		return "MainProgramTree";
	}
	
	public Object clone(){
		return new TreePopHalfHalfInitializer();
	}
	
	public String toString(){
		return new String("Tree Population (ramped) Half and Half Initializer : initializes a population of program trees " +
				"using the Full and Grow method, creating trees with depth from 2 to maximum depth, with an equal " +
				"number of programs for each depth.");
	}

}
