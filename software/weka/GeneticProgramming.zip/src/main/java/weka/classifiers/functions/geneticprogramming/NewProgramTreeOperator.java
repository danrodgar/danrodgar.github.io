package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class NewProgramTreeOperator extends GeneticOperator {

	public NewProgramTreeOperator(int nbParents, int nbChildren, double prob){
		super(nbParents, nbChildren, prob);
	}
	
	/** Here we simply create a new program
	 *  nbChildren new programs are created..
	 *  The children are either returned (if "replace" == false), or
	 *  they replace the last programs of the parent list (if "replace" == true)  */
	public Vector performOperation(ProgramRules PR, Vector inputProgramPositions, FitnessEvaluator fe,
			Instances trainIns, Instances valIns, Vector pop, boolean doReplacement, double valProp) {
		
		Vector resultPrograms = new Vector();

		// Here we clone the nbOfChildren first program into the results
		for(int i=0;i<nbOfChildren;i++){
			Program newProgram = new MainProgramTree(PR);
			newProgram.growInit(PR, fe, trainIns, valIns, valProp);
			resultPrograms.add(newProgram);
		}
		
		// Here we replace the last programs of the list with the results
		if(doReplacement){
			replace(inputProgramPositions, resultPrograms, pop);
			return null;
		}
		// Or simply return the result
		return resultPrograms;
	}
	
	public String toString(){
		return new String("New Program Tree Operator : creates completely new programs.\n" + super.toString());
	}

}
