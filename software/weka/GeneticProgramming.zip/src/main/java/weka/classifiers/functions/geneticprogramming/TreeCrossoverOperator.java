package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class TreeCrossoverOperator extends GeneticOperator {

	
	public TreeCrossoverOperator(int nbParents, int nbChildren, double prob){
		super(nbParents, nbChildren, prob);
	}
	
	
	/** Here we perform Crossover operation.
	 *  The two first Programs of the program table get crossed, enough times to produce
	 *  the wanted number of children.
	 *  The children are either returned (if "replace" == false), or
	 *  they replace the last programs of the list (if "replace" == true)  */
	public Vector performOperation(ProgramRules PR, Vector inputProgramPositions, FitnessEvaluator fe,
			Instances trainIns, Instances valIns, Vector pop, boolean doReplacement, double pV) {
		
		int i;
		Vector resultPrograms = new Vector();
		
		// Here we clone the two first program into the results
		for(i=0;i<nbOfChildren;i++){
			resultPrograms.add( ( (ProgramPosition)inputProgramPositions.get(i % 2)).getProgram().clone(PR));
		}
		
		try {
			// Each pair of result is crossed together
			for(i=0;i<nbOfChildren/2;i++)
				((MainProgramTree)resultPrograms.get(i*2)).crossover(PR, ((MainProgramTree)resultPrograms.get(i*2+1)), fe, trainIns, valIns, pV);

			// If there is an odd number of programs, the last one crosses with itself (?!)
			if(nbOfChildren%2==1){
				int lastChild = nbOfChildren - 1;
				((MainProgramTree)resultPrograms.get(lastChild)).crossover(PR, (MainProgramTree)resultPrograms.get(lastChild), fe, trainIns, valIns, pV);
			}
		}
		catch (Exception E) {
			E.printStackTrace();
		}
		
		// Here we replace the last programs of the list with the results
		if(doReplacement){
			replace(inputProgramPositions, resultPrograms, pop);
			return null;
		}
		// Or simply return the result
		return resultPrograms;
	}

	public String toString(){
		return new String("Tree Crossover Operator : \"crosses\" two programs together, switching " +
				"a random sub-tree from each of the programs. Results are two offsprings.\n" + super.toString());
	}

}

