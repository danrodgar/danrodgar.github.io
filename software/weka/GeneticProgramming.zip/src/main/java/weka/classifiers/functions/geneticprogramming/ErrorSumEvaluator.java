package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;
import java.util.Enumeration;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.*;
import weka.gui.streams.SerialInstanceListener;

/**
 * Least Error Sum Evaluator.
 * Evaluates the fitness of a program using the sum of errors on predictions.
 * Note: fitness is the negated value of the result so that high fitness is better than
 * a low fitness.  This should be fixed (or accepted as a good solution).
 * @author Administrateur
 */
public class ErrorSumEvaluator implements FitnessEvaluator, Serializable {

	public double measureFitness(Instances ins, Program prog) {
			
		float sumErrors=0; 
		Enumeration enu = ins.enumerateInstances();		
			while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
	            double[] record = instance.toDoubleArray();
	            // Note GAB: incertain que classValue est le bon champ pour une estimation continue.
	            sumErrors += Math.abs(prog.execute(record) - instance.classValue() );
			}			
		return(sumErrors);		
	}

	public double measureFitness(Instance instance, Program prog) {		
		return Math.abs(prog.execute(instance.toDoubleArray()) - instance.classValue() );
	}
	
	public boolean lowerIsBetter(){
		return true;
	}
	
	public Double getInferiorBound(){
		return new Double(0);
	}
	
	public Double getSuperiorBound(){
		return new Double(Double.POSITIVE_INFINITY);
	}

	public boolean isNominal() {
		return false;
	}

	public boolean isNumeric() {
		return true;
	}
	
	public String toString(){
		return new String("Error Sum Evaluator : simply sums the error for each data instance.");
	}

}
