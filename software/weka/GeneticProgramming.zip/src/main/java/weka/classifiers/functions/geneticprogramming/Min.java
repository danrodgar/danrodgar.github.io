package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Min extends Function {
	
	public Min(ArgumentType AT){
		super(AT);
		name = "Min";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		return Math.min(argVal[0],argVal[1]);
	}
}