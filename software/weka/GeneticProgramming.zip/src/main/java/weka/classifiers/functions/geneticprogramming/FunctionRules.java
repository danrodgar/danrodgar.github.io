package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.ADFRules;
import weka.classifiers.functions.geneticprogramming.Add;
import weka.classifiers.functions.geneticprogramming.And;
import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Divide;
import weka.classifiers.functions.geneticprogramming.Function;
import weka.classifiers.functions.geneticprogramming.IfThen;
import weka.classifiers.functions.geneticprogramming.IfThenElse;
import weka.classifiers.functions.geneticprogramming.Invert;
import weka.classifiers.functions.geneticprogramming.IsGreaterThan;
import weka.classifiers.functions.geneticprogramming.IsLessThan;
import weka.classifiers.functions.geneticprogramming.Multiply;
import weka.classifiers.functions.geneticprogramming.Or;
import weka.classifiers.functions.geneticprogramming.Power;
import weka.classifiers.functions.geneticprogramming.Square;
import weka.classifiers.functions.geneticprogramming.SquareRoot;
import weka.classifiers.functions.geneticprogramming.Substract;
import weka.classifiers.functions.geneticprogramming.XOr;

/**
* A table of Vectors of Functions is stored in the
* FonctionRules class. Automatically Defined Functions (ADF)
* are also considered functions.
**/

public class FunctionRules implements java.io.Serializable{
	
	// Check that all of these functions are in String ALLFUNCTIONSSTRING in weka.classifiers.trees.GeneticProgramming
	// and in function getAllAvailableFunctions()
	private final String[] ALLFUNCTIONSSTRINGS = {"+","-","/","*","Sq","Sqrt","If","If3",">","<","!",
			"Pow","&","|","Xor","Max","Min","Exp","Log","Sin","Cos"};
	
	private ArgumentType argumentType;	
	private Vector nbArgs;
	private Vector functionTable;
	private Vector functionByType[];
	private Vector functionByNbArg[];
	private Vector nonADFFunctionTable;
	private Vector nonADFFunctionByType[];
	private Vector nonADFFunctionByNbArg[];
		
	// Functions available (default) are :
	// Add, Substract, Multiply, Divide, Square, SquareRoot, IfThen, IfThenElse
	// IsLessThan, IsGreaterThan, Invert, Power, And, Or, XOr, Max, Min, Exp, Log, Sin, Cos plus you may add ADFs

	public FunctionRules(){
		argumentType = null;	
		nbArgs = null;
		functionTable = null;
		functionByType = null;
		functionByNbArg = null;
		nonADFFunctionTable = null;
		nonADFFunctionByType = null;
		nonADFFunctionByNbArg = null;
	}
	
	// Default constructor with all functions available
	public FunctionRules(ADFRules ADFR){
		setAllAvailableFunctions(ADFR);
	}
	
	// Using String table to input functions we want to use
	public FunctionRules(String[] functionsStrings, ADFRules ADFR) throws Exception{
				
		if(functionsStrings[0].compareTo("all")==0){
			setAllAvailableFunctions(ADFR);
			return;
		}
		
		// Set Argument Types to default values ("Arithmetic", "Test", "Any")
		argumentType = new ArgumentType();
		
		Function function;
		Vector allAvailableFunctionTable = getAllAvailableFunctions();
		functionTable = new Vector();
		
		for(int i=0;i<functionsStrings.length;i++){
			function = checkFunction(functionsStrings[i],allAvailableFunctionTable);
			if(function != null){
				if(!functionTable.contains(function)){
					functionTable.add(function);
				}else{
					Exception E = new Exception("Function " + functionsStrings[i] + " is already in the list.");
					throw E;
				}
			}else{
				Exception E = new Exception("Function " + functionsStrings[i] + " was not recognized.");
				throw E;
			}
		}
		nonADFFunctionTable = new Vector();
		nonADFFunctionTable.addAll(functionTable);
		
		setADFs(ADFR);
		setTables(ADFR);
	}
	
	public void setAllAvailableFunctions(ADFRules ADFR){
//		 Set Argument Types to default values ("Arithmetic", "Test", "Any")
		argumentType = new ArgumentType();
		
		// Now setting the available functions for default run
		functionTable = getAllAvailableFunctions();
		
		nonADFFunctionTable = new Vector();
		nonADFFunctionTable.addAll(functionTable);
		
		setADFs(ADFR);
		setTables(ADFR);
	}
	
	public Vector getAllAvailableFunctions(){
		Vector allAvailableFunctionTable = new Vector();
		allAvailableFunctionTable.add(new Add(argumentType));
		allAvailableFunctionTable.add(new Substract(argumentType));
		allAvailableFunctionTable.add(new Multiply(argumentType));
		allAvailableFunctionTable.add(new Divide(argumentType));
		allAvailableFunctionTable.add(new Square(argumentType));
		allAvailableFunctionTable.add(new SquareRoot(argumentType));
		allAvailableFunctionTable.add(new IfThen(argumentType));
		allAvailableFunctionTable.add(new IfThenElse(argumentType));
		allAvailableFunctionTable.add(new IsLessThan(argumentType));
		allAvailableFunctionTable.add(new IsGreaterThan(argumentType));
		allAvailableFunctionTable.add(new Invert(argumentType));
		allAvailableFunctionTable.add(new Power(argumentType));
		allAvailableFunctionTable.add(new And(argumentType));
		allAvailableFunctionTable.add(new Or(argumentType));
		allAvailableFunctionTable.add(new XOr(argumentType));
		allAvailableFunctionTable.add(new Max(argumentType));
		allAvailableFunctionTable.add(new Min(argumentType));
		allAvailableFunctionTable.add(new Exp(argumentType));
		allAvailableFunctionTable.add(new Log(argumentType));
		allAvailableFunctionTable.add(new Sin(argumentType));
		allAvailableFunctionTable.add(new Cos(argumentType));
		return allAvailableFunctionTable;
	}
	
	public static Function checkFunction(String functionName, Vector allAvailableFunctionTable){
		int size = allAvailableFunctionTable.size();
		Function function;
		for(int i=0;i<size;i++){
			function = (Function)allAvailableFunctionTable.get(i);
			if(functionName.compareTo(function.getName()) == 0)
				return function;
		}
		return null;
	}
	
	private void setADFs(ADFRules ADFR){
		// Now introducing ADFs
		if(ADFR != null){
			for(int i=0;i<ADFR.getNbOfADFs();i++){
				int nbOfInputsADF = ADFR.getNbOfInputsADF(i);
				String[] ADFAny = new String[nbOfInputsADF];
				for(int j=0;j<nbOfInputsADF;j++){
					ADFAny[j] = "Any";
				}
				functionTable.add(new Function(true, i, nbOfInputsADF, "Any", ADFAny,  "ADF" + i, argumentType));
			}
		}
	}
	
	private void setTables(ADFRules ADFR){

		int i, j, nbOfArgs, nbOfNbOfArgs;
		nbArgs = new Vector();
		int size = functionTable.size();
		int nbOfArgTypes = argumentType.getNoOfArgumentType();
		
		// Here we add functions for each Argument Type in the appropriate Vector
		functionByType = new Vector[nbOfArgTypes];
		nonADFFunctionByType = new Vector[nbOfArgTypes];
		for(i=0;i<nbOfArgTypes;i++){
			functionByType[i] = new Vector();
			nonADFFunctionByType[i] = new Vector();
			for(j=0;j<size;j++){
				if( ((Function)functionTable.get(j)).getFunctionType() == i){
					functionByType[i].add(functionTable.get(j));
					if(!(((Function)functionTable.get(j)).isADF()))
						nonADFFunctionByType[i].add(functionTable.get(j));
				}
			}
		}

		// Here we add each of the possible argument number for a function in a Vector 
		for(j=0;j<size;j++){
			nbOfArgs = ((Function)functionTable.get(j)).getNbArgs();
			if(!(nbArgs.contains(new Integer(nbOfArgs))))
				nbArgs.add(new Integer(nbOfArgs));
		}
		nbOfNbOfArgs = nbArgs.size();
		
		// Here we add functions for number of arguments in the appropriate Vector
		functionByNbArg = new Vector[nbOfNbOfArgs];
		nonADFFunctionByNbArg = new Vector[nbOfNbOfArgs];
		for(i=0;i<nbOfNbOfArgs;i++){
			functionByNbArg[i] = new Vector();
			nonADFFunctionByNbArg[i] = new Vector();
			for(j=0;j<size;j++){
				if( ((Function)functionTable.get(j)).getNbArgs() == ((Integer)nbArgs.get(i)).intValue() ){
					functionByNbArg[i].add(functionTable.get(j));
					if(!(((Function)functionTable.get(j)).isADF()))
						nonADFFunctionByNbArg[i].add(functionTable.get(j));
				}
			}
		}
		
		if(argumentType.usingStandards()){
			functionByType[argumentType.ANY].addAll(functionTable);
			if(ADFR != null)
				if(ADFR.getNbOfADFs() != 0)
					nonADFFunctionByType[argumentType.ANY].addAll(nonADFFunctionTable);
		}
	}
	
	public int getSize(){
		return functionTable.size();
	}
	
	public Function getFunction(){
		int size = functionTable.size();
		if(size>0)
			return (Function) functionTable.get((int)(Math.random() *(double)size));
		else
			return null;
	}
	
	public Function getFunctionByType(int argType){
		int size = functionByType[argType].size();
		if(size>0)
			return (Function) functionByType[argType].get((int)(Math.random() * (double)size));
		else
			return null;
	}
	
	public Function getFunctionByNbArg(int wantedNbOfArgs){
		for(int i=0;i<nbArgs.size();i++){
			if( ((Integer)nbArgs.get(i)).intValue() == wantedNbOfArgs){
				int size = functionByNbArg[i].size();
				if(size>0)
					return (Function) functionByNbArg[i].get((int)(Math.random() * (double)size));
				else
					return null;
			}
		}
		return null;
	}
	
	public Function getNonADFFunction(){
		int size = nonADFFunctionTable.size();
		if(size>0)
			return (Function) nonADFFunctionTable.get((int)(Math.random() *	(double)size));
		else
			return null;
	}
	
	public Function getNonADFFunctionByType(int argType){
		int size = nonADFFunctionByType[argType].size();
		if(size>0)
			return (Function) nonADFFunctionByType[argType].get((int)(Math.random() * (double)size));
		else
			return null;
	}

	public Function getNonADFFunctionByNbArg(int wantedNbOfArgs){
		for(int i=0;i<nbArgs.size();i++){
			if( ((Integer)nbArgs.get(i)).intValue() == wantedNbOfArgs){
				int size = nonADFFunctionByNbArg[i].size();
				if(size>0)
					return (Function) nonADFFunctionByNbArg[i].get((int)(Math.random() * (double)size));
				else
					return null;
			}
		}
		return null;
	}
	
	public Function getFunctionByString(String argType){
		return getNonADFFunctionByType(argumentType.checkType(argType));
	}
	
	public Object clone(){
		FunctionRules theClone = new FunctionRules();
		theClone.argumentType = (ArgumentType) argumentType.clone();;	
		theClone.nbArgs = (Vector) nbArgs.clone();
		theClone.functionTable = (Vector) functionTable.clone();;
		theClone.functionByType = (Vector[]) functionByType.clone();;
		theClone.functionByNbArg = (Vector[]) functionByNbArg.clone();;
		theClone.nonADFFunctionTable = (Vector) nonADFFunctionTable.clone();;
		theClone.nonADFFunctionByType = (Vector[]) nonADFFunctionByType.clone();;
		theClone.nonADFFunctionByNbArg = (Vector[]) nonADFFunctionByNbArg.clone();;
		return theClone;
	}
	
	public String toString(){
		String s = "";
		s += argumentType.toString();
		s += "Function Table : " + functionTable.toString() + "\n";
		return s;
	}

}
