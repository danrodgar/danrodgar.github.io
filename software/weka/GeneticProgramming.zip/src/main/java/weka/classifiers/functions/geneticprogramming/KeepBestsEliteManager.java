package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class KeepBestsEliteManager extends EliteManager implements java.io.Serializable {
	
	public KeepBestsEliteManager(int nbBests){
		super(nbBests);
	}

	public void manageElite(Vector population, FitnessEvaluator FE, ProgramRules PR, Instances trainIns, double pV) {
		addAndSortPrograms(population, FE, pV);
	}
	
	public Object clone(){
		return new KeepBestsEliteManager(eliteSize);
	}
	
	public String toString(){
		return ("Keep Bests Elite Manager : keeps " + eliteSize + " best programs since beginning of run in memory.");
	}
	
	public void add(Program P, ProgramRules PR, Instances trainIns){
		elite.add(P);
	}

}
