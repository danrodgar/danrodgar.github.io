package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.GeneticProgramming;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import weka.core.*;

public class GPExperimentController extends Observable implements java.io.Serializable, Observer{
	
	private int eliteSize;
	private int problemType;
	private int nbOfExperiments;
	private GPExperiment theExp;
	private double classWeight[];
	private double programWeight[][];
	private EliteManager eliteManager[];
	private double sumOfProgramWeights[];
	private DataPreProcessor dataPreProcessor;
	private FitnessEvaluator fitnessEvaluator[];
	private GeneticParameters geneticParameters;

	private Instances fullIns;
	private Instances trainingIns;
	private Instances validationIns;
    
	private boolean useClassWeights;
	private String completionParameters;
	private String completionMessage[][];
	private CompletionManager completionManager; 
    
    public GPExperimentController(int nbExp, GeneticParameters gP, EliteManager EM,
    		FitnessEvaluator[] FE, CompletionManager CM, boolean useClassW, int probType){
 
    	problemType = probType;
    	fitnessEvaluator = FE;
       	geneticParameters = gP;
    	completionManager = CM;
    	
    	if(problemType == GeneticProgramming.REGRESSION){
    		useClassWeights = false;
    		eliteSize = 1;
    	}else{
    		useClassWeights = useClassW;
    		eliteSize = EM.getEliteSize();
    	}
    	
    	nbOfExperiments = nbExp;
    	completionParameters = completionManager.toString();
		dataPreProcessor = geneticParameters.getDataPreProcessor();

    	eliteManager =  new EliteManager[nbOfExperiments];
    	for (int i=0;i<nbOfExperiments;i++)
    		eliteManager[i]= (EliteManager) EM.clone();
    	classWeight = new double[nbOfExperiments];
    	programWeight = new double [nbOfExperiments][eliteSize];
    	    	
        completionMessage = new String[nbOfExperiments][eliteSize];

    }
    
    public void run(Instances instances){ // Without multi-thread
    	
    	ProgramRules PR = geneticParameters.getProgramRules();
    	GPExperiment currentExperiment;
    	boolean popToCreate = false;
    	
    	for(int i=0;i<nbOfExperiments;i++){
    		
	        geneticParameters.setFitnessEvaluator(fitnessEvaluator[i]);
	        currentExperiment = newExperiment(instances);
	        
    		for(int j=0;j<eliteSize;j++){
		        
	    		int currentGeneration = 0;
		        completionManager.start();   
		        geneticParameters.getEliteManager().reset();
		        
		        double fitnessAttained;
		        do{
		        	if((currentGeneration == 0 && j == 0) || popToCreate){
			        	currentExperiment.createPopulation();
						currentGeneration ++;
						popToCreate = false;
					}else{	
						currentExperiment.oneGeneration();	
						currentGeneration ++;
					}
			        fitnessAttained = currentExperiment.getBestProgram().getFitness();
				}while(!completionManager.isCompleted(currentGeneration, 
						fitnessAttained, geneticParameters.getFitnessEvaluator()));
		        
		        Program P = currentExperiment.getBestProgram().clone(PR);
		        P.simplify(PR, fullIns);
		        
		        if(problemType == GeneticProgramming.CLASSIFICATION)
		        	setInstancesWeights(i, fitnessEvaluator[i], trainingIns, validationIns, P, problemType);
		        
		        eliteManager[i].add(P, PR, trainingIns);

		        if(problemType == GeneticProgramming.CLASSIFICATION){
		        	if(P.getError() <= 0.000001){
		        		currentExperiment = newExperiment(instances);
		        		popToCreate = true;
			        }else{
			        	currentExperiment.recomputePopulationFitness();
			        }
		        }
		        	
		        completionMessage[i][j] = completionManager.getEndMessage();
		        
	    	}
        	theExp = currentExperiment;
    	
    	}
    	if(problemType == GeneticProgramming.CLASSIFICATION)
    		setWeights();
    	else if(problemType == GeneticProgramming.REGRESSION)
    		eliteManager[0].getEliteProgram(0).computeErrorRegression(validationIns);
    }
    
	private GPExperiment newExperiment(Instances instances){
	    GPExperiment newExperiment = new GPExperiment(geneticParameters, instances);
	    newExperiment.prepareDataSets();
	    
	    fullIns = newExperiment.getFullInstances();
		trainingIns = newExperiment.getTrainingInstances();
		validationIns = newExperiment.getValidationInstances();
		
		initializeInstancesWeights(trainingIns,validationIns);
		return newExperiment;
	}
    
    private void setWeights(){
    	
    	sumOfProgramWeights = new double[nbOfExperiments];
    	
		for(int i=0;i<nbOfExperiments;i++){
			classWeight[i] = 0.0;
			sumOfProgramWeights[i] = 0.0;
		    for(int j=0;j<eliteSize;j++){
		    	Program P = eliteManager[i].getEliteProgram(j);
		    	double e = P.getError();
		    	if(e >= 0.5)
		    		programWeight[i][j] = 0;
		    	else if(e == 0.0)
		    		programWeight[i][j] = -Math.log(0.000001);
		    	else
		    		programWeight[i][j] = -Math.log(e/(1-e));
		    	
		    	sumOfProgramWeights[i] += programWeight[i][j];
		    }
		}
		
		if(useClassWeights){
			double score[];
	    	double shouldBeBestScore;
	    	double step = 1.0 / (double) fullIns.numInstances();
	    	
			Enumeration enu = fullIns.enumerateInstances();		
			while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
				score = mesureScore(instance);
	            int theClass = (int)instance.classValue();
	            shouldBeBestScore = score[theClass];
	        	for(int i=0;i<nbOfExperiments;i++)
	       		 	if(score[i] > shouldBeBestScore)
	       		 		classWeight[i] -= step; // wrong !
	       		 	else
	       		 		classWeight[i] += step; // wrong but has to rise!
			}
			
			for(int i=0;i<nbOfExperiments;i++){
				if(classWeight[i] < 0)
					classWeight[i] = 0.0;
				else
					classWeight[i] = Math.pow(classWeight[i],5);
			}
		}
    }
    
    public double classifyInstance(Instance instance){
    	
    	if(dataPreProcessor != null)
    		dataPreProcessor.preProcessInstance(instance);
    	
    	if(problemType == GeneticProgramming.REGRESSION)
    		return eliteManager[0].getEliteProgram(0).execute(instance.toDoubleArray());
    	
		int chosenClass = 0;
		boolean everythingNull = true;
		double max = Double.NEGATIVE_INFINITY;
		double minSumProgramWeight = Double.POSITIVE_INFINITY;
		
		double sumProgramWeight = 0.0;
		double score[] = mesureScore(instance);	
		
		for(int i=0;i<nbOfExperiments;i++){
			if(useClassWeights)
				score[i] = score[i] * classWeight[i];
			
			if(score[i] == 0.0 && everythingNull){ // In order to choose when everything is null (scores = 0.0)
				
				double mPW = sumOfProgramWeights[i];
				if(mPW < minSumProgramWeight){ 
					chosenClass = i; // We use the class which has less confidence of not being the class
					// chosenClass = -1; // Reject decision because of ambiguous information
					minSumProgramWeight = mPW;
				}		
				
			}else if(score[i] > max){ // Best scores indicates class
				
				everythingNull = false;
				max = score[i];
				chosenClass = i;
				sumProgramWeight = sumOfProgramWeights[i];		
				
			}else if(score[i] == max){ // In order to choose when there is egality (at score = 1.0)
				
				everythingNull = false;

				if(sumOfProgramWeights[i] > sumProgramWeight){ // We use classifier with highest class weight
					max = score[i];
					chosenClass = i;
					sumProgramWeight = sumOfProgramWeights[i];
				}
					
			}
		}
		return (double)chosenClass;
    }

    
    private double[] mesureScore(Instance instance){
    	double score[] = new double[nbOfExperiments];
    	
    	for(int i=0;i<nbOfExperiments;i++){
    		
    		score[i] = 0.0;
        	for(int j=0;j<eliteSize;j++){
        		score[i] += programWeight[i][j] * fitnessEvaluator[i].measureFitness(instance, eliteManager[i].getEliteProgram(j));
        	}
        	score[i] /= sumOfProgramWeights[i];
        }
    	return score;
    }
    
    private void initializeInstancesWeights(Instances trainIns, Instances valIns){
		
    	Enumeration enu = trainIns.enumerateInstances();		
		
    	while(enu.hasMoreElements()){
			Instance instance = (Instance)enu.nextElement();
            instance.setWeight(1.0);
		}		
    	
    	if(valIns != null){
        	enu = valIns.enumerateInstances();		
    		
        	while(enu.hasMoreElements()){
    			Instance instance = (Instance)enu.nextElement();
                instance.setWeight(1.0);
    		}		
    	}
			
    }
    
   
    private void setInstancesWeights(int classNo, FitnessEvaluator FE, Instances trainIns, Instances valIns, Program program, int probType){
	
		program.computeError(classNo, FE, trainIns, valIns);
    	
    	double error = program.getError();
    	if(error != 0.0){
	    	Enumeration enu = trainIns.enumerateInstances();		
	    	
	    	while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
				double score = FE.measureFitness(instance, program);
				
				if( (score >= 0.5 && instance.classValue() == classNo) || 
						(score < 0.5 && instance.classValue() != classNo) ){
					double w = instance.weight();
					instance.setWeight(w * (error / (1 - error)));
				}
			}		
	    	
	    	if(valIns != null){
		    	enu = valIns.enumerateInstances();		
				
		    	while(enu.hasMoreElements()){
					Instance instance = (Instance)enu.nextElement();
					double score = FE.measureFitness(instance, program);
					
					if( (score >= 0.5 && instance.classValue() == classNo) || 
							(score < 0.5 && instance.classValue() != classNo) ){
						double w = instance.weight();
			            instance.setWeight(w * (error / (1 - error)));
					}
				}	
	    	}
	    	normalizeInstancesWeights(trainIns, valIns);
    	}
    }

    private void normalizeInstancesWeights(Instances trainIns, Instances valIns){
		
    	Enumeration enu = trainIns.enumerateInstances();		
		double totalWeight = 0.0;
		
    	while(enu.hasMoreElements()){
			Instance instance = (Instance)enu.nextElement();
			totalWeight += instance.weight();
		}	
    	
    	enu = trainIns.enumerateInstances();
    	while(enu.hasMoreElements()){
			Instance instance = (Instance)enu.nextElement();
			double w = instance.weight();
            instance.setWeight(w * trainIns.numInstances() / totalWeight);
		}	
    	
    	if(valIns != null){
    		enu = valIns.enumerateInstances();		
    		totalWeight = 0.0;
    		
        	while(enu.hasMoreElements()){
    			Instance instance = (Instance)enu.nextElement();
    			totalWeight += instance.weight();
    		}	
        	
        	enu = valIns.enumerateInstances();
        	while(enu.hasMoreElements()){
    			Instance instance = (Instance)enu.nextElement();
    			double w = instance.weight();
                instance.setWeight(w * valIns.numInstances() / totalWeight);
    		}	
    	}
    }
    
    public String toString(){
    	String result = "";
    	
    	result += "Creation of a multiclass classifier from multiple one-class classifier (multiple GP runs).\n";
		
		for(int i=0;i<nbOfExperiments;i++){
			
			if(problemType != GeneticProgramming.REGRESSION)
				result += "\n*** CLASS " + theExp.getClassName(i) + " ***\n";

	    	for(int j=0;j<eliteSize;j++){
				result += "\n" + completionMessage[i][j] ;
	    		Program program = eliteManager[i].getEliteProgram(j);
	    		String validation = "";
	    		if(validationIns != null)
	    			validation = ", validation fitness = " + program.getValidationFitness();
	    		
	    		result += "\nElite program no."+ j + ", size = " + program.getSize() 
	    		+ ", training fitness = " + program.getTrainingFitness() + validation + "\n" +
	    		"Error = " + program.getError() + "\n";
	    		result += program.toString(theExp.getInputNames(), theExp.getClassName(),
	    				geneticParameters.getProgramRules()) + "\n";
	    	}
			result += "\n";
		}
		
		if(problemType == GeneticProgramming.CLASSIFICATION){	
			int last = eliteSize - 1;
			result += "\nWeights from orchestration of programs\n";
			for(int k=0;k<nbOfExperiments;k++){
				result += "\n\t Program weights for class " + k + " :\t";
				for(int j=0;j<last;j++)		{result += "PW" + k + "-" + j + "=" + programWeight[k][j] + ",\t";}
				result += "PW" + k + "-" + last + "=" + programWeight[k][last];
			}
			
			if(useClassWeights){
				last = nbOfExperiments - 1;
				result += "\n\t Class weights :\t";
				for(int j=0;j<last;j++){result += "CW" + j + "=" + classWeight[j] + ",\t";}
				result += "CW" + last + "=" + classWeight[last];
			}
		}
			
		return theExp.toString() + "\n" + completionParameters + "\n\nGenetic run finished. "
		+  "\n" + result;
		
    }
    
	public void update(Observable o, Object arg) {
    	// String message = (String) arg;
    	// System.out.println("GeneticProgramming.update().  message=" + message + "  objet=" +o);
    	if (arg=="generation completed"){
    		System.out.println("Generation completed");
    		// put graph up to date here
    		// GPExperiment GPE = (GPExperiment) o;   	    
    	}else if (arg=="state changed"){
    		//System.out.println("new state:" + ((GPController)o).getState());
    		GPController GPC = (GPController) o;
    		if (GPC.getState() == GPController.COMPLETED ){
    			// buildComplete[GPC.getExperimentNumber()] = true;
    		}
    	}
	}
	
}
