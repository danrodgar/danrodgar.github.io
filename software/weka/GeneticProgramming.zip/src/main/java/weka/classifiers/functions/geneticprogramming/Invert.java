package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Invert extends Function {
	
	public Invert(ArgumentType AT){
		super(AT);
		name = "!";
		functionType = AT.checkType("Test");
		
		nbArgs = 1;
		argTypes = new int[nbArgs];
		argTypes[0] = AT.checkType("Test");	
	}
	
	public double execute(double argVal[]){
		if(argVal[0] == (double)0.0)
			return (double) 1.0;
		else
			return (double) 0.0;
	}
	/*		
	case Constants.POWER:
		return Math.pow(argVal[0], argVal[1]);
	case Constants.ADF:
		
	default:
		return 0;
		// To change later to accomodate user defined
		// functions... (if necessary)
	}*/
}
