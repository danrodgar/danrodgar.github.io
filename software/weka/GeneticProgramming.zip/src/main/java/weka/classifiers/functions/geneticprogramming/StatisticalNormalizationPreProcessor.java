package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.DataPreProcessor;
import weka.core.Instances;

public class StatisticalNormalizationPreProcessor extends DataPreProcessor {

	double mean[];
	double standardDeviation[];
	
	public double computeNormalizedValue(int index, double inputValue){
		return ((inputValue - mean[index]) / standardDeviation[index]);
	}
	
//	 Prepare the pre-processing of the data by retrieving max and mins
//	 also stores the instances' adress for later comparison
	public void prepareProcessor(Instances ins) {
		instances = ins;
		double buff;
		int numInstances = instances.numInstances();
		int numAttributes = instances.numAttributes() - 1;
		int i,j;
		
		mean = new double[numAttributes];
		standardDeviation = new double[numAttributes];
		
		// put everything to zero
		for (j = 0; j < numAttributes; j++){
			mean[j] = 0.0;
			standardDeviation[j] = 0.0;
		}
		
		// compute sum for each attribute
		for (i = 0; i < numInstances; i++)
			for (j = 0; j < numAttributes; j++)
				mean[j] += instances.instance(i).value(j);
		
		// compute mean for each attribute
		for (j = 0; j < numAttributes; j++)
			mean[j] = mean[j] / ((double)numInstances);
		
		// compute sum of squared distance for each attribute
		for (i = 0; i < numInstances; i++)
			for (j = 0; j < numAttributes; j++) {
				buff = instances.instance(i).value(j);
				standardDeviation[j] += Math.pow((buff - mean[j]),2.0);
			}
		
		for (j = 0; j < numAttributes; j++)
			standardDeviation[j] = Math.sqrt(standardDeviation[j] / ((double)numInstances));
	}
	
	public Object clone(){
		return new StatisticalNormalizationPreProcessor();
	}
	
	public String toString(){
		return new String("Statistical Normalization Pre-processor : normalizes data to have mean = 0.0 " +
				"and standard deviation = 1.0");
	}

}
