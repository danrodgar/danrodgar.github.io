/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.Function;
import weka.classifiers.functions.geneticprogramming.FunctionCall;
import weka.classifiers.functions.geneticprogramming.FunctionRules;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FunctionCall extends Content implements Serializable, Cloneable {
	
	protected Function fct;
	
	public FunctionCall(){
		fct = null;
	}
	
	public FunctionCall(FunctionRules FR, int wantedArgumentType){
		fct = FR.getFunctionByType(wantedArgumentType);
	}
	
	public void setFunctionCallByType(FunctionRules FR, int wantedArgumentType){
		fct = FR.getFunctionByType(wantedArgumentType);
	}
	
	public void setFunctionCallByString(FunctionRules FR, String argType){
		fct = FR.getFunctionByString(argType);
	}
	
	public void setFunctionCallByNbArg(FunctionRules FR, int nbArgs){
		fct = FR.getFunctionByNbArg(nbArgs);
	}

	public FunctionCall(Function f){
		fct = f;
	}
	
	public Function getFunction(){
		return fct;
	}
	
	public Object getContent(){
		return fct;
	}

	public void setFunction(Function f){
		fct = f;
	}
	
	public int nbOfChildren(){
		return fct.getNbArgs();
	}
	
	public int getTypeOfArg(int argNumber){
		return fct.getTypeOfArg(argNumber);
	}
	
	// Clone
	public Object clone(){
		return new FunctionCall(fct);
	}
	
	// Evaluation of the Node.
	public double execute(Program program, double inputArgs[], double args[]){
		return fct.execute(args);
	}
	
	// Management of text format output.
	public String toString(String inputString[], String classNames[], int nbChild, String childString[]){
		String outputString;
		outputString = fct.toString() + "( " + childString[0];
		for (int i = 1; i < nbChild; i++)
			outputString = outputString + ", " + childString[i];
		outputString = outputString + " )";
		return outputString;
	}	
	
	// Management of text format output.
	public String toStringADF(int nbChild, String classNames[], String childString[]){
		return toString(null, classNames, nbChild, childString);
	}
}
