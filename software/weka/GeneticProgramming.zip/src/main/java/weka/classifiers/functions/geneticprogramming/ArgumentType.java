/*
 * Created on Dec 3, 2004
 */
package weka.classifiers.functions.geneticprogramming;

/**
 * @author Yan Levasseur
 *
 * This class serves for the management of Argument
 * Types in function definition, and call to function
 * as argument of another function.
 * 
 * PUT IN FUNCTION RULES CLASS
 *
 */

public class ArgumentType implements java.io.Serializable {

	public final int ARITHMETIC = 0;
	public final int TEST = 1;
	public final int ANY = 2;
	
	public final String ARITHMETICSTRING = "Arithmetic";
	public final String TESTSTRING = "Test";
	public final String ANYSTRING = "Any";
	
	private String argTypeNames[] = null;
	private int nbOfArgumentTypes = 0;
	private boolean usingStandards;

	public ArgumentType(){
		nbOfArgumentTypes = 3;
		argTypeNames = new String[3];
		argTypeNames[ARITHMETIC] = ARITHMETICSTRING;
		argTypeNames[TEST] = TESTSTRING;
		argTypeNames[ANY] = ANYSTRING;
		usingStandards = true;
	}
	
	public void setArgumentTypes(int n, String s[]){
		nbOfArgumentTypes = n;
		argTypeNames = new String[n];
		for(int i=0;i<n;i++)
			argTypeNames[i] = s[i];
		usingStandards = false;
	}

	public int checkType(String s){
		for(int i=0;i<nbOfArgumentTypes;i++)
			if(s==argTypeNames[i])
				return i;
		return -1;
	}

	public String getNames(){
		String namesString = "";
		for(int i=0;i<nbOfArgumentTypes;i++){
			namesString = namesString +	argTypeNames[i] + ", ";
		}
		return namesString;
	}

	public String getName(int i){
		return argTypeNames[i];
	}

	public int getNoOfArgumentType(){
		return nbOfArgumentTypes;
	}
	
	public boolean usingStandards(){
		return usingStandards;
	}
	
	public Object clone(){
		ArgumentType theClone = new ArgumentType();
		theClone.argTypeNames = (String[])argTypeNames.clone();
		theClone.nbOfArgumentTypes = nbOfArgumentTypes;
		theClone.usingStandards = usingStandards;
		return theClone;
	}
	
	public String toString(){
		String s = "";
		s += "Arguments types : " + getNames() + "\n";
		return s;
	}

}
