package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneNode;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramTree;
import weka.core.Instances;

/**
 * @author Yan Levasseur
 *
 * This class is the "header" of a whole genetic
 * program tree. */
public class ProgramTree extends Program {

// 	Link to the first node of the program
	protected GeneNode firstNode;
   	
	public ProgramTree(){
		trainingFitness = 0;
	}
	
// Methods for Program Tree creation
    public void growInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
    	size = firstNode.growInit(PR);
    	computeFitness(trainIns, valIns, fe, valProp);
    }
    
    public void fullInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
    	size = firstNode.fullInit(PR);
    	computeFitness(trainIns, valIns, fe, valProp);
    }
    
    public Program clone(ProgramRules PR){
    	return new ProgramTree(this, PR);
    }
    
//  A copy Constructor for use with clone method
    public ProgramTree(ProgramTree program, ProgramRules PR){
    	trainingFitness = program.trainingFitness;
    	validationFitness = program.validationFitness;
    	totalFitness = program.totalFitness;
    	error = program.error;			
    	wasValidated = program.wasValidated;
    	size = program.size;
     	
// Construction of the program itself, recursively by its GeneNodes
        firstNode = (GeneNode) program.firstNode.clone();   
    }
        
// Use GeneNode's recompute method with level of parent = 0. 
    public void recompute() {
        size = firstNode.recompute(0);
    }
    
// Crossover with wrong Program Type
    public void crossover(ProgramRules PR, Program otherProgram, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp) throws Exception{
    	if(this.getClass()!=otherProgram.getClass()){
    		Exception e = new Exception("Trying to cross programs of two diffent types!");
    		throw e;
    	}
   		crossover(PR, (ProgramTree)otherProgram, fe, trainIns, valIns, true, valProp);
    }
    
// The actual crossover method
    public void crossover(ProgramRules PR, ProgramTree otherProgram, FitnessEvaluator fe, Instances trainIns, Instances valIns, boolean ok, double valProp){

    	GeneNode crossoverPoints[];    	
    	crossoverPoints = selectNodesForCrossover(PR.getMaxDepth(), otherProgram);
    	
    	crossoverPoints[0].switchNode(this, otherProgram, crossoverPoints[1]);
				
		recompute();
		computeFitness(trainIns, valIns, fe, valProp);
    	
		otherProgram.recompute();
		otherProgram.computeFitness(trainIns, valIns, fe, valProp);
    }
     
    public GeneNode[] selectNodesForCrossover(int maxDepth, ProgramTree otherProgram){
//    	 Assuring that each crossover will not make program ecceed maximum depth specified by user
    	GeneNode crossoverPoints[] = new GeneNode[2];
    	GeneNode firstCrossoverPoint, secondCrossoverPoint;
    	
    	int firstProgramDepth = firstNode.getSubDepth() + 1;
		int secondProgramDepth = otherProgram.firstNode.getSubDepth() + 1;
    	int firstSubDepth, secondSubDepth, firstMaxSubDepth, secondMaxSubDepth;
		
    	do{
    		firstCrossoverPoint = firstNode.getRandomNode();
    		secondCrossoverPoint = otherProgram.firstNode.getRandomNode();
    		firstSubDepth = firstCrossoverPoint.getSubDepth();
    		secondSubDepth = secondCrossoverPoint.getSubDepth();
    		firstMaxSubDepth = maxDepth - firstProgramDepth + firstSubDepth;
    		secondMaxSubDepth = maxDepth - secondProgramDepth + secondSubDepth;
    		}while(secondSubDepth > firstMaxSubDepth || firstSubDepth > secondMaxSubDepth);
    	crossoverPoints[0] = firstCrossoverPoint;
    	crossoverPoints[1] = secondCrossoverPoint;
    	return crossoverPoints;
    }
    
// Actual mutation method (whole sub-tree is mutated)
    public void mutation(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns,  double valProp){
    	firstNode.getRandomNode().mutate(PR);
    	
    	recompute();
    	computeFitness(trainIns, valIns, fe, valProp);
    }
    
// Mutation method where only one node is mutated
    public void mutationNodeOnly(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
    	getFirstNode().getRandomNode().mutateNode(PR);
    	
    	recompute();
    	computeFitness(trainIns, valIns, fe, valProp);
    }
    
    public void simplify(ProgramRules PR, Instances instances){
    	firstNode.simplify(this, PR, instances);
    	recompute();
    }
            
    public double execute(double inputArgs[]){
    	return firstNode.execute(this, inputArgs);
    }
    
    public void setFirstNode(GeneNode node){
    	firstNode = node;
    }

// Standard "get" methods
    public int getSize(){
    	return firstNode.getSize();
    }
    
    public GeneNode getRandomNode(){
    	return firstNode.getRandomNode();
    }
    
    public GeneNode getFirstNode(){
    	return firstNode;
    }
    
    public String toString(){
    	String validation = "";
    	if(wasValidated){
    		validation = "Validation Fitness = " + validationFitness + "\n";
    	}
    	
    	return ("\nTraining Fitness = " + trainingFitness + "\n" +
    			validation + "Error = " + error + "\n" +
    			"Size = " + size + "\n" +
    			firstNode.toString());
    }
    
//  Use GeneNode's toString method and to print recursively.
     public String toString(String inputNames[], String classNames[], ProgramRules PR) {
         return firstNode.toString(inputNames, classNames);
     }

}
