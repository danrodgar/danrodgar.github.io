package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Multiply extends Function {
	
	public Multiply(ArgumentType AT){
		super(AT);
		name = "*";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		argTypes[0] = AT.checkType("Arithmetic");
		argTypes[1] = AT.checkType("Arithmetic");	
	}
	
	public double execute(double argVal[]){
		return argVal[0] * argVal[1];
	}

}
