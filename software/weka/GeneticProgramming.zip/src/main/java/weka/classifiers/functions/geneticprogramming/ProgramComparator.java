package weka.classifiers.functions.geneticprogramming;
import java.util.Comparator;

import weka.classifiers.functions.geneticprogramming.Program;

public class ProgramComparator implements Comparator {

	private int dataType;
	private boolean isInversed;
	double proportionValidation;
	
	public static int PROGRAM = 0;
	public static int POSITION = 1;
	
	public ProgramComparator(int dType, double propVal, boolean isInv){
		dataType = dType;
		isInversed = isInv;
		proportionValidation = propVal;
	}
	
	public int compare(Object arg0, Object arg1) {
		try{
			Program p1 = null, p2 = null;
			int result;
			
			if(dataType == PROGRAM){
				p1 = (Program) arg0;
				p2 = (Program) arg1;
			}else if(dataType == POSITION){
				p1 = ((ProgramPosition) arg0).getProgram();
				p2 = ((ProgramPosition) arg1).getProgram();
			}else
				throw new Exception("Problem with data type in comparison.");
			
			double f1 = 0, f2 = 0;
			
			if(proportionValidation <= 0.0){
				f1 = p1.getTrainingFitness();
				f2 = p2.getTrainingFitness();
			}else if(proportionValidation > 0.0){
				f1 = p1.getFitness();
				f2 = p2.getFitness();
			}else
				throw new Exception("Problem with fitness type in comparison.");
			
			result = Double.compare(f1,f2);
			
			if(result == 0){
				return Double.compare(p1.getSize(), p2.getSize());
			}
			
			if(isInversed == true)
				return -result;
			
			return result;
		}
		catch (Exception e){
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public String toString(){
		return new String("Program fitness comparator, compare so that sort gives ASCENDING order.");
	}

}
