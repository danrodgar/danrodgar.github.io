/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ClassChooser;
import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ClassChooser extends Content implements Cloneable, Serializable {

	private int classNo;
	
	public ClassChooser(int nbClasses){
		classNo = (int)(Math.random()*(nbClasses));
	}
	
	public ClassChooser(ClassChooser toCopy){
		classNo = toCopy.classNo;
	}
	
	public int getConstant(){
		return classNo;
	}
	
	public Object getContent(){
		return new Integer(classNo);
	}
	
	public void setClass(int c){
		classNo = c;
	}
	
	public int nbOfChildren(){
		return 0;
	}
	
	public int getTypeOfArg(int argNumber){
		return -1;
	}
	
	// Clone
	public Object clone(){
		return new ClassChooser(this);
	}
	
	// Evaluation of the Node.
	public double execute(Program program, double inputArgs[], double args[]){
		return (double)classNo;
	}

	// Management of text format output.
	public String toString(String inputString[], String classNames[], int nbChild, String childString[]){
		if(classNames == null)
			return "Class " + nf.format(classNo);
		else
			return classNames[classNo] + "(" + classNo + ")";
	}
	
	// Management of text format output.
	public String toStringADF(int nbChild, String classNames[], String childString[]){
		return toString(null,  classNames, nbChild,  childString);
	}
}
