package weka.classifiers.functions.geneticprogramming;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.*;


/**
 * FitnessEvaluators are used to evaluate the fitness of a program over a group of instances.
 * There are many ways to calculate the fitness of a program, and there can be as much classes
 * implmenting this intereface.
 * @author Administrateur
 */
public interface FitnessEvaluator {

	/**
	 * @param ins Groupe d'instances � �valuer
	 * @param prog Programme � �valuer
	 * @return fitness
	 */
	public double measureFitness(Instances ins, Program prog);
	
	/**
	 * @param ins Instance � �valuer
	 * @param prog Programme � �valuer
	 * @return fitness
	 */
	public double measureFitness(Instance ins, Program prog);
		
	/**
	 * Gives the lowest value that this FitnessEvaluator can return when
	 * evaluating the fitness.  Can return an infinite value (see Double class).
	 * @return miminum fitness
	 */
	public Double getInferiorBound();
	

	/**
	 * Gives the highest value that this FitnessEvaluator can return when
	 * evaluating the fitness.  Can return an infinite value (see Double class).
	 * @return maximum fitness
	 */
	public Double getSuperiorBound();
	
	/**
	 * @return true if this classifier's given fitness is better when lower
	 * false when this classifier's given fitness is better when higher
	 */
	public boolean lowerIsBetter();
	
	/**
	 * @return true if this classifier can be used to classify instances with
	 * a nominal (discrete) Class.
	 */
	public boolean isNominal();
	

	/**
	 * @return true if this classifier can be used to classify instances with
	 * a numeric (continuous) class.
	 */
	public boolean isNumeric();
		
		
}
