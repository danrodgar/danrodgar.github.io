package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;

public class TournamentSelector extends ProgramSelector {

	public void prepareRanking(Vector pop, FitnessEvaluator FE, double pV) {
		// Nothing to do !
	}

	public Vector selectPrograms(Vector pop, FitnessEvaluator FE, int number, double pV) {
		Vector programPositions = new Vector();
		int selected, popSize = pop.size();
		
		for(int i = 0;i<number;i++){
			selected =  (int)(Math.random() * (double)popSize);
			programPositions.add(new ProgramPosition(selected, (Program)pop.get(selected)));
		}
		ProgramSelector.sortProgramPositions(programPositions, FE, pV);
		return programPositions;
	}

	public void setParameters(double[] params) throws Exception {
		if(params != null){
			Exception e = new Exception("There are no arguments for FitnessProportionnalSelector.\n");
			throw e;
		}
	}

	public boolean usuallyReplaces() {
		return true;
	}

	public Object clone(){
		return new TournamentSelector();
	}
	
	public String toString(){
		return new String("Tournament Selector : selects programs randomly. We use this selector for " +
				"continuous evolution, replacing worst individuals of tournament with the best individuals'" +
				"offsprings.");
	}


}
