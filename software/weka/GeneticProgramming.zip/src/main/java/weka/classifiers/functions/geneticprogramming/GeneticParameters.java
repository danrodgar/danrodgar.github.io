/*
 * Created on Dec 2, 2004
 */
package weka.classifiers.functions.geneticprogramming;
import java.io.Serializable;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.ADFRules;
import weka.classifiers.functions.geneticprogramming.ClassifierEvaluator;
import weka.classifiers.functions.geneticprogramming.Constant;
import weka.classifiers.functions.geneticprogramming.ContinuousEvolutionController;
import weka.classifiers.functions.geneticprogramming.DataPreProcessor;
import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.EvolutionController;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.FitnessProportionnalSelector;
import weka.classifiers.functions.geneticprogramming.FunctionRules;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.KeepBestsEliteManager;
import weka.classifiers.functions.geneticprogramming.PopulationInitializer;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;
import weka.classifiers.functions.geneticprogramming.ReproductionOperator;
import weka.classifiers.functions.geneticprogramming.SelectAfterEvolutionController;
import weka.classifiers.functions.geneticprogramming.StatisticalNormalizationPreProcessor;
import weka.classifiers.functions.geneticprogramming.TournamentSelector;
import weka.classifiers.functions.geneticprogramming.TreeCrossoverOperator;
import weka.classifiers.functions.geneticprogramming.TreeMutationOperator;
import weka.classifiers.functions.geneticprogramming.TreeNodeMutationOperator;
import weka.classifiers.functions.geneticprogramming.TreePopHalfHalfInitializer;
import weka.core.Instances;

/**
 * @author Yan Levasseur
 *
 * This class contains all information used
 * by a Population to evaluate a specific
 * prediction goal.
 *
 */
public class GeneticParameters implements Serializable {
    
	private DataPreProcessor dataPreProcessor;		// For normalization of the Data
	
	private int populationSize;						// The number of programs in the population
	private double validationProportion;			// Proportion of dataset used for validation
	private ProgramRules programRules;				// Rules for building the programs, including ADF options and functions available
	private FitnessEvaluator fitnessEvaluator;   	// Classifier, ErrorSum, RMSE
	private PopulationInitializer populationInitializer; 	// Full, Growth, Ramped Half and Half
	
	private Vector operators;						// Vector of GeneticOperator (Crossover, Mutation, Reproduction, NewProgram)
	private ProgramSelector programSelector;    	// Roulette, LinearRanking, ExponentialRanking, Tournament
	private EliteManager eliteManager;				// KeepBests, SimplifyBests, SimplifyAndKeepBests
	private EvolutionController evolutionController;		// SelectFirst, SelectAfter, Continuous
	
	public GeneticParameters(){
		dataPreProcessor = null;
		populationSize = 0;
		programRules = null;
		fitnessEvaluator = null;
		populationInitializer = null;
		operators = null;
		programSelector = null;
		eliteManager = null;
		evolutionController = null;
	}
	
    /**
     * Constructor with all parameters in arguments.
     */
    public GeneticParameters(DataPreProcessor dP, int popSize, double valProp, ProgramRules PR,
    		PopulationInitializer chosenPI, Vector chosenOperators,
    		ProgramSelector chosenPS, EliteManager EM, EvolutionController chosenEC){	
    	
    	dataPreProcessor = dP;
    	populationSize = popSize;
    	validationProportion = valProp;
    	programRules = PR;
    	populationInitializer = chosenPI;
    	operators = chosenOperators;
    	programSelector = chosenPS;
    	eliteManager = EM;
    	evolutionController = chosenEC;
    }
    
    /**
     * Constructor with default values. (assuming Classification problem, not continuous)
     */
    public void setParamsForStandardProportionnalGP(int popSize, double valProp, 
    		int depth, int inputs, int classes,
    		double cross, double mutation, double newP) {    	

    	dataPreProcessor = new StatisticalNormalizationPreProcessor();
    	populationSize = popSize;
    	validationProportion = valProp;
    	
    	double percentageInput = 0.5; 			// Input percentage in terminals compared to constant values
    	double percentageFloatConstant = 0.5; 	// Float constants compared to constant equal to class value
    	int numberOfADFs = 0;    	int minNumberOfADFs = 0;    	int maxNumberOfADFs = 0;    	int maxDepthADF = 0;    	
    	
    	ADFRules ADFR = new ADFRules(numberOfADFs, minNumberOfADFs, maxNumberOfADFs, maxDepthADF);
    	FunctionRules FR = new FunctionRules(ADFR);
    	programRules = new ProgramRules(depth, inputs, classes, percentageInput, percentageFloatConstant, ADFR, FR);
    	
    	fitnessEvaluator = new ClassifierEvaluator();
    	populationInitializer = new TreePopHalfHalfInitializer();
    	operators = new Vector();
    	
    	int nbOfParents = 2;    	int nbOfChildrenMade = 2;    	double proportion = cross;
    	TreeCrossoverOperator tournamentCrossover = new TreeCrossoverOperator(nbOfParents, nbOfChildrenMade, proportion);
    	operators.add(tournamentCrossover);
    	
    	nbOfParents = 1;    	nbOfChildrenMade = 1;    	proportion = mutation;
    	TreeMutationOperator tournamentMutation = new TreeMutationOperator(nbOfParents, nbOfChildrenMade, proportion);
    	operators.add(tournamentMutation);
    	
    	nbOfParents = 1;    	nbOfChildrenMade = 1;    	proportion = newP;
       	ReproductionOperator simpleReproduction = new ReproductionOperator(nbOfParents, nbOfChildrenMade, proportion);
    	operators.add(simpleReproduction);
    	
    	programSelector = new FitnessProportionnalSelector();
    	eliteManager = new KeepBestsEliteManager(1);
    	evolutionController = new SelectAfterEvolutionController(popSize);
    }
    
    /**
     * Constructor with some default values for tournament selection
     * (assuming Classification problem, not continuous)
     */
    public void setParamsForStandardTournamentGP(int popSize, double valProp, 
    		int mStyle, int tCross, int tMut,
    		int tNew, double cross, double mutation, double newP, 
    		int depth, int inputs, int classes, double pI, double pFC) {    	
    	
    	dataPreProcessor = new StatisticalNormalizationPreProcessor();
    	populationSize = popSize;
    	validationProportion = valProp;
    	
    	double percentageInput = pI; 			// Input percentage in terminals compared to constant values
    	double percentageFloatConstant = pFC; 	// Float constants compared to constant equal to class value  	
    	
    	int numberOfADFs = 0;    	int minNumberOfADFs = 0;    	int maxNumberOfADFs = 0;    	int maxDepthADF = 0;    	
    	
    	ADFRules ADFR = new ADFRules(numberOfADFs, minNumberOfADFs, maxNumberOfADFs, maxDepthADF);
    	FunctionRules FR = new FunctionRules(ADFR);
    	programRules = new ProgramRules(depth, inputs, classes, percentageInput, percentageFloatConstant, ADFR, FR);
    	
    	fitnessEvaluator = new ClassifierEvaluator();
    	populationInitializer = new TreePopHalfHalfInitializer();
    	operators = new Vector();
    	
    	int nbOfParents = tCross;    	int nbOfChildrenMade = 2;    	double proportion = cross;
    	if(proportion > 0.0){
    		GeneticOperator tournamentCrossover = new TreeCrossoverOperator(nbOfParents, nbOfChildrenMade, proportion);
	    	operators.add(tournamentCrossover);
    	}
    	
    	nbOfParents = tMut;    	nbOfChildrenMade = 1;    	proportion = mutation;
    	if(proportion > 0.0){
	    	if(mStyle == 0){
	    		GeneticOperator tournamentMutation = new TreeMutationOperator(nbOfParents, nbOfChildrenMade, proportion);
		    	operators.add(tournamentMutation);
	    	}else{
	    		GeneticOperator tournamentMutation = new TreeNodeMutationOperator(nbOfParents, nbOfChildrenMade, proportion);
		    	operators.add(tournamentMutation);
	    	}
    	}
    	
    	nbOfParents = tNew;    	nbOfChildrenMade = 1;    	proportion = newP;
    	if(proportion > 0.0){
    		GeneticOperator simpleReproduction = new ReproductionOperator(nbOfParents, nbOfChildrenMade, proportion);
	    	operators.add(simpleReproduction);
    	}
    	
    	programSelector = new TournamentSelector();
    	eliteManager = new KeepBestsEliteManager(1);
    	evolutionController = new ContinuousEvolutionController();	
    }
    
// Two next methods to be implemented later.
    public GeneticParameters(String fileName) {
        // Read info from a file. To be implemented later.
    }

    public boolean saveGeneticParameters(String fileName){
        // Save Genetic Parameters to a text file which
        // can be loaded later.
        return false;
    }

    public void preProcessTrainingData(Instances ins){
    	if(dataPreProcessor != null){
    		dataPreProcessor.prepareProcessor(ins);
    		dataPreProcessor.preProcessInstances(ins);
    	}else{
    		// If no data processor, we will find the maximum value of Data
    		// and use this maximum for random generation of constants
    		
    		double buff;
			int numInstances = ins.numInstances();
			int numAttributes = ins.numAttributes() - 1;
			
			double max[] = new double[numAttributes];

			for (int j = 0; j < (numAttributes); j++) {
				buff = ins.instance(0).value(j);
				max[j] = buff;
			}

			for (int i = 1; i < numInstances; i++) {
				for (int j = 0; j < (numAttributes); j++) {
					buff = ins.instance(i).value(j);
					
				}
			}
			
			double theMax = 0;
			for (int j = 0; j < (numAttributes); j++) {
				if (max[j] > theMax)
					theMax = max[j];
			}
			
			Constant.setMaxValue(theMax);
    	}
    }
    
    public void preProcessTestData(Instances ins){
    	if(dataPreProcessor != null){
    		dataPreProcessor.preProcessInstances(ins);
    	}
    }
    
    public Vector createPopulation(Instances trainIns, Instances valIns){
    	return populationInitializer.createPopulation(populationSize, programRules, fitnessEvaluator, eliteManager, trainIns, valIns, validationProportion);
    }
    
    public Vector oneGeneration(Instances trainIns, Instances valIns, Vector pop){
    	return evolutionController.evolveOneGeneration(trainIns, valIns, pop, fitnessEvaluator, programSelector, eliteManager, operators, programRules, validationProportion);
    }
    
    public Program getBestProgram(Vector pop, Instances trainIns, Instances valIns){
    	if(eliteManager == null){
    		ProgramSelector.sortProgramPopulation(pop, fitnessEvaluator, validationProportion);
			return (Program)pop.get(0);
    	}else{
    		Vector elite = eliteManager.getElite();
    		return (Program)elite.get(0);
    	}
    }
    
    public Vector getElite(){
   		return eliteManager.getElite();
    }
    
    /**
     * Sets the fitness evaluator used to determine the fitness of programs.
     * @param fe
     */
    public void setFitnessEvaluator(FitnessEvaluator fe){
    	fitnessEvaluator = fe; 
    }
    
    /**
     * Creates a new FitnessEvaluator using the name of its class and sets it as the
     * FitnessEvaluator.  Currently there is no support for supplying arguments to the
     * class's constructor, but it can easily be done if needed by using the
     * Constructor class.
     * @see java.lang.Constructor
     * @param classname The fully qualified class name of the fitness evaluator to use.
     * @throws ClassNotFoundException
     */
    public void setFitnessEvaluator(String classname) throws Exception{
    	Class classDesc = ClassLoader.getSystemClassLoader().loadClass(classname);
    	fitnessEvaluator = (FitnessEvaluator) classDesc.newInstance();
    }    

	/**
	 * @param rule The pRule to set.
	 */
	public void setProgramRules(ProgramRules rules) {
		programRules = rules;
	}
	
	public void setEliteManager(EliteManager EM){
		eliteManager = EM;
	}
    
// Get methods.
	public int getPopSize(){
		return populationSize;
	}
	
	public double getValidationProportion(){
		return validationProportion;
	}
	
    public ProgramRules getProgramRules() {
        return programRules;
    }
    
    public FitnessEvaluator getFitnessEvaluator(){
    	return fitnessEvaluator;
    }
    
    public DataPreProcessor getDataPreProcessor(){
    	return dataPreProcessor;
    }
    
    public int getEliteSize(){
    	return eliteManager.getEliteSize();
    }
    
    public EliteManager getEliteManager(){
    	return eliteManager;
    }
    
    public void resetEliteManager(){
    	eliteManager.reset();
    }
    
    public Object clone(){
    	if(dataPreProcessor == null)
    		return new GeneticParameters(null,
        			populationSize, validationProportion, (ProgramRules)programRules.clone(),
        			(PopulationInitializer)populationInitializer.clone(), (Vector)operators.clone(),
        			(ProgramSelector)programSelector.clone(), (EliteManager)eliteManager.clone(),
        			(EvolutionController)evolutionController.clone());
    	else
    		return new GeneticParameters((DataPreProcessor)dataPreProcessor.clone(),
    			populationSize, validationProportion, (ProgramRules)programRules.clone(),
    			(PopulationInitializer)populationInitializer.clone(), (Vector)operators.clone(),
    			(ProgramSelector)programSelector.clone(), (EliteManager)eliteManager.clone(),
    			(EvolutionController)evolutionController.clone());
    }
    
// The classical method. Representing the Genetic Parameters in text format.
    public String toString() {
    	String s = "\n .: Genetic Parameters :. \n\n";
  
    	int i = 1;
    	if(dataPreProcessor != null) s += i + ". " + dataPreProcessor.toString() + "\n";
    	else s += i + ". No data pre processing.\n"; i++;
    	s += i + ". Population size : " + populationSize + "\n"; i++;
    	s += i + ". Proportion of training data kept for validation : " + validationProportion + "\n"; i++;
    	s += i + ". Program rules : " + programRules.toString(); i++;
    	s += i + ". " + fitnessEvaluator.toString() + "\n"; i++;
    	s += i + ". " + populationInitializer.toString()+ "\nType of programs : " +
    		populationInitializer.getProgramTypeString() + "\n"; i++;
    	s += i + ". " + programSelector.toString()+ "\n"; i++;
    	s += i + ". " + eliteManager.toString()+ "\n"; i++;
    	s += i + ". " + evolutionController.toString()+ "\n"; i++;
    	for(int j=0;j<operators.size();i++,j++)
    		s += (i) + ". " + ((GeneticOperator)operators.get(j)).toString()+ "\n";
    	
        return s;
    }

}
