package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;
import java.util.Vector;

public abstract class GeneticOperator implements Serializable {

	protected int nbOfParents;
	protected int nbOfChildren;
	protected double proportion;
	
	public GeneticOperator(int nbParents, int nbChildren, double prop){
		nbOfParents = nbParents;
		nbOfChildren = nbChildren;
		proportion = prop;
	}
	
	public abstract Vector performOperation(ProgramRules PR, Vector inputProgramPositions, FitnessEvaluator fe,
			Instances trainIns, Instances valIns, Vector pop, boolean doReplacement, double valProp);
	
	protected void replace(Vector inputProgramPositions, Vector resultPrograms, Vector pop){
//	     Replaces the last of the input programs vector (sorted in order of fitness) by the 
//  	 programs in the result programs vector, in the population vector
		ProgramPosition toOverWrite;
		int lastParent = nbOfParents - 1;
		int lastChild = nbOfChildren - 1;
		int nbToReplace = Math.min(nbOfParents, nbOfChildren);
		for(int i=0;i<nbToReplace;i++){
			toOverWrite = (ProgramPosition) inputProgramPositions.get(lastParent - i);
			pop.setElementAt(resultPrograms.get(lastChild - i), toOverWrite.getPositionInPopulation());
		}
	}
	
	public int getNbOfParents(){
		return nbOfParents;
	}
	
	public int getNbOfChildren(){
		return nbOfChildren;
	}
	
	public double getProportion(){
		return proportion;	
	}
	
	public String toString(){
		return "\tProportion = " + proportion + "\n" +
			"\tNumber of parents = " + nbOfParents + "\n" +
			"\tNumber of children = " + nbOfChildren;
		
	}
		
}
