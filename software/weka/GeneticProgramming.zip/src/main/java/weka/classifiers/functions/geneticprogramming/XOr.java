package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class XOr extends Function {

	public XOr(ArgumentType AT){
		super(AT);
		name = "Xor";
		functionType = AT.checkType("Test");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		argTypes[0] = AT.checkType("Test");
		argTypes[1] = AT.checkType("Test");	
	}
	
	public double execute(double argVal[]){
		if( (toBoolean(argVal[0]) && !(toBoolean(argVal[1]))) || (!(toBoolean(argVal[0])) && toBoolean(argVal[1])) )
			return (double)1.0;
		else
			return (double)0.0;
	}
}
