package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.EvolutionController;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;
import weka.core.Instances;

public class ContinuousEvolutionController extends EvolutionController {

	public ContinuousEvolutionController(){
		doReplacement = true;
	}
	
	public Vector evolveOneGeneration(Instances trainIns, Instances valIns, Vector pop,
			FitnessEvaluator FE, ProgramSelector PS,
			EliteManager EM, Vector operators, ProgramRules PR, double pV) {
		
		GeneticOperator theOperator;
		int nbOfGeneticOperations = 0, popSize = pop.size(), nbOfParents;
		Vector selectedProgramPositions;
		
		try{
			while(nbOfGeneticOperations < popSize){
				theOperator = getGeneticOperator(operators);
				nbOfParents = theOperator.getNbOfParents();
				PS.prepareRanking(pop, FE, pV);
				selectedProgramPositions = PS.selectPrograms(pop, FE, nbOfParents, pV);
				theOperator.performOperation(PR, selectedProgramPositions, FE, trainIns, valIns, pop, doReplacement, pV);
				nbOfGeneticOperations += theOperator.getNbOfChildren();	
			}
					
		}catch(Exception E){
			E.printStackTrace();
		}
		
		EM.manageElite(pop, FE, PR, trainIns, pV);
		return pop;
	}
	
	public Object clone(){
		return new ContinuousEvolutionController();
	}
	
	public String toString(){
		return new String("Continuous Evolution Controller : replacement of individuals in population " +
				"is made after each genetic operation (ideal for tournament selection).");
	}

}
