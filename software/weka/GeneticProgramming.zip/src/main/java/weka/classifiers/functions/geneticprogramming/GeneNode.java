/*
 * Created on Dec 1, 2004
 *
 */
package weka.classifiers.functions.geneticprogramming;
import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.GeneNode;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramTree;
import weka.core.Instances;

import java.io.Serializable;

/**
 * @author Yan Levasseur
 *
 * The main class for a genetic node or chromosome.
 * This also is the parent class of ADFNode,
 *
 * GeneNode is used to produce tree data structures.
 * Each GeneNode contains data specific to the tree
 * structure and information about its content
 * (see the Content class) for the realization of
 * a program tree.
 *
 */

public class GeneNode implements Serializable, Cloneable{

//	Content of this GeneNode, see Content class for more info
    protected Content nodeContent;

// Info about the sub-tree (which includes the current GeneNode)
    protected int size; // Number of GeneNodes in sub-tree
    protected int level; // Level of current Genenode (1 is root)
    protected int subDepth; // Number of "levels" of sub-tree (0 if no child)

// Info about the surrounding GeneNodes
    protected GeneNode parent; // The parent GeneNode
    protected GeneNode[] arrayNodes; // The "children" GeneNodes

//  Constructor for the first node of a tree
    public GeneNode(){
    	parent = null;
    	level = 1;
    }
    
//  A constructor for tree creation
    public GeneNode(ProgramRules PR, GeneNode theParent) {
        level = theParent.level + 1;
    	parent = theParent;
    }
    
// For creation of a Tree using Grow method
    public int growInit(ProgramRules PR) {
        nodeContent = PR.getContentGrow(level);
        createChildrenGrow(PR);
        return recompute(0);
    }    
    
//  For creation of a Tree using Grow method, with argument type specified
    public void growInit(ProgramRules PR, int argType) {
        nodeContent = PR.getContentGrow(argType, level);
        createChildrenGrow(PR);
    }    
    
// For creation of a Tree using Full method
    public int fullInit(ProgramRules PR) {
        nodeContent = PR.getContentFull(level);
        createChildrenFull(PR);
        return recompute(0);
    }
    
//  For creation of a Tree using Full method, with argument type specified
    public void fullInit(ProgramRules PR, int argType) {
        nodeContent = PR.getContentFull(argType, level);
        createChildrenFull(PR);
    }   
    
//  Used to recursively create children to a node, Grow method
     public void createChildrenGrow(ProgramRules PR){
    	int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0){
 	       arrayNodes = new GeneNode[numNodes];
 	       for (int i = 0; i < numNodes; i++) {
 	           arrayNodes[i] = new GeneNode(PR, this);
 	           arrayNodes[i].growInit(PR, nodeContent.getTypeOfArg(i));
 	       }
        }else
        	arrayNodes = null;
     }
    
// Used to recursively create children to a node, default Full method
    public void createChildrenFull(ProgramRules PR){
    	int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0){
	        arrayNodes = new GeneNode[numNodes];
	        for (int i = 0; i < numNodes; i++) {
	            arrayNodes[i] = new GeneNode(PR, this);
	            arrayNodes[i].fullInit(PR, nodeContent.getTypeOfArg(i));
	        }
        }else
        	arrayNodes = null;
    }

// Using the recursive copy constructor to produce a clone
    public Object clone(){
    	return new GeneNode(this, null);
    }
    
// Internal clone method
    public GeneNode clone(GeneNode newParent){
    	return new GeneNode(this, newParent);
    }
    
// A copy recursive constructor
    public GeneNode(GeneNode toCopy, GeneNode newParent) {
        parent = newParent;
        level = toCopy.level;
        subDepth = toCopy.subDepth;
        size = toCopy.size;
        nodeContent = (Content)toCopy.nodeContent.clone();
        
        int numNodes = toCopy.nodeContent.nbOfChildren();
        if(numNodes>0){
	        arrayNodes = new GeneNode[numNodes];
	        for (int i = 0; i < numNodes; i++) {
	            arrayNodes[i] = (GeneNode)toCopy.arrayNodes[i].clone(this);
	        }
        }else{
        	arrayNodes = null;
        }
    }
    
    /**
     * This method is used to correct the size, level and subDepth members
     * after creation or modification of a program tree (as when we use
     * crossover or mutation for example). It also correct the ADF links after
     * crossover operation.
     * @param parentLevel : the level of the parent node
     * @return size : is used recursively to compute parent size  */
    public int recompute(int parentLevel) {
        level = parentLevel + 1;
                
        int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0) {

            int max = 0;
            int depth = 0;
            int total = 0;

            for (int i = 0; i < numNodes; i++) {

                // This method uses recursivity to "visit" each GeneNode
                // of the program tree.
                total += arrayNodes[i].recompute(level);
                depth = arrayNodes[i].subDepth;
                if (depth > max) {
                    max = depth;
                }
            }
            // subDepth, size and level's values are corrected.
            subDepth = max + 1;
            size = total + 1;
        } else {
            subDepth = 0;
            size = 1;
        }
        return size;
    }


/** This method is used to find a randomly selected GeneNode in a program tree
 *  using the GeneNode's number (from 0 to size-1).
 * @param found : the number of the node I want
 * @return : the GeneNode selected */
    public GeneNode seek(int found) {
        if (found == 0) {
            return this;
        } else {
            for (int i = 0; i < nodeContent.nbOfChildren(); i++) {
            	if(found - arrayNodes[i].size <= 0)     	            	
            		return arrayNodes[i].seek(found-1);
            	else
            		found -= arrayNodes[i].size;
            }
        }
        return null;
    }


 // Method to obtain a random node in this node's sub tree
    public GeneNode getRandomNode() {
        return seek((int) (Math.random() * size));
    }
 
/** This method is used to accomplish the crossover genetic operation.
 * Two GeneNodes are "switched" (with their whole sub-trees) from
 * one genetic program to another. */
    public void switchNode(ProgramTree thisNodeProgram, ProgramTree otherNodeProgram, GeneNode otherNode) {
    	
        int i;
        // Here we identify and switch the two GeneNode's parents.
        if (isRoot()) {
        	thisNodeProgram.setFirstNode(otherNode);
        }else{
            i = -1; while (parent.getNode(++i) != this) {}
            parent.setNode(i, otherNode);
        }

        if (otherNode.isRoot()) {
        	otherNodeProgram.setFirstNode(this);
        }else{
            i = -1; while (otherNode.parent.getArrayNodes()[++i] != otherNode) {}
            otherNode.parent.setNode(i, this);
        }

        // Here we switch the two GeneNode's links to their parent.
        GeneNode tmpParent = parent;
        parent = otherNode.parent;
        otherNode.parent = tmpParent;
    }


    /** This method is used to mutate a whole GeneNode's subtree, full method is default
     *  @param PR : The Program Rule */
    public void mutate(ProgramRules PR) {
    	int i;
    	if(isRoot()){
    		fullInit(PR);
    	}else{
    		i = -1; while (parent.getNode(++i) != this) {}
    		fullInit(PR, parent.getContent().getTypeOfArg(i));
    	}
    }
    
/** This method is used to mutate a GeneNode's content to another content
 *  which has the same number of arguments.
 *  @param PR : The Program Rule */
    public void mutateNode(ProgramRules PR) {
    		nodeContent = PR.getContentByNbArg(nodeContent.nbOfChildren());
    }

/**
 * This method litterally "execute" the GeneNode's content, recursively
 * asking to execute its children to create arguments before execution.
 * @return result of the execution     */
    public double execute(Program program, double inputsArgs[]) {
    	int numNodes = nodeContent.nbOfChildren();
        double childArgs[] = new double[numNodes];
        for (int i = 0; i < numNodes; i++) {
            childArgs[i] = arrayNodes[i].execute(program, inputsArgs);
        }
        return nodeContent.execute(program, inputsArgs, childArgs);
    }

/** This method is used to "simplify" a program tree by
 *  replacing sub-trees which produces the same results when
 *  executed on the whole database. */  
    public void simplify(Program program, ProgramRules PR, Instances instances) {
        double lastValue;
        double newValue = (double) 0.0;
        double[] record;

        int nbOfRecords = instances.numInstances();
        record = instances.instance(0).toDoubleArray();
        lastValue = execute(program, record);

        for (int i = 1; i < nbOfRecords; i++) {
            record = instances.instance(i).toDoubleArray();
            newValue = execute(program, record);

            // If there is a difference in results when executing, we
            // recursively call this method on the children.
            if (newValue != lastValue) {
            	int numNodes = nodeContent.nbOfChildren();
                for (int child = 0; child < numNodes; child++) {
                    arrayNodes[child].simplify(program, PR, instances);
                }
                // The method ends here for this GeneNode.
                return;
            }
            lastValue = newValue;
        }
        // If the result of execution for this GeneNode (and its
        // sub-tree) was the same for the whole database, we replace
        // this GeneNode's content by this result (in constant form)
        // and eliminate the sub-tree.
        arrayNodes = null;
        nodeContent = PR.getConstant(newValue);
    }

// Standard "get" methods
    public int getSize() {
        return size;
    }
    
    public Content getContent(){
    	return nodeContent;
    }

    public int getSubDepth() {
        return subDepth;
    }

    public GeneNode[] getArrayNodes() {
        return arrayNodes;
    }
    
    public GeneNode getNode(int i){
    	return arrayNodes[i];
    }

    public GeneNode getParent() {
        return parent;
    }

// Some "set" methods
    public void setNode(int i, GeneNode node) {
        arrayNodes[i] = node;
    }

// Check if this is the "root" GeneNode.
    public boolean isRoot() {
        return (parent == null);
    }

    public String toString(){
    	return toString(null, null);
    }
    
/** To represent this GeneNode and its whole sub-tree (recursively)
 *  in text form. We use the LISP representation to simplify writing.
 *  
 * @param inputNames : Names of the possible inputs
 * @return : String representing this whole sub-tree in LISP */
    public String toString(String inputNames[], String classNames[]) {
        String childString[] = null;
        int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0) {
            childString = new String[numNodes];
            // Append children to the string.
            for (int i = 0; i < numNodes; i++) {
                childString[i] = arrayNodes[i].toString(inputNames, classNames);
            }
        }
        return nodeContent.toString(inputNames, classNames, numNodes, childString);
    }

}
