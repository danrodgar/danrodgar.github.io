package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.EvolutionController;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;
import weka.core.Instances;

public class SelectFirstEvolutionController extends EvolutionController {
	
	public SelectFirstEvolutionController(){
		doReplacement = false;
	}
	
	// Here we produce enough children to replace the whole population
	public Vector evolveOneGeneration(Instances trainIns, Instances valIns,Vector pop, FitnessEvaluator FE, ProgramSelector PS,
			EliteManager EM, Vector operators, ProgramRules PR, double pV) {

		Vector newPop = new Vector();
		GeneticOperator theOperator;
		int nbOfGeneticOperations = 0, popSize = pop.size(), newPopSize, nbOfParents;
		Vector selectedProgramPositions, newPrograms;
		
		try{
			PS.prepareRanking(pop, FE, pV);
			while(nbOfGeneticOperations < popSize){
				theOperator = getGeneticOperator(operators);
				nbOfParents = theOperator.getNbOfParents();
				selectedProgramPositions = PS.selectPrograms(pop, FE, nbOfParents, pV);
				newPrograms = theOperator.performOperation(PR, selectedProgramPositions, FE, trainIns, valIns, pop, doReplacement, pV);
				nbOfGeneticOperations += theOperator.getNbOfChildren();	
				newPop.addAll(newPrograms);
			}
		
			newPopSize = newPop.size();
			if(newPopSize > popSize){
				newPop.setSize(popSize);
				nbOfGeneticOperations = popSize;
			}
			
		}catch(Exception E){
			E.printStackTrace();
		}
		
		EM.manageElite(newPop, FE, PR, trainIns, pV);
		return newPop;
	}
	
	public Object clone(){
		return new SelectFirstEvolutionController();
	}

	public String toString(){
		return new String("Select First Evolution Controller : we select programs from the current population " +
				"and perform genetic operations on them to create a new generation of programs having the same " +
				"number of programs."); 
	}
}
