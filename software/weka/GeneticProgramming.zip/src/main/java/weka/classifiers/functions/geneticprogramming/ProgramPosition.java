package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.Program;

public class ProgramPosition {
	private int positionInPopulation;
	private Program program;
	
	public ProgramPosition(int pos, Program prog){
		positionInPopulation = pos;
		program = prog;
	}
	
	public int getPositionInPopulation(){
		return positionInPopulation;
	}
	
	public Program getProgram(){
		return program;
	}
		
	public String toString(){
		return new String("Program at position " + positionInPopulation + "\n" + program.toString());
	}


}
