package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class IfThen extends Function {

	public IfThen(ArgumentType AT){
		super(AT);
		name = "If";
		functionType = AT.checkType("Test");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		argTypes[0] = AT.checkType("Test");
		argTypes[1] = AT.checkType("Any");	
	}
	
	public double execute(double argVal[]){
		if(toBoolean(argVal[0]))
			return argVal[1];
		else
			return (double) 0.0;
	}
}
