/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ADFCall;
import weka.classifiers.functions.geneticprogramming.ADFRules;
import weka.classifiers.functions.geneticprogramming.Function;
import weka.classifiers.functions.geneticprogramming.FunctionCall;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ADFCall extends FunctionCall implements Serializable, Cloneable {
	
	private int ADFnumber;
	
	public ADFCall(Function function) {
		fct = function;
		ADFnumber = function.getFunctionNumber();
	}
		
	public Object getContent(){
		return (fct);
	}
	
	public int getADFnumber() {
		return ADFnumber;
	}
	
	// Clone
	public Object clone(ADFRules ADFR){
		return new ADFCall(fct);
	}
	
	// Evaluation of the Node.
	public double execute(Program program, double inputArgs[], double args[]){
		return ((MainProgramTree)program).getADF(ADFnumber).execute(args);
	}

	// Management of text format output.
	public String toString(String inputNames[], int nbChild, String childString[]){
		return "ADF" + ADFnumber;
	}
	
	// Management of text format output.
	public String toStringADF(String inputNames[], int nbChild, String childString[]){
		return "Error : ADF Call in ADF";
	}
}
