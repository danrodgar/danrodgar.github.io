package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticParameters;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.*;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Random;
import java.util.Vector;
import java.util.Collection;

/**
 * @author Yan Levasseur
 *
 * This class represent a whole Genetic Programming Experiment
 * The pool of programs will be used for reproduction
 * and evolution for a purpose. 
 */

public class GPExperiment extends Observable implements java.io.Serializable  {

//	 Information about the population of programs.
	    private Vector population;		// A vector of programs
	    private Vector elite;			// The best programs since beginning

//	 Contains all information about the genetic evolution.
	    private GeneticParameters geneticParameters;

//	 "instances" represent the database
	    private Instances basicInstances;
	    private Instances trainingInstances;
	    private Instances validationInstances;
	    private String inputNames[];
	    private String classNames[];

//	 Some constructors.

	    public GPExperiment(GeneticParameters p, Instances ins) {
	    	geneticParameters = p;
	        population = null;
	        elite = null;
	        basicInstances = new Instances(ins);
	        setInputAndClassNames(basicInstances);
	    }
	    
	    public Object clone(){
	    	GPExperiment theClone = new GPExperiment(geneticParameters, basicInstances);
	    	theClone.trainingInstances = trainingInstances;
	    	theClone.validationInstances = validationInstances;
	    	theClone.inputNames = inputNames;
	    	theClone.classNames = classNames;
	    	
	    	theClone.elite = Program.cloneVectorOfPrograms(elite, geneticParameters.getProgramRules());
	    	return theClone;
	    }
	    
	    public void setDatabases(Instances trainIns, Instances valIns) {
	        trainingInstances = trainIns;
	        validationInstances = valIns;
	    }

	    public void prepareDataSets(){
	    	
	    	basicInstances.randomize(new Random(0));
	    	geneticParameters.preProcessTrainingData(basicInstances);
	    		    	
	    	double validationProportion = geneticParameters.getValidationProportion();
    		int numberOfValidationInstances = (int)(validationProportion * basicInstances.numInstances());
	    	
	    	if(validationProportion <= 0 || numberOfValidationInstances <= 0){
	    		trainingInstances = new Instances(basicInstances);
	    		validationInstances = null;
	    	}else{
	    		validationInstances = new Instances(basicInstances, 0, numberOfValidationInstances);
	    		trainingInstances = new Instances(basicInstances, numberOfValidationInstances, 
	    				basicInstances.numInstances()-numberOfValidationInstances);	    		
	    	}
	    }
	    
	    public void createPopulation(){

	    	population = geneticParameters.createPopulation(trainingInstances, validationInstances);
	    	elite = geneticParameters.getElite();
	    	setChanged(); 
	    }
	    
	    public void oneGeneration(){
	    	population = geneticParameters.oneGeneration(trainingInstances, validationInstances, population);
	    	elite = geneticParameters.getElite();
	    	setChanged(); 
	    }
	    
	    public void recomputePopulationFitness(){
	    	if(population != null){
		    	FitnessEvaluator fe = geneticParameters.getFitnessEvaluator();
		    	double valProp = geneticParameters.getValidationProportion();
		    	for(int i=0;i<population.size();i++){
		    		((Program)population.get(i)).computeFitness(trainingInstances, validationInstances, fe, valProp);
		    	}
	    	}
	    }
	    
	    public void addPopulation(Collection popToAdd){
	    	population.addAll(popToAdd);
	    }
	    
	    public void simplifyWholePopulation(){
	    	int popSize = geneticParameters.getPopSize();
	    	for(int i=0;i<popSize;i++){
	    		((Program)population.get(i)).simplify(geneticParameters.getProgramRules(), basicInstances);
	    		((Program)population.get(i)).recompute();
	    	}
	    }
	    
	    public void setInstances(Instances ins){
	    	basicInstances = ins;
	    }
	    
	    private void setInputAndClassNames(Instances ins){
	    	int numAttributes = ins.numAttributes()-1;
	    	int nbOfClasses;
	    	
	    	boolean isClassificationProblem = basicInstances.attribute(basicInstances.numAttributes()-1).isNominal();
	    	
	    	if(isClassificationProblem)
	    		nbOfClasses = ins.numClasses();
	    	else
	    		nbOfClasses = 0;
	    	
	    	inputNames = new String[numAttributes];
	    	for(int i=0;i<numAttributes;i++)
	    		inputNames[i] = ins.attribute(i).name();
	    	
	    	if(isClassificationProblem){
	    		classNames = new String[nbOfClasses];
	    		Enumeration classesEnum = ins.classAttribute().enumerateValues();
		    	for(int i=0;classesEnum.hasMoreElements();i++)
		    		classNames[i] = (String)classesEnum.nextElement();
	    	}else{
	    		classNames = null;
	    	}
	    }
	    
	    public void end(){
	    	population = null;
		    elite = null;

		    geneticParameters = null;

		    basicInstances = null;
		    trainingInstances = null;
		    validationInstances = null;
		    inputNames = null;
		    classNames = null;
		    deleteObservers();
	    }
	    
	    // Standard get methods.
	    
	    public Instances getTrainingInstances(){
	    	return trainingInstances;
	    }
	    
	    public Instances getValidationInstances(){
	    	return validationInstances;
	    }
	    
	    public Instances getFullInstances(){
	    	return basicInstances;
	    }
	    
	    public String getClassName(int classNo){
	    	return classNames[classNo];
	    }
	    
	    public String[] getClassName(){
	    	return classNames;
	    }
	    
	    public String[] getInputNames(){
	    	return inputNames;
	    }
	    
	    public FitnessEvaluator getFitnessEvaluator(){
	    	return geneticParameters.getFitnessEvaluator();
	    }
	    
	    public int getEliteSize(){
	    	return geneticParameters.getEliteSize();
	    }
	    
	    public Program getBestProgram() {
	        return (Program)elite.get(0);
	    }
	    
	    public double getBestProgramFitness(){
	    	if(validationInstances != null)
				return getBestProgram().getValidationFitness();
			else
				return getBestProgram().getTrainingFitness();
	    }
	    
	    public double getBestProgramTrainingFitness() {
	        return getBestProgram().getTrainingFitness();
	    }
	    
	    public double getBestProgramValidationFitness() {
	        return getBestProgram().getValidationFitness();
	    }
	
	    public Vector getPopulation(){
	    	return population;
	    }
	    
	    public void setPopulation(Vector v){
	    	population = v;
	    }
	    
	    public String getPopulationString(){
	    	String s = "";
	    	int popSize = geneticParameters.getPopSize();
	    	for(int i=0;i<popSize;i++){
	    		s += "\n" + ((Program)population.get(i)).toString(inputNames, classNames, geneticParameters.getProgramRules());
	    	}
	    	return s;
	    }
	    
	    public String getEliteString(){
	    	String s = "";
	    	int size = elite.size();
	    	
	    	for(int i=0;i<size;i++){
	    		Program program = ((Program)elite.get(i));
	    		String validation = "";
	    		if(program.wasValidated())
	    			validation = ", validation fitness = " + program.getValidationFitness();
	    		
	    		s += "\nElite program no."+ i + ", size = " + program.getSize() 
	    		+ ", training fitness = " + program.getTrainingFitness() + validation + "\n";
	    		s += program.toString(inputNames, classNames, geneticParameters.getProgramRules()) + "\n";
	    	}
	    	return s;
	    }

	    public String getBestProgramString() {
	    	Program bestProgram = getBestProgram();
	    	String validation = "";
    		if(bestProgram.wasValidated())
    			validation = ", validation fitness = " + bestProgram.getValidationFitness();
            return("Best Program :"
            		+ "\nSize = " + bestProgram.getSize() + ", training fitness = " + bestProgram.getTrainingFitness()
            		+ validation + "\n" + bestProgram.toString(inputNames, classNames, geneticParameters.getProgramRules()));
	    }

	    public String toString() {
	    	String validation = "";
	    	if(validationInstances!=null)
	    		validation = "\nNumber of instances for validation: " + validationInstances.numInstances();
            return("\nDetails of Genetic Programming Experiment\n"
            		+ "\nDatabase name : " + basicInstances.relationName()
            		+ "\nNumber of attributes : " + basicInstances.numAttributes()
            		+ "\nNumber of instances for training: " + trainingInstances.numInstances()
            		+ validation
            		+ "\n" + geneticParameters.toString());            		
	    }

}
