package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.PopulationInitializer;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class TreePopFullInitializer implements PopulationInitializer, java.io.Serializable {

	public Program createProgram(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double pV){
		MainProgramTree program = new MainProgramTree(PR);
		program.fullInit(PR, fe, trainIns, valIns, pV);
		return program;
	}
	
	public Vector createPopulation(int popSize, ProgramRules PR, FitnessEvaluator fe, EliteManager EM, Instances trainIns, Instances valIns, double pV) {
		Vector pop = new Vector();
		MainProgramTree program;
		for(int i=0;i<popSize;i++){
			program = new MainProgramTree(PR);
			program.fullInit(PR, fe, trainIns, valIns, pV);
			pop.add(program);
		}
		EM.manageElite(pop, fe, PR, trainIns, pV);
		return pop;
	}

	public String getProgramTypeString(){
		return "MainProgramTree";
	}

	public Object clone(){
		return new TreePopFullInitializer();
	}
	
	public String toString(){
		return new String("Tree Population Full Initializer : initializes a population of program trees " +
				"using the Full method, i.e. creating trees with the maximum size.");
	}


}
