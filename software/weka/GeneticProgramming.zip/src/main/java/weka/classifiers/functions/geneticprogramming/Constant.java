/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ADFNode;
import weka.classifiers.functions.geneticprogramming.Constant;
import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Constant extends Content implements Serializable, Cloneable {
	
	private double constant;
	private static double maxValue = 1;
	
	public static void setMaxValue(double mValue){
		maxValue = mValue;
	}
	
	public Constant(double c){
		constant = c;
	}
	
	public Constant(){
		constant = Math.random()*maxValue;
	}
	
	public double getConstant(){
		return constant;
	}
	
	public Object getContent(){
		return new Double(constant);
	}
	
	public void setADF(ADFNode ADFs[]){
	}
	
	public void setConstant(double c){
		constant = c;
	}
	
	public void setConstant(){
		constant = Math.random()*maxValue;
	}
	
	// Clone
	public Object clone(){
		return new Constant(constant);
	}
	
	public int nbOfChildren(){
		return 0;
	}
	
	public int getTypeOfArg(int argNumber){
		return -1;
	}
	
	// Evaluation is a bit different when ADF.
	public double execute(Program program, double inputArgs[], double args[]){
		return constant;
	}

	// Management of text format output.
	public String toString(String inputString[], String classNames[], int nbChild, String childString[]){
		return "Co " + nf.format(constant);
	}
	
	// Management of text format output.
	public String toStringADF(int nbChild, String classNames[], String childString[]){
		return toString(null,  classNames, nbChild,  childString);
	}
}
