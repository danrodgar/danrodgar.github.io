package weka.classifiers.functions.geneticprogramming;
import java.io.Serializable;
import java.util.*;

import weka.classifiers.functions.geneticprogramming.CompletionManager;
import weka.classifiers.functions.geneticprogramming.GPExperiment;
import weka.classifiers.functions.geneticprogramming.GeneticRunThread;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.Instances;

/**
 * Controls the genetic programming algorithms.  User interfaces or other
 * software in need of the genetic evolution framework should interface
 * via this class.  Updates on the state of evolution are transmitted
 * via the observer-observable mechanism.
 * 
 * @author Gabriel Valois
 */
public class GPController extends Observable implements Observer, Serializable {
	
    GeneticRunThread runThread;				//Performs evolution in background
   
    private int currentState=STOPPED;		//Holds the current state of the evolution    
    public static final int RUNNING=1;		//Population is evolving
    public static final int WAITINGPAUSED=2;//Evolution pause is pending
    public static final int PAUSED=3;		//Evolution is paused
    public static final int STOPPED=4;  	//default state
    public static final int COMPLETED=4;	//Evolution goal is attained
    public static final int WAITINGSTOPPED=5;//Evolution stop is pending

    /**
     * Starts the genetic evolution.  A new population is created. 
     */
    public void start(GPExperiment GPE, CompletionManager CM){    	
    	runThread = new GeneticRunThread(GPE, CM);
		runThread.addObserver(this);
		runThread.start();
		
		currentState=RUNNING;
		setChanged();
		notifyObservers("state changed");
	}	
    
	/**
	 * Pauses the genetic evolution.  The current generation will be
	 * completed, then evolution will be paused untill a call to
	 * unpause is issued.
	 */
	public void pause(){
		currentState = WAITINGPAUSED;
		runThread.pause();		
		setChanged();
		notifyObservers("state changed");
	}

	/**
	 * Resumes the genetic evolution, after a call to pause() has
	 * been made. 
	 */
	public void unpause(){
		runThread.unpause();
		currentState = RUNNING;
		setChanged();
		notifyObservers("state changed");
	}
		
	/**
	 * Stops the genetic evolution, once the current generation is
	 * completed. 
	 */
	public void stop(){
		currentState= WAITINGSTOPPED;
		runThread.stopExec();
		setChanged();
		notifyObservers("state changed");
	}
		
	public int getCurrentGeneration(){
		return runThread.getCurrentGeneration();
	}
	
	/**
	 * Sets the instances (in the machine learning sense) that will be used
	 * to learn.
	 * @param instances
	 */
	public Program getBestProgram(){
		return runThread.getBestProgram();
	}
	
	public GPExperiment getGPExperiment(){
		return runThread.getGPExperiment();
	}
	
	/**
	 * Returns the current state of the evolution. See the static
	 * variables of this class, such as RUNNING or PAUSED.
	 * 
	 * @return
	 */
	public int getState(){
		return currentState;
	}
	
	/* (non-Javadoc)
	 * This method is called by the thread when its state changes.  There
	 * is currently no benefit to call this method unless you are the Thread.
	 * @see java.util.Observer#update(java.util.Observable, java.lang.Object)
	 */
	public void update(Observable o, Object param){
		
		// This should always be the case
		if (param==runThread){
			int threadState = runThread.getCurrentState();
			
			switch(threadState){			
			case GeneticRunThread.IDLE:
				currentState = STOPPED;
				setChanged();
				break;
				
			case GeneticRunThread.RUNNING:
				currentState = RUNNING;
				setChanged();
				break;
								
			case GeneticRunThread.PAUSED:
				if (currentState != PAUSED){
					currentState = PAUSED;
					setChanged();
				}
				break;
								
			case GeneticRunThread.STOPPED:
				boolean evolutionComplete = runThread.evolutionCompleted();							
				if (evolutionComplete){
					currentState = COMPLETED;
					setChanged();
				}else{
					currentState = STOPPED;
					setChanged();
				}				
				break;				
			}
		}
		notifyObservers("state changed");
	}
    
	public String getEndMessage(){
		return runThread.getEndMessage();
	}
	
	public String toString(){
		String s = "";
	    s += runThread.toString();
	    return s;
	}
}



