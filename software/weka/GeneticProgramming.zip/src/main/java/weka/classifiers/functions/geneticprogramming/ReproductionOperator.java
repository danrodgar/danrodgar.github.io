package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class ReproductionOperator extends GeneticOperator {

	public ReproductionOperator(int nbParents, int nbChildren, double prob){
		super(nbParents, nbChildren, prob);
	}
	
	/** Here we perform Reproduction operation.
	 *  The first [nb of children] Programs of the program table get reproduced (cloned).
	 *  The children are either returned (if "replace" == false), or
	 *  they replace the last programs of the list (if "replace" == true)  */
	public Vector performOperation(ProgramRules PR, Vector inputProgramPositions, FitnessEvaluator fe,
			Instances trainIns, Instances valIns, Vector pop, boolean doReplacement, double valProp) {
		
		Vector resultPrograms = new Vector();

		// Here we clone the nbOfChildren first program into the results
		for(int i=0;i<nbOfChildren;i++)
			resultPrograms.add( ((ProgramPosition)inputProgramPositions.get(i)).getProgram().clone(PR) );
		
		// Here we replace the last programs of the list with the results
		if(doReplacement){
			replace(inputProgramPositions, resultPrograms, pop);
			return null;
		}
		// Or simply return the result
		return resultPrograms;
	}
	
	public String toString(){
		return new String("Reproduction Operator : produces a clone of selected program for coming generation.\n" + super.toString());
	}

}
