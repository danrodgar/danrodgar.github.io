/*
 * Created on Dec 1, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;


/**
 *
 * This class is used to store the possible functions or
 * operation that can be used by the random Program Tree.
 *
 * This class was built in the idea that the user might easily
 * introduce new functions of its own to the genetic programs...
 * 
 * @author Yan Levasseur
 *
 */

public class Function implements java.io.Serializable{

	protected int fNum;
	protected int nbArgs;
	protected String name;
	protected boolean isADF;
	
	// According to ArgumentType Class
	protected int functionType;
	protected int argTypes[];

	public Function(ArgumentType AT){
		isADF = false;
		nbArgs = 0;
		name = "undef";
		functionType = -1;
		argTypes = null;
	}
	
// Function creation.
	public Function(boolean iADF, int fNumber, int args, int functionT, int argT[], String n){
		isADF = iADF;
		fNum = fNumber;
		nbArgs = args;
		functionType = functionT;
		name = n;

		if(args>0){
			argTypes = new int[args];
			for(int i=0;i<args;i++)
				argTypes[i] = argT[i];
		}
	}

// Function creation with argument types in string format.
	public Function(boolean iADF, int fNumber, int args, String functionT, String argT[], String n, ArgumentType argumentType){
		isADF = iADF;
		fNum = fNumber;
		nbArgs = args;
		functionType = argumentType.checkType(functionT);
		name = n;
		
		if(args>0){
			argTypes = new int[args];
			for(int i=0;i<args;i++)
				argTypes[i] = argumentType.checkType(argT[i]);
		}
	}

	public boolean isADF(){
		return isADF;
	}
	
// Get methods.
	public int getNbArgs(){
		return nbArgs;
	}
	
	public int getFunctionType(){
		return functionType;
	}
	
	public int getFunctionNumber(){
		return fNum;
	}

	public int[] getArgTypes(){
		return argTypes;
	}

	public int getTypeOfArg(int n){
		return argTypes[n];
	}

	public String getName(){
		return name;
	}

// Transform a double to boolean type.
	protected boolean toBoolean(double d){
		return (d != (double) 0.0);
	}
	
// This serves to transform a program tree to text format.
	public String toString(){
			return name;
	}

// For the execution of functions.
	public double execute(double argVal[]){
		return 0.0;
	}
}
