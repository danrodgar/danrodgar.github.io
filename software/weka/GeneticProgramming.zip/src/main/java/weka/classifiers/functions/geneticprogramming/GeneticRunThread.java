package weka.classifiers.functions.geneticprogramming;
import java.io.Serializable;
import java.util.Vector;
import java.util.Observable;
import java.util.Observer; 

import weka.classifiers.functions.geneticprogramming.CompletionManager;
import weka.classifiers.functions.geneticprogramming.GPExperiment;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 *  Supervizes the genetic evolution execution.  A thread allows the evolution
 *  to take place as the rest of the program continues to operate.
 */
class GeneticRunThread extends Thread implements Serializable {

	Vector observers = new Vector();
	
	int currentGeneration = 0;
    GPExperiment experiment;
    CompletionManager cpManager;

	boolean evolutionComplete = false;	//has the genetic goal been attained ?
    private int currentState = 1; 		//last execution state
    private int lastState = 1;			//current execution state, one of next values:    
    public static final int IDLE=1;
    public static final int RUNNING=2;
    public static final int PAUSED=3;
    public static final int STOPPED=4;

    public GeneticRunThread(GPExperiment exp, CompletionManager cM) {
    	experiment = exp;
        cpManager = cM;
        cM.start();
        currentState=IDLE;
        lastState=IDLE;
    }
    
    /**
     * Pauses the thread.  Genetic evolution will temporarily stop
     * until resumed, after the current generation is completed. 
     */
    public void pause(){
    	if( currentState==RUNNING ){
    		lastState=RUNNING;
    		currentState=PAUSED;
    		notifyObservers();
    	}
    }

    /**
     *  Resumes the genetic evolution.  Evolution must be paused for
     *  this command to have an effect. 
     */
    public void unpause(){
    	if (lastState==RUNNING){
    		currentState=RUNNING;
    		lastState=PAUSED;
    		notifyObservers();	
    	}    	
    }
    
    /**
     *  Stop the genetic evolution.  Resuming is not possible.
     *  Evolution must be PAUSED or RUNNING for this command to
     *  have an effect.  If the evolution end criteria is met, as defined
     *  by the CompletionManager, this method will be called.
     */
    public void stopExec(){
    	if(currentState==RUNNING || currentState==PAUSED){
    		// lastState=currentState;	
    		// currentState=STOPPED;
    		notifyObservers();
    	}
    }

    /**
     * Add an observer to this thread object.  Observers will be
     * notified with their update() method called when the state
     * of the execution thread is changed.
     * @param obs The object to be notified when the state changes.
     */
    public void addObserver(Observer obs){
    	observers.add(obs);
    }
    
    /**
     * Notify all observers that the state of the thread has changed.
     * @param param A parameter that will be passed to observers.
     */
    private void notifyObservers(){
    	java.util.Iterator iter = observers.iterator();
    	while(iter.hasNext()){
    		Observer o = (Observer) iter.next();
    		o.update(new Observable(),this);
    		// a new observable object is sent instead of this class
    		// because this class can't extend both Observable and Thread.    		
    	}    	
    }
    
    /**
     * Returns the current state, see this class's constantes for more
     * information.  Note:  This is not the same as Thread.getState.
     * @return state
     */
    public int getCurrentState(){
    	return currentState;
    }
    
    /* (non-Javadoc)
     * Start the evolution. Creates a new population.
     * @see java.lang.Runnable#run()
     */
    public void run() {
		currentState=RUNNING;

		while (currentState==RUNNING  || currentState ==PAUSED) {
			
			// Do nothing if paused
			while (currentState==PAUSED) {
				try {
					notifyObservers();
					sleep(100);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}

			if(currentGeneration == 0){
				//create the initial population
				experiment.prepareDataSets();
				experiment.createPopulation();
				currentGeneration ++;
				experiment.notifyObservers("population created");
			}else{	
				//perform one generation
				experiment.oneGeneration();	
				currentGeneration ++;
				experiment.notifyObservers("generation completed");
			}
			
			//Automatically stop evolution if the completion criteria is met.
			evolutionComplete = cpManager.isCompleted(currentGeneration, experiment.getBestProgramFitness(), experiment.getFitnessEvaluator());			
			if (evolutionComplete){
				currentState=STOPPED;
				evolutionComplete=true;
				notifyObservers();
			}
		}
	}
    
    public boolean evolutionCompleted(){
    	return evolutionComplete;
    }
    
    public int getCurrentGeneration(){
    	return currentGeneration;
    }
    
    public Program getBestProgram(){
    	return experiment.getBestProgram();
    }
	
	public GPExperiment getGPExperiment(){
		return experiment;
	}
    
	public String getEndMessage(){
		return cpManager.getEndMessage();
	}
	
    public String toString(){
    	String s = "";
    	s += "Evolution completed ? = " + evolutionComplete + "\n";
    	s += "Possible states : 1 = idle, 2 = running, 3 = paused, 4 = stopped\n";
    	s += "Current State = " + currentState + "\n";
    	s += "Last State = " + lastState + "\n";
    	s += cpManager.toString();
    	return s;
    }
}
    	  
