package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Power extends Function {

	public Power(ArgumentType AT){
		super(AT);
		name = "Pow";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		return Math.pow(argVal[0], argVal[1]);
	}
}
