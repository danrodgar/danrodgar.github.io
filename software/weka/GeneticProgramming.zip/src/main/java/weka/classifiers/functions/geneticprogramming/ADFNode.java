/*
 * Created on Dec 2, 2004
 */
package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ADFNode;
import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.GeneNode;
import weka.classifiers.functions.geneticprogramming.ProgramRules;

/**
 * @author Yan Levasseur
 *
 * This is an Automatically Defined Function (ADF) Node class.
 * This class is derived from the basic genetic node (GeneNode) to
 * implement ADF functionnality. The ADF is another program
 * tree which is used by the main program tree as a function.
 * It is a function (that can be used multiple time in the
 * main program tree, without re-creating its structure)
 * created by the genetic evolution.
 *
 * (All GeneNodes in an ADF program are ADFNodes.)
 *
 */
public class ADFNode extends GeneNode {
	
//  Constructor for the first node of a tree
    public ADFNode(){
    	level = 1;
    	parent = null;
    }
	
//  A constructor for tree creation
    public ADFNode(ProgramRules PR, GeneNode theParent) {
        level = theParent.level + 1;
        parent = theParent;
    }
    
//  For creation of a Tree using Grow method
    public int growInit(int ADFno, ProgramRules PR) { // WATCH OUT AS THERE ARE TWO SIMILAR METHODS, THIS ONE IS (INT, PROGRAMRULE)
    												  // OTHER FROM GENENODE IS PROGRAMRULE, INT..!!
    	nodeContent = PR.getContentForADFGrow(level, ADFno);
        createChildrenGrow(PR, ADFno);
        return recompute(0);
    }    
    
//  For creation of a Tree using Grow method, with argument type specified
    public void growInit(ProgramRules PR, int argType, int ADFno) {
    	nodeContent = PR.getContentForADFGrow(argType, level, ADFno);
        createChildrenGrow(PR, ADFno);
    }    
        
// For creation of a Tree using Full method
    public int fullInit(int ADFno, ProgramRules PR) { // WATCH OUT AS THERE ARE TWO SIMILAR METHODS, THIS ONE IS (INT, PROGRAMRULE)
		  											  // OTHER FROM GENENODE IS PROGRAMRULE, INT..!!
    	nodeContent = PR.getContentForADFFull(level, ADFno);
        createChildrenFull(PR, ADFno);
        return recompute(0);
    }   

//  For creation of a Tree using Full method, with argument type specified
     public void fullInit(ProgramRules PR, int argType, int ADFno) {
     	nodeContent = PR.getContentForADFFull(argType, level, ADFno);
        createChildrenFull(PR, ADFno);
     }   
     
    private void createChildrenGrow(ProgramRules PR, int ADFno){
    	int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0){
	        arrayNodes = new ADFNode[numNodes];
	        for (int i = 0; i < numNodes; i++) {
	            arrayNodes[i] = new ADFNode(PR, this);
	            ((ADFNode)arrayNodes[i]).growInit(PR, nodeContent.getTypeOfArg(i), ADFno);
	        }
        }else
        	arrayNodes = null;
    }
    
    private void createChildrenFull(ProgramRules PR, int ADFno){
    	int numNodes = nodeContent.nbOfChildren();
        if (numNodes > 0){
	        arrayNodes = new ADFNode[numNodes];
	        for (int i = 0; i < numNodes; i++) {
	            arrayNodes[i] = new ADFNode(PR, this);
	            ((ADFNode)arrayNodes[i]).fullInit(PR, nodeContent.getTypeOfArg(i), ADFno);
	        }
        }else
        	arrayNodes = null;
    }
    
//  Using the recursive copy constructor to produce a clone
    public Object clone(){
    	return new ADFNode(this, null);
    }
    
// Internal clone method
    public ADFNode clone(ADFNode newParent){
    	return new ADFNode(this, newParent);
    }
    
// A copy recursive constructor
    public ADFNode(ADFNode toCopy, ADFNode newParent) {
        parent = newParent;
        level = toCopy.level;
        subDepth = toCopy.subDepth;
        size = toCopy.size;
        nodeContent = (Content)toCopy.nodeContent.clone();
        
        int numNodes = toCopy.nodeContent.nbOfChildren();
        if(numNodes>0){
	        arrayNodes = new ADFNode[numNodes];
	        for (int i = 0; i < numNodes; i++) {
	            arrayNodes[i] = (ADFNode)((ADFNode)toCopy.arrayNodes[i]).clone(this);
	        }
        }else{
        	arrayNodes = null;
        }
    }
    
    /** This method is used to mutate a whole GeneNode's subtree, full method is default
     *  @param PR : The Program Rule */
    public void mutate(ProgramRules PR, int ADFno) {
    	if(isRoot()){
    		fullInit(ADFno, PR);
    	}else{
	    	int i;
	    	i = -1; while (parent.getArrayNodes()[++i] != this) {}
	    	fullInit(PR, parent.getContent().getTypeOfArg(i), ADFno);
    	}
    }
     
     /** This method is used to mutate a GeneNode's content to another content
      *  which has the same number of arguments.
      *  @param PR : The Program Rule */
         public void mutateNode(ProgramRules PR, int ADFno) {
       		nodeContent = PR.getContentForADFByNbArg(nodeContent.nbOfChildren(), ADFno);
         }
	     
	// Same as GeneNode but adapted to ADF text output
	 public String toString(String classNames[]) {
	     String childString[] = null;
	     int numNodes = nodeContent.nbOfChildren();
	     if (numNodes > 0) {
	         childString = new String[numNodes];
	         // Append children to the string.
	         for (int i = 0; i < numNodes; i++) {
	             childString[i] = arrayNodes[i].toString();
	         }
	     }
	     return nodeContent.toStringADF(numNodes, classNames, childString);
	 }
}
