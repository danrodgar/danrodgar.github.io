package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Log extends Function {
	
	public Log(ArgumentType AT){
		super(AT);
		name = "Log";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 1;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		if(argVal[0] > 0.0)
			return Math.log(argVal[0]);
		else
			return 0.0;
	}
}