package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Add extends Function {
	
	public Add(ArgumentType AT){
		super(AT);
		name = "+";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		return argVal[0] + argVal[1];
	}
}
