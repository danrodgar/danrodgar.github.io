package weka.classifiers.functions.geneticprogramming;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Vector;
import java.io.File;

public class ProgramsToSave implements Serializable {
	
	private int numberOfClusters;
	private int classNumber = -1;
	private int count = 0;
	private Vector[] eliteCluster;
	private DataPreProcessor dataPreProcessor;
	
	public ProgramsToSave(int nb, DataPreProcessor DPP){
		numberOfClusters = nb;
		dataPreProcessor = DPP;
	}
	
	public void setNumberOfClusters(int i){
		numberOfClusters = i;
	}

	public void setDataPreProcessor(DataPreProcessor DPP){
		dataPreProcessor = DPP;
	}
	
	public void setClassNumber(int i){
		classNumber = i;
	}
	
	public void addEliteCluster(Vector elite){
		if(count == 0){
			eliteCluster = new Vector[numberOfClusters];
		}
		eliteCluster[count] = elite;
		count++;		
	}
	
	public void write(FileOutputStream fos){
		try{
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fos);
		objectOutputStream.writeObject(this);
		}catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public int getNumberOfClusters(){
		return numberOfClusters;
	}
	
	public int getClassNumber(){
		return classNumber;
	}
	
	public Vector getElite(int i){
		return eliteCluster[i];
	}
	
	public DataPreProcessor getDataPreProcessor(){
		return dataPreProcessor;
	}
	
}
