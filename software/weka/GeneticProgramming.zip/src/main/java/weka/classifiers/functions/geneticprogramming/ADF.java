package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ADF;
import weka.classifiers.functions.geneticprogramming.ADFNode;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneNode;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramTree;
import weka.core.Instances;

/**
 * @author Yan Levasseur
 *
 * This class is the "header" of a whole Automatically
 * Defined Function (ADF).  *
 */

public class ADF extends ProgramTree implements Serializable, Cloneable {

	// 	Link to the first node of the program
	private int nbOfInputs;
	
	public ADF(ProgramRules PR, int ADFnum){
		nbOfInputs = PR.getADFRules().getNbOfInputsADF(ADFnum);
		firstNode = new ADFNode();
	}
	
//  Methods for Main Program Tree creation
    public void growInit(ProgramRules PR, int ADFnum){
    	size = ((ADFNode)firstNode).growInit(ADFnum, PR);
    }
    
    public void fullInit(ProgramRules PR, int ADFnum){
    	size = ((ADFNode)firstNode).fullInit(ADFnum, PR);
    }
    
	public ADF(ADF toCopy){
		size = toCopy.size;
		nbOfInputs = toCopy.nbOfInputs;
   	
    	// Construction of the program itself, recursively by its GeneNodes
        firstNode = (ADFNode) toCopy.firstNode.clone();   
	}
	
	public Object clone(){
		return new ADF(this);
	}
	
//	 The crossover for ADFs
    public void crossover(ProgramRules PR, ADF otherProgram){
		
// Assuring that each crossover will not make program exceed maximum depth specified by user
		
    	GeneNode crossoverPoints[];    	
    	crossoverPoints = selectNodesForCrossover(PR.getADFRules().getMaxDepthADF(), otherProgram);
    	
    	crossoverPoints[0].switchNode(this, otherProgram, crossoverPoints[1]);
    	
		recompute();
    	otherProgram.recompute();
    }	
	
//  Actual mutation method (whole sub-tree is mutated)
     public void mutation(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, int ADFno){
     	((ADFNode)firstNode.getRandomNode()).mutate(PR, ADFno);
		recompute();
     }
     
//  Mutation method where only one node is mutated
     public void mutationNodeOnly(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, int ADFno){
     	((ADFNode)getFirstNode().getRandomNode()).mutateNode(PR, ADFno);
		recompute();
     }
    
     // Child arguments are as input arguments
    public double execute(double args[]){
		return firstNode.execute(null, args);
	}
	
	public String toString(){
		return ((ADFNode)firstNode).toString(null);
	}
	
	public String toString(String classNames[]){
		return ((ADFNode)firstNode).toString(classNames);
	}
	
	public int getNbOfInputs(){
		return nbOfInputs;
	}
	
	public void setSize(int s){
		size = s;
	}

}
