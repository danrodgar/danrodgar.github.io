package weka.classifiers.functions.geneticprogramming;

import java.util.Enumeration;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.*;

/**
 * �valuateur de fitness ad�quat pour la classification d'objets.   Retourne la proportion
 * d'objets correctement classifi�s (nombre de 0 � 1).
 * @author Administrateur
 */
public class ClassifierEvaluator implements FitnessEvaluator, java.io.Serializable {


	public double measureFitness(Instances ins, Program prog) {

		Enumeration enu = ins.enumerateInstances();
		int nbProperlyClassed=0; // number of properly classified instances		
		
		while(enu.hasMoreElements()){
			Instance instance = (Instance)enu.nextElement();
			
            double[] record = instance.toDoubleArray();

            if (Math.floor(prog.execute(record)) == instance.classValue()) {
                nbProperlyClassed++;
            }
		}
		return( (nbProperlyClassed) / ((double)ins.numInstances())  ) ;
	}
	
	
	public double measureFitness(Instance ins, Program prog) {
        double[] record = ins.toDoubleArray();

		if (Math.floor(prog.execute(record)) == ins.classValue()) {
            return 1;
        }								
		return 0;
	}
	
	public boolean lowerIsBetter(){
		return false;
	}
	
	public Double getInferiorBound(){
		return new Double(0);
	}
	
	public Double getSuperiorBound(){
		return new Double(1);
	}
	
	public boolean isNominal() {
		return true;
	}

	public boolean isNumeric() {
		return false;
	}
	
	public String toString(){
		return new String("Classifier Evaluator : each good prediction increments fitness by one.");
	}

}
