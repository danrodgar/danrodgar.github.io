package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class SimplifyAndKeepBestsEliteManager extends EliteManager implements java.io.Serializable {
	
	public SimplifyAndKeepBestsEliteManager(int nbBests){
		super(nbBests);
	}

	public void manageElite(Vector population, FitnessEvaluator FE, ProgramRules PR, Instances trainIns, double pV) {

		addAndSortPrograms(population, FE, pV);		
		for(int i=0;i<eliteSize;i++)
			((Program)elite.get(i)).simplify(PR, trainIns);
	}
	
	public Object clone(){
		return new SimplifyAndKeepBestsEliteManager(eliteSize);
	}
	
	public String toString(){
		return ("Simplify and Keep Bests Elite Manager : simplifies and keeps " + eliteSize + " best programs since beginning of run in memory.");
	}


	public void add(Program P, ProgramRules PR, Instances trainIns){
		P.simplify(PR, trainIns);
		elite.add(P);
	}

}
