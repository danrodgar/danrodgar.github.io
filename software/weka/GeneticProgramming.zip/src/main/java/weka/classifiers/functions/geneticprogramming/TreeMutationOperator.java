package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public class TreeMutationOperator extends GeneticOperator {

	public TreeMutationOperator(int nbParents, int nbChildren, double prob){
		super(nbParents, nbChildren, prob);
	}
	
	/** Here we perform Mutation operation.
	 *  The first Program of the program table get mutated, enough times to produce
	 *  the wanted number of children.
	 *  The children are either returned (if "replace" == false), or
	 *  they replace the last programs of the list (if "replace" == true)  */
	public Vector performOperation(ProgramRules PR, Vector inputProgramPositions, FitnessEvaluator fe,
			Instances trainIns, Instances valIns, Vector pop, boolean doReplacement, double pV) {
		
		int i;
		Vector resultPrograms = new Vector();
		
		// Here we clone the first program into the results
		for(i=0;i<nbOfChildren;i++)
			resultPrograms.add( (MainProgramTree)((MainProgramTree)((ProgramPosition)inputProgramPositions.get(0)).getProgram()).clone(PR) );

		// Each result is mutated
		for(i=0;i<nbOfChildren;i++)
			((MainProgramTree)resultPrograms.get(i)).mutation(PR,fe,trainIns, valIns, pV);
		
		// Here we replace the last programs of the list with the results
		if(doReplacement){
			replace(inputProgramPositions, resultPrograms, pop);
			return null;
		}
		// Or simply return the result
		return resultPrograms;
	}
	

	public String toString(){
		return new String("Tree Mutation Operator : mutates a whole randomly selected sub-tree from a program.\n" + super.toString());
	}


}
