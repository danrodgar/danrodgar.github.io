package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.DataPreProcessor;
import weka.core.Instances;

// This Data Pre Processor normalizes data between 0 and 1
public class LinearNormalizationPreProcessor extends DataPreProcessor {

	double min[];
	double max[];
	
	public double computeNormalizedValue(int index, double inputValue){
		return ((double) 1.0) - (max[index] - inputValue) / (max[index] - min[index]);
	}
	
//	 Prepare the pre-processing of the data by retrieving max and mins
//	 also stores the instances' adress for later comparison
	public void prepareProcessor(Instances ins) {
			instances = ins;
			double buff;
			int numInstances = instances.numInstances();
			int numAttributes = instances.numAttributes() - 1;
			
			min = new double[numAttributes];
			max = new double[numAttributes];

			for (int j = 0; j < (numAttributes); j++) {
				buff = instances.instance(0).value(j);
				max[j] = buff;
				min[j] = buff;
			}

			for (int i = 1; i < numInstances; i++) {
				for (int j = 0; j < (numAttributes); j++) {
					buff = instances.instance(i).value(j);
					if (buff > max[j])
						max[j] = buff;
					else if (buff < min[j])
						min[j] = buff;
				}
			}
		}

	public Object clone(){
		return new LinearNormalizationPreProcessor();
	}
	
	public String toString(){
		return new String("Linear Normalization Pre-processor : normalizes data between 0 and 1.0");
	}
}
