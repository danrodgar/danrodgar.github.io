/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;
import java.lang.Cloneable;
import java.text.NumberFormat;

import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public abstract class Content implements Serializable, Cloneable {
	
	static protected NumberFormat nf = NumberFormat.getInstance();
	
	// Set the maximum number of fraction digits (for print purposes)
	static public void setMaxNumberDigits(int nb){
		nf.setMaximumFractionDigits(nb);	
	}
	
	// Copy constructor.
	public abstract Object clone();
	
	// Evaluation of the Node.
	public abstract double execute(Program program, double inputArgs[], double args[]);

	// Management of text format output.
	public abstract String toString(String inputNames[], String classNames[], int nbChild, String childString[]);
	
	// Management of text format output for ADFs
	public abstract String toStringADF(int nbChild, String classNames[], String childString[]);
	
	// To get the content itself.
	public abstract Object getContent();
	
	// To get the number of children of this Content
	public abstract int nbOfChildren();
	
	// To get the Type of Argument of one of this Content's argument
	public abstract int getTypeOfArg(int argNumber);
}

