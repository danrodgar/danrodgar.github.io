package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;
import weka.core.Instances;
import weka.core.Instance;

public abstract class DataPreProcessor implements Serializable {

	Instances instances;

// Method to compute normalized values
	abstract double computeNormalizedValue(int index, double inputValue);
	
// Method to get info about data before pro-processing
	abstract void prepareProcessor(Instances ins);
	
//	 Used when wanting to test on only one instance
	public void preProcessInstance(Instance ins) {
		double buff, normalizedValue;
		for (int j = 0; j < (instances.numAttributes() - 1); j++) {
			buff = ins.value(j);
			normalizedValue = computeNormalizedValue(j,buff);
			ins.setValue(j, normalizedValue);
		}
	}

// Pre-process input instances using max and mins computed when preparing processor
	public void preProcessInstances(Instances ins) {
		double normalizedValue, buff;
		for (int i = 0; i < ins.numInstances(); i++) {
			for (int j = 0; j < (ins.numAttributes() - 1); j++) {
				buff = ins.instance(i).value(j);
				normalizedValue = computeNormalizedValue(j,buff);
				ins.instance(i).setValue(j, normalizedValue);
			}
		}	
	}
	
	public abstract Object clone();
	
}
