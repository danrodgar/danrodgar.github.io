package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public abstract class EliteManager implements java.io.Serializable{
	
	int eliteSize;
	Vector elite;
	
	public abstract void manageElite(Vector population, FitnessEvaluator FE,
			ProgramRules PR, Instances trainIns, double pV);

	public EliteManager(int eSize){
		eliteSize = eSize;
		elite = new Vector();
	}
	
	public Vector getElite() {
		return elite;
	}
	
	public void addAndSortPrograms(Vector programs, FitnessEvaluator FE, double proportionValidation){
		elite.addAll(programs);
		ProgramSelector.sortProgramPopulation(elite, FE, proportionValidation);
		elite.setSize(eliteSize);
	}
	
	public void addAndSortBestPrograms(Vector programs, FitnessEvaluator FE, double proportionValidation){
		
		for(int i=0;i<programs.size();i++){
			Program po = (Program)programs.get(i);
			if(!hasClone(po))
					elite.add(po);
		}

		ProgramSelector.sortProgramPopulation(elite, FE, proportionValidation);
		elite.setSize(eliteSize);
	}
		
	private boolean hasClone(Program po){
		if(!elite.contains(po)){
			for(int j=0;j<elite.size();j++){
				Program pe = (Program)elite.get(j);
				if( po.getTrainingFitness() == pe.getTrainingFitness()){
						return true;
				}
			}
			return false;
		}
		return true;
	}
	
	public int getEliteSize(){
		return eliteSize;
	}
	
	public Program getEliteProgram(int i){
		return (Program) elite.get(i);
	}
	
	public void reset(){
		elite = new Vector();
	}
	
	public void setElite(Vector theElite){
		elite = theElite;
	}
	
	abstract public void add(Program p, ProgramRules PR, Instances trainIns);
	
	public void reEvaluateFitness(FitnessEvaluator FE, Instances trIns, Instances valIns, double valProp){
		for(int i=0;i<elite.size();i++){
			((Program)elite.get(i)).computeFitness(trIns, valIns, FE, valProp);
		}
	}
	
	abstract public Object clone();
	
}