package weka.classifiers.functions.geneticprogramming;
import java.util.Collections;
import java.util.Vector;
import java.util.Comparator;

public abstract class ProgramSelector implements java.io.Serializable {
	
	public abstract void prepareRanking(Vector pop, FitnessEvaluator FE, double pV);
	public abstract Vector selectPrograms(Vector pop, FitnessEvaluator FE, int number, double pV); // returns Vector of programPositions
	public abstract boolean usuallyReplaces();
	public abstract Object clone();
	
	public static void sortProgramPopulation(Vector pop, FitnessEvaluator FE, double pV){
		Comparator comparator;
		if(FE.lowerIsBetter())
			comparator = new ProgramComparator(ProgramComparator.PROGRAM, pV, false);
		else
			comparator = new ProgramComparator(ProgramComparator.PROGRAM, pV, true);
		Collections.sort(pop, comparator); // Sort is by default ascending order
	}
	
	public static void sortProgramPositions(Vector programsPositions, FitnessEvaluator FE, double pV){
		Comparator comparator;
		if(FE.lowerIsBetter())
			comparator = new ProgramComparator(ProgramComparator.POSITION, pV, false);
		else
			comparator = new ProgramComparator(ProgramComparator.POSITION, pV, true);
		Collections.sort(programsPositions, comparator); // Sort is by default ascending order
	}
	
}

