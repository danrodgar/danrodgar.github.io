package weka.classifiers.functions.geneticprogramming;
import java.io.FileOutputStream;

import javax.swing.JFileChooser;
import java.io.*;
import weka.filters.*;
import weka.core.*;
import weka.filters.supervised.instance.StratifiedRemoveFolds;

public class ManageDB {

	public static void main(String[] args) {
		
		try{
				
			int numberOfDBWanted = 50;
			int noOfFolds = 3;
			String fileName = null;
			
			JFileChooser chooser = new JFileChooser();
		    int returnVal = chooser.showOpenDialog(null);
		    if(returnVal == JFileChooser.APPROVE_OPTION) {
		    	fileName = chooser.getSelectedFile().getAbsolutePath();
		    }
		    
		    StratifiedRemoveFolds filter = new StratifiedRemoveFolds();
			filter.setNumFolds(3);
			
			
			FileReader reader = new FileReader(fileName);
			Instances inputDB = new Instances(reader);
			inputDB.setClassIndex(inputDB.numAttributes() - 1);
 
			Instances outputTrainingDB;
			Instances outputTestDB;
			for(int i=0;i<numberOfDBWanted;i++){
				filter.setSeed(i);
				filter.setInvertSelection(true);
				filter.setInputFormat(inputDB);
				outputTrainingDB = Filter.useFilter(inputDB, filter);
				writeInstancesToFile(outputTrainingDB, fileName, "training", i);
				
				filter.setSeed(i);
				filter.setInvertSelection(false);
				filter.setInputFormat(inputDB);
				outputTestDB = Filter.useFilter(inputDB, filter);
				writeInstancesToFile(outputTestDB, fileName, "test", i);
			}
		}catch (Exception E){
			E.printStackTrace();
		}
	
	}
	
	static private void writeInstancesToFile(Instances ins, String originalFileName, String toAdd, int fileNumber) throws Exception{
		int pointIndex = originalFileName.lastIndexOf('.');
		String newFileName = originalFileName.substring(0, pointIndex-1);
		
		FileOutputStream fos = new FileOutputStream(newFileName + toAdd + fileNumber + ".arff");
		OutputStreamWriter out = new OutputStreamWriter(fos, "UTF-8");
		out.write(ins.toString());
		out.close();
	}

}
