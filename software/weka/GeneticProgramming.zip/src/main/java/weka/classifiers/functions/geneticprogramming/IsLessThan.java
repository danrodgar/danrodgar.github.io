package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class IsLessThan extends Function {
	public IsLessThan(ArgumentType AT){
		super(AT);
		name = "<";
		functionType = AT.checkType("Test");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		argTypes[0] = AT.checkType("Arithmetic");
		argTypes[1] = AT.checkType("Arithmetic");	
	}
	
	public double execute(double argVal[]){
		if(argVal[0]<argVal[1])
			return (double)1.0;
		else
			return (double)0.0;
	}
}
