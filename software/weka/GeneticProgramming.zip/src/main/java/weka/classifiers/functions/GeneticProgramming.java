package weka.classifiers.functions;

import weka.classifiers.AbstractClassifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.geneticprogramming.ADFRules;
import weka.classifiers.functions.geneticprogramming.CompletionManager;
import weka.classifiers.functions.geneticprogramming.ContinuousEvolutionController;
import weka.classifiers.functions.geneticprogramming.DataPreProcessor;
import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.ErrorSumEvaluator;
import weka.classifiers.functions.geneticprogramming.EvolutionController;
import weka.classifiers.functions.geneticprogramming.ExponentialRankingSelector;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.FitnessProportionnalSelector;
import weka.classifiers.functions.geneticprogramming.FunctionRules;
import weka.classifiers.functions.geneticprogramming.GPController;
import weka.classifiers.functions.geneticprogramming.GPExperimentController;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.GeneticParameters;
import weka.classifiers.functions.geneticprogramming.KeepBestsEliteManager;
import weka.classifiers.functions.geneticprogramming.LinearNormalizationPreProcessor;
import weka.classifiers.functions.geneticprogramming.LinearRankingSelector;
import weka.classifiers.functions.geneticprogramming.NewProgramTreeOperator;
import weka.classifiers.functions.geneticprogramming.OneClassConfidenceEvaluator;
import weka.classifiers.functions.geneticprogramming.OneClassEvaluator;
import weka.classifiers.functions.geneticprogramming.OneClassWeightEvaluator;
import weka.classifiers.functions.geneticprogramming.PopulationInitializer;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;
import weka.classifiers.functions.geneticprogramming.RMSEEvaluator;
import weka.classifiers.functions.geneticprogramming.ReproductionOperator;
import weka.classifiers.functions.geneticprogramming.SelectAfterEvolutionController;
import weka.classifiers.functions.geneticprogramming.SelectFirstEvolutionController;
import weka.classifiers.functions.geneticprogramming.SimplifyAndKeepBestsEliteManager;
import weka.classifiers.functions.geneticprogramming.StatisticalNormalizationPreProcessor;
import weka.classifiers.functions.geneticprogramming.TournamentSelector;
import weka.classifiers.functions.geneticprogramming.TreeCrossoverOperator;
import weka.classifiers.functions.geneticprogramming.TreeMutationOperator;
import weka.classifiers.functions.geneticprogramming.TreeNodeMutationOperator;
import weka.classifiers.functions.geneticprogramming.TreePopFullInitializer;
import weka.classifiers.functions.geneticprogramming.TreePopGrowInitializer;
import weka.classifiers.functions.geneticprogramming.TreePopHalfHalfInitializer;
import weka.core.Capabilities;
import weka.core.Capabilities.Capability;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.SelectedTag;
import weka.core.Tag;
import weka.core.Utils;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

public class GeneticProgramming extends AbstractClassifier implements weka.core.OptionHandler, Observer	{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1421453984913337717L;
	public static final int CLASSIFICATION = 0;
	public static final int REGRESSION = 1;	
	private int problemType;
	
	/** Pre-processing of data */
	public static final int NOPREPROCESSING = 0;
	public static final int LINEARNORMALIZATION = 1;
	public static final int STATISTICALNORMALIZATION = 2;
	public static final Tag [] TAGS_PREPROCESSING = {
	  new Tag(NOPREPROCESSING, "No pre-processing of data."),
	  new Tag(LINEARNORMALIZATION, "Linear normalization [0,1] of data."),
	  new Tag(STATISTICALNORMALIZATION, "Statistical normalization (using mean and std dev.) of data."),
	};
	private int DEFAULTPREPROCESSINGCODE = STATISTICALNORMALIZATION;
	private int preProcessingCode = DEFAULTPREPROCESSINGCODE;
	
	/** General parameters */
	private final static int DEFAULTPOPULATIONSIZE = 100;
	private final static double DEFAULTPROPORTIONVALIDATION = 0.5;
	private final static int DEFAULTMAXDEPTH = 5;
	private final static double DEFAULTPROPORTIONINPUT = 0.5;
	private final static double DEFAULTPROPORTIONFLOATCONSTANT = 1.0;
	
	private int populationSize = DEFAULTPOPULATIONSIZE;
	private double proportionValidation = DEFAULTPROPORTIONVALIDATION;
	private int maxDepth = DEFAULTMAXDEPTH;
	private double proportionInput = DEFAULTPROPORTIONINPUT;
	private double proportionFloatConstant = DEFAULTPROPORTIONFLOATCONSTANT; 
	
	/** ADF parameters */
	private static final int NBOFADFS = 0, MINNBOFARGSADF = 1, MAXNBOFARGSADF = 2, MAXDEPTHADF = 3;
	private static final int[] DEFAULTADFPARAMETERS = {0,0,0,0};
	private int[] adfParameters = (int[]) DEFAULTADFPARAMETERS.clone();
	
	private static final String ALLFUNCTIONSSTRING = "+,-,/,*,Sq,Sqrt,If,If3,>,<,!,Pow,&,|,Xor,Max,Min,Exp,Log,Sin,Cos";
	private static final String DEFAULTFUNCTIONSSTRING = "+,-,/,*,If,>,<,Pow,&,|,Max,Min,Exp,Log";
	private String functionsString = new String(DEFAULTFUNCTIONSSTRING);
	
	/** The population initializer */
	public static final int FULL = 0;
	public static final int GROW = 1;
	public static final int RAMPEDHALFANDHALF = 2;
	public static final Tag [] TAGS_POPULATIONINITIALIZER = {
	  new Tag(FULL, "Program trees initialized with Full method"),
	  new Tag(GROW, "Program trees initialized with Grow method"),
	  new Tag(RAMPEDHALFANDHALF, "Program trees initialized with Ramped Half and Half method"),
	};
	private int DEFAULTPOPULATIONINITIALIZER = RAMPEDHALFANDHALF;
	private int populationInitializerCode = DEFAULTPOPULATIONINITIALIZER;
	
	/** The genetic operators */
	private Vector geneticOperators;
	private static final int CROSSOVER = 0, MUTATION = 1, MUTATIONNODE = 2, REPRODUCTION = 3, NEWPROGRAM = 4;
	private static final String[] OPERATORNAMES = {"Crossover", "Mutation", "Mutation (node)", "Reproduction", "New program"};
	private static final double[] DEFAULTOPERATORPROPORTION = {0.9,0.07,0,0,0.03};
	private static final int[] DEFAULTOPERATORPARENTS = {2,1,1,1,1};
	private static final int[] DEFAULTOPERATORCHILDREN = {2,1,1,1,1};
	
	private double[] operatorProportion = (double[]) DEFAULTOPERATORPROPORTION.clone();
	private int[]  operatorParents = (int[]) DEFAULTOPERATORPARENTS.clone();
	private int[]  operatorChildren = (int[]) DEFAULTOPERATORCHILDREN.clone();
	
	/** The fitness evaluators */
	public static final int ONECLASSWEIGHTEVALUATOR = 0;
	public static final int ERRORSUMEVALUATOR = 1;
	public static final int RMSEEVALUATOR = 2;
	public static final int STANDARDCLASSIFIER = 3;
	public static final int ONECLASSCONFIDENCEEVALUATOR = 4;
	public static final int ONECLASSEVALUATOR = 5;

	public static final Tag [] TAGS_FITNESSEVALUATOR = {
	  new Tag(ONECLASSWEIGHTEVALUATOR, "Confidence on one class recognition (hybrid classifier with boosting)"),
	  new Tag(ERRORSUMEVALUATOR, "Error sum (continuous)"),
	  new Tag(RMSEEVALUATOR, "Root mean square error (continuous)"),
	  // new Tag(STANDARDCLASSIFIER, "Standard classifier"),
	  // new Tag(ONECLASSCONFIDENCEEVALUATOR, "Confidence on only one class recognition (hybrid classifier)"),
	  // new Tag(ONECLASSEVALUATOR, "Binary one class recognition (hybrid classifier)"),
	  
	};
	private final int DEFAULTFITNESSEVALUATOR = ONECLASSWEIGHTEVALUATOR;
	private int fitnessEvaluatorCode = DEFAULTFITNESSEVALUATOR;
	
	/** The program selectors */
	public static final int FITNESSPROPORTIONNAL = 0;
	public static final int TOURNAMENT = 1;
	public static final int LINEARRANKING = 2;
	public static final int EXPONENTIALRANKING = 3;
	public static final Tag [] TAGS_PROGRAMSELECTOR = {
	  new Tag(FITNESSPROPORTIONNAL, "Selection proportionnal to fitness"),
	  new Tag(TOURNAMENT, "Tournament (random selection, to combine with Continuous evolution)"),
	  new Tag(LINEARRANKING, "Selection from linear ranking between 2 values"),
	  new Tag(EXPONENTIALRANKING, "Selection from exponential ranking with bias constant"),
	};
	private static final int DEFAULTPROGRAMSELECTOR = FITNESSPROPORTIONNAL;
	private int programSelectorCode = DEFAULTPROGRAMSELECTOR;
	
	private static final double DEFAULTMMINUS = 0.5;
	private static final double DEFAULTMPLUS = 1.5;
	private static final double DEFAULTBIASCONSTANT = 0.5;
	
	private double mMinus = DEFAULTMMINUS;
	private double mPlus = DEFAULTMPLUS;
	private double biasConstant = DEFAULTBIASCONSTANT;
	
	/** The elite managers */
	public static final int KEEPBESTS = 0;
	public static final int SIMPLIFYANDKEEPBESTS = 1;
	public static final Tag [] TAGS_ELITEMANAGER = {
	  new Tag(KEEPBESTS, "Keep a number of the best programs in memory"),
	  new Tag(SIMPLIFYANDKEEPBESTS, "Simplify and keep a number of best programs"),
	};
	private static final int DEFAULTELITEMANAGER = KEEPBESTS;
	private int eliteManagerCode = DEFAULTELITEMANAGER;
	
	private static final int DEFAULTELITESIZE = 5;	
	private int eliteSize = DEFAULTELITESIZE;
	
	/** The evolution controllers */
	public static final int SELECTFIRST = 0;
	public static final int SELECTAFTER = 1;
	public static final int CONTINUOUS = 2;
	public static final Tag [] TAGS_EVOLUTIONCONTROLLER = {
	  new Tag(SELECTFIRST, "Produce enough children to replace preceding generation"),
	  new Tag(SELECTAFTER, "Produce a number of children. Choose between children and parents to create a new generation"),
	  new Tag(CONTINUOUS, "Children created immediately replace worst program(s) selected for operation"),
	};
	private final int DEFAULTEVOLUTIONCONTROLLER = SELECTAFTER;
	private int evolutionControllerCode = DEFAULTEVOLUTIONCONTROLLER;
	
	private int newPopulationSize = DEFAULTPOPULATIONSIZE;

	/** The completion parameters */
	private static final int FITNESS = 0, GENERATIONS = 1, MINUTES = 2;
	private static final String[] COMPLETIONNAMES = {"Fitness", "Generations", "Max time in minutes"};
	private static final double[] DEFAULTCOMPLETION = {0.90,20.0,0.33};
	private double[] completion = (double[]) DEFAULTCOMPLETION.clone();
	
	/** Use of class weights */
	private static final int USECLASSWEIGHTS = 0, NOCLASSWEIGHTS = 1;
	public static final Tag [] TAGS_CLASSWEIGHTS = {
		  new Tag(USECLASSWEIGHTS, "Use class weights."),
		  new Tag(NOCLASSWEIGHTS, "Do not use class weights."),
		};
		private final int DEFAULTCLASSWEIGHTS = NOCLASSWEIGHTS;
		private int classWeightsCode = DEFAULTCLASSWEIGHTS;
	
    GPExperimentController GPEC;
    
	public String globalInfo() {
		return "Genetic Programming (only tree structure available for now)." +
		"Genetic Programming inspired by Koza [1] " +
		"and Banzhaf et al. [2]. Can perform symbolic regression (continuous) or classification. " +
		"Classification uses multiple one-against-all classifiers. Better accuracy is obtained " +
		"on classification by the integration of a boosting technique [3].\n" +
		"[1] Koza, J.R. (1992), Genetic Programming: On the Programming of Computers "+ 
		"by Means of Natural Selection, MIT Press\n" +
		"[2] Banzhaf, W., Nordin, P., Keller, R.E., Francone, F.D. (1998), Genetic " + 
		"Programming: An Introduction: On the Automatic Evolution of Computer Programs " + 
		"and Its Applications, Morgan Kaufmann\n" +
		"[3] Yoav Freund and Robert E. Schapire (1996). Experiments with a new boosting " +
		"algorithm. Proc International Conference on Machine Learning, pages 148-156, Morgan " +
		"Kaufmann, San Francisco.";
	}

  /**
   * Returns default capabilities of the classifier.
   *
   * @return      the capabilities of this classifier
   */
  public Capabilities getCapabilities() {
    Capabilities result = super.getCapabilities();

    // attributes
    result.enable(Capability.NOMINAL_ATTRIBUTES);
    result.enable(Capability.NUMERIC_ATTRIBUTES);
    result.enable(Capability.DATE_ATTRIBUTES);
    result.enable(Capability.MISSING_VALUES);

    // class
    result.enable(Capability.NOMINAL_CLASS);
    result.enable(Capability.NUMERIC_CLASS);
    result.enable(Capability.DATE_CLASS);
    result.enable(Capability.MISSING_CLASS_VALUES);
    
    return result;
  }
	
	public void buildClassifier(Instances instances) throws Exception {

		getCapabilities().testWithFail(instances);
		instances = new Instances(instances);
		instances.deleteWithMissingClass();
		
		// Get info concerning attributes and classes from instances
		int nbOfAttributes = instances.numAttributes();
		int nbOfInputs = nbOfAttributes-1;
		int classIndex = nbOfInputs;
		instances.setClassIndex(classIndex);
		int nbOfClasses;

		// Check problem type (continuous or class output problem)
		if(instances.attribute(classIndex).isNominal()){
			nbOfClasses = instances.numClasses();
			problemType = CLASSIFICATION;
		}else{
			nbOfClasses = 0;
			problemType = REGRESSION;
		}

		// Choose pre-processing method		
		DataPreProcessor dataPreProcessor = null;
		switch (preProcessingCode){
			case NOPREPROCESSING:
				dataPreProcessor = null; break;
			case LINEARNORMALIZATION:
				dataPreProcessor = new LinearNormalizationPreProcessor(); break;
			case STATISTICALNORMALIZATION:
				dataPreProcessor = new StatisticalNormalizationPreProcessor(); break;
		}

		// Choose population initialization method		
		PopulationInitializer populationInitializer = null;
		switch (populationInitializerCode){
			case FULL:
				populationInitializer = new TreePopFullInitializer(); break;
			case GROW:
				populationInitializer = new TreePopGrowInitializer(); break;
			case RAMPEDHALFANDHALF:
				populationInitializer = new TreePopHalfHalfInitializer(); break;
		}

		int nbOfExperiments = nbOfClasses;	
		if (problemType == REGRESSION)
			nbOfExperiments = 1;
		else
			completion[MINUTES] /= (double)(eliteSize * nbOfExperiments);

		// Choose fitness evaluation method
		FitnessEvaluator fitnessEvaluator[] = new FitnessEvaluator[nbOfExperiments];
		if(problemType == CLASSIFICATION){
			for(int z=0;z<nbOfExperiments;z++){
				if(fitnessEvaluatorCode == ONECLASSWEIGHTEVALUATOR)
					fitnessEvaluator[z] = new OneClassWeightEvaluator(z);
				else if(fitnessEvaluatorCode == ONECLASSCONFIDENCEEVALUATOR)
					fitnessEvaluator[z] = new OneClassConfidenceEvaluator(z);
				else // (fitnessEvaluatorCode == ONECLASSEVALUATOR) // DEFAULT
					fitnessEvaluator[z] = new OneClassEvaluator(z);
			}
		}else{
			switch (fitnessEvaluatorCode){
				case ERRORSUMEVALUATOR:
					fitnessEvaluator[0] = new ErrorSumEvaluator();	break;
				default: // All others
					fitnessEvaluator[0] = new RMSEEvaluator(); break;	
			}
		}

		// Choose program selection method
		ProgramSelector programSelector = null;
		switch (programSelectorCode){
			case FITNESSPROPORTIONNAL:
				programSelector = new FitnessProportionnalSelector(); break;
			case TOURNAMENT:
				programSelector = new TournamentSelector();	break;
			case LINEARRANKING:
				programSelector = new LinearRankingSelector(mMinus, mPlus); break;
			case EXPONENTIALRANKING:
				programSelector = new ExponentialRankingSelector(biasConstant); break;
		}

		// Choose elitism management method
		EliteManager eliteManager = null;
		switch (eliteManagerCode){
			case KEEPBESTS:
				eliteManager = new KeepBestsEliteManager(eliteSize); break;
			case SIMPLIFYANDKEEPBESTS:
				eliteManager = new SimplifyAndKeepBestsEliteManager(eliteSize); break;
		}

		// Chose evolution style of GP
		EvolutionController evolutionController = null;
		switch (evolutionControllerCode){
			case SELECTFIRST:
				evolutionController = new SelectFirstEvolutionController(); break;
			case SELECTAFTER:
				evolutionController = new SelectAfterEvolutionController(newPopulationSize);	break;
			case CONTINUOUS:
				evolutionController = new ContinuousEvolutionController(); break;
		}

		// Preparation of Genetic Operators
		geneticOperators = new Vector();
		GeneticOperator GPO;
		GPO = new TreeCrossoverOperator(operatorParents[CROSSOVER], operatorChildren[CROSSOVER], operatorProportion[CROSSOVER]);
		if(operatorProportion[CROSSOVER] > 0.0) geneticOperators.add(GPO);
		GPO = new TreeMutationOperator(operatorParents[MUTATION], operatorChildren[MUTATION], operatorProportion[MUTATION]);
		if(operatorProportion[MUTATION] > 0.0) geneticOperators.add(GPO);
		GPO = new TreeNodeMutationOperator(operatorParents[MUTATIONNODE], operatorChildren[MUTATIONNODE], operatorProportion[MUTATIONNODE]);
		if(operatorProportion[MUTATIONNODE] > 0.0) geneticOperators.add(GPO);
		GPO = new ReproductionOperator(operatorParents[REPRODUCTION], operatorChildren[REPRODUCTION], operatorProportion[REPRODUCTION]);
		if(operatorProportion[REPRODUCTION] > 0.0) geneticOperators.add(GPO);
		GPO = new NewProgramTreeOperator(operatorParents[NEWPROGRAM], operatorChildren[NEWPROGRAM], operatorProportion[NEWPROGRAM]);
		if(operatorProportion[NEWPROGRAM] > 0.0) geneticOperators.add(GPO);

		// Preparation of ADF Rules, if nbOfADFs = 0 there will be no ADF
		ADFRules ADFR = new ADFRules(adfParameters[NBOFADFS], adfParameters[MINNBOFARGSADF],
				adfParameters[MAXNBOFARGSADF], adfParameters[MAXDEPTHADF]);

		// Preparation of the Function Rules, which Functions will be available for the programs
		FunctionRules functionRules = new FunctionRules(functionsString.split(","), ADFR);

		// Preparation of completion parameters
		CompletionManager completionManager = new CompletionManager(completion[FITNESS],
				(int)completion[GENERATIONS], completion[MINUTES]);

		// All genetic parameters are stored in this object
		GeneticParameters geneticParameters = new GeneticParameters(dataPreProcessor, populationSize, 
				proportionValidation, new ProgramRules(maxDepth, nbOfInputs, nbOfClasses,
						proportionInput, proportionFloatConstant, ADFR, functionRules),
						populationInitializer, geneticOperators, programSelector,
						new KeepBestsEliteManager(1), evolutionController);

		boolean useClassWeights;
		if(classWeightsCode == USECLASSWEIGHTS)
			useClassWeights = true;
		else
			useClassWeights = false;

		// Initializing and starting experiment(s)
		GPEC = new GPExperimentController(nbOfExperiments, geneticParameters, eliteManager,
				fitnessEvaluator, completionManager, useClassWeights, problemType);

		GPEC.run(instances);
	}
	
	public double[] distributionForInstance(Instance instance) throws Exception {
		double[] dist = new double[instance.numClasses()];
		int prediction= (int) classifyInstance(instance);
		if (prediction>=0 && prediction < instance.numClasses()){
			dist[prediction] = 1;
		}
		return dist;
	}

	public double classifyInstance(Instance instance) throws Exception {
		return GPEC.classifyInstance(instance);
	}

	/**
	   * Returns an enumeration describing the available options..
	   * @return an enumeration of all the available options.
	   */
	  public Enumeration listOptions() {

	    Vector newVector = new Vector(20);
	    
	    // General parameters
	    
	    String string = "\tTo load and old experiment and continue it with new parameters.";
	    newVector.addElement(new Option(string, "le", 1, "-le <Model file name>"));
	    string = "\tTo save elite obtained by this experiment in a file.";
	    newVector.addElement(new Option(string, "sv", 1, "-sv <Save file name>"));
	    string = "\tFor one-thread execution of experiment (is default).";
	    newVector.addElement(new Option(string, "ot", 0, "-ot"));
	    string = "\tFor multithread execution of experiments";
	    newVector.addElement(new Option(string, "mt", 0, "-mt"));
	    string = "\tFor non-hybrid multiclass classifier (default is one hybrid multiclass classifier)";
	    newVector.addElement(new Option(string, "om", 0, "-om"));
	    string = "\tFor hybrid classifier made from multiple one-class classifiers (is default)";
	    newVector.addElement(new Option(string, "mo", 0, "-mo"));
	    string = "\tFor evolution centered on only one class (default: -1 means option not used)";
	    newVector.addElement(new Option(string, "eo", 1, "-eo <class number>"));
	    string = "\tThe number of programs in the population (default: 2000).";
	    newVector.addElement(new Option(string, "pop", 1, "-pop <population size>"));
	    string = "\tThe proportion of training data kept for validation (default: 0.0).";
	    newVector.addElement(new Option(string, "pv", 1, "-pv <validation data proportion>"));
	    string = "\tThe maximum depth of a program tree (default: 5).";
	    newVector.addElement(new Option(string, "de", 1, "-de <depth of program trees>"));
	    string = "\tUse of class weights.";
	    newVector.addElement(new Option(string, "cw", 0, "-cw"));
	    
	    // Pre-processing
	    // No pre-processing
	    string = "\tNo pre-processing of data (is default).";
	    newVector.addElement(new Option(string, "no", 0, "-no"));
	    // Linear normalization [0,1]
	    string = "\tFor linear normalization [0,1] of data.";
	    newVector.addElement(new Option(string, "ln", 0, "-ln"));
	    // Statistical normalization (mean, std. dev.)
	    string = "\tFor statistical normalization (using mean and std dev.) of data.";
	    newVector.addElement(new Option(string, "sn", 0, "-sn"));
	    
	    // ADF parameters
	    string = "\tParameters number, min. number of args, max. number of args, max.  depth for ADFS (default: 0,0,0,0).";
	    newVector.addElement(new Option(string, "adf", 4, "-adf <number of ADFs per program> <min number of args> <max number of args> <max depth>"));
	    
	    // Function rules parameters
	    string = "\tAvailable functions for programs : enter a string for each function, separated with a comma without space +" +
	    		" (or \"all\"). Available functions are (case sensitive) : +,-,/,*,Sq,Sqrt,If,If3,>,<,!,Pow,&,|,Xor";
	    newVector.addElement(new Option(string, "func", 1, "-func <string containing functions or \"all\"."));
	    
	    // Population initializer
	    // Full method
	    string = "\tTrees are initially fully grown (max size).";
	    newVector.addElement(new Option(string, "fi", 0, "-fi"));
	    // Grow method
	    string = "\tTrees are initially grown and pruned using proportion of inputs.";
	    newVector.addElement(new Option(string, "gi", 0, "-gi"));
	    // Half and half
	    string = "\tTrees are grown using the Ramped Half and Half methode proposed by Koza (is default).";
	    newVector.addElement(new Option(string, "hh", 0, "-hh"));
	    
	    // Operators options
	    // Change Operator proportion
	    string = "\tOperator proportion : crossover, mutation, mutationNode, reproduction, newProgram (default: 0.9, 0.07, 0, 0, 0.03), total must be 1.0.";
	    newVector.addElement(new Option(string, "pr", 5, "-pr <crossover pr.> <mutation pr.> <mutationNode pr.> <reproduction pr.> <newProgram pr.>"));
	    // Change Operator nb of Parents
	    string = "\tOperator parents : crossover, mutation, mutationNode, reproduction, newProgram (default: 2, 1, 1, 1, 1).";
	    newVector.addElement(new Option(string, "pa", 5, "-pa <crossover parents> <mutation parents> <mutationNode parents> <reproduction parents> <newProgram parents>"));
	    // Change Operator nb of Children
	    string = "\tOperator children : crossover, mutation, mutationNode, reproduction, newProgram (default: 2, 1, 1, 1, 1).";
	    newVector.addElement(new Option(string, "ch", 5, "-ch <crossover children> <mutation children> <mutationNode children> <reproduction children> <newProgram children>"));
	    
	    // Fitness Evaluator
	    // Classifier
	    string = "\tStandard Classifier fitness evaluator : (is default fitness evaluator for non-hybrid classification problem).";
	    newVector.addElement(new Option(string, "cl", 0, "-cl"));
	    // RMSE
	    string = "\tRoot Mean Square Error fitness evaluator : (is default fitness evaluator for regression problem).";
	    newVector.addElement(new Option(string, "rm", 0, "-rm"));
	    // Error Sum
	    string = "\tSum of error fitness evaluator.";
	    newVector.addElement(new Option(string, "es", 0, "-es"));
	    // One class confidence evaluator
	    string = "\tConfidence on one class fitness evaluator.";
	    newVector.addElement(new Option(string, "oc", 0, "-oc"));
	    // One class evaluator
	    string = "\tOne class fitness evaluator.";
	    newVector.addElement(new Option(string, "of", 0, "-of"));
	    // One class weight evaluator
	    string = "\tOne class weight fitness evaluator : (is default for multiple class hybrid classifier).";
	    newVector.addElement(new Option(string, "of", 0, "-ow"));
	    
	    // Program selector
	    // Fitness proportionnal
	    string = "\tFitness proportionnal program selector : (is default program selector).";
	    newVector.addElement(new Option(string, "fp", 0, "-fp"));
	    // Tournament
	    string = "\tTournament program selector : (Continuous Evolution Controller suggested).";
	    newVector.addElement(new Option(string, "to", 0, "-to"));
	    // Linear ranking
	    string = "\tLinear ranking program selector : N * minimum proportion, N * maximum proportion (total must be 2.0 - default: 0.5, 1.5).";
	    newVector.addElement(new Option(string, "lr", 2, "-lr <N*mMinus> <N*mPlus>"));
	    // Exponential ranking
	    string = "\tExponential ranking program selector : bias constant (must be in ]0,1[  default: 0.5).";
	    newVector.addElement(new Option(string, "er", 1, "-er <bias constant>"));
	    
	    // Elite manager
	    // Keep Bests
	    string = "\tKeep bests Elite Manager : number of program to keep (is default Elite Manager, default value: 1).";
	    newVector.addElement(new Option(string, "ke", 1, "-ke <elite size>"));
	    // Simplify and Keep Bests
	    string = "\tSimplify and Keepbests Elite Manager : number of program to simplify and keep (default: 1)";
	    newVector.addElement(new Option(string, "sk", 1, "-sk <elite size>"));
	    	    
	    // Evolution Controller
	    // Select First
	    string = "\tSelect First Evolution Controller (total replacement with children).";
	    newVector.addElement(new Option(string, "sf", 0, "-sf"));
	    // Select After
	    string = "\tSelect After Evolution Controller : number of children to produce (default: popSize).";
	    newVector.addElement(new Option(string, "sa", 1, "-sa <children pop size>"));
	    // Continuous
	    string = "\tContinuous Evolution Controller : (immediate replacement of tournament losers by children of winners)";
	    newVector.addElement(new Option(string, "co", 0, "-co"));
	    
	    // Completion manager options
	    string = "\tThe completion parameters for run : fitness, maximum generation and maximum time in minutes.";
	    newVector.addElement(new Option(string, "com", 3, "-com <desired fitness> <maximum gen> <time in minutes>"));
	     
	    return newVector.elements();
	  }

	  private boolean minMaxOK(double value, double min, double max, String parameterName) throws Exception{
		  boolean valueOK = false;
		  if(value < min)
			  throw new Exception(parameterName + " cannot be less than " + min + ".");
		  else if(value > max)
			  throw new Exception(parameterName + " cannot be greater than " + max + ".");
		  else
			  valueOK = true;
		  return valueOK;
	  }
	  	    
	  private void checkAndSetMaxDepthADF(int nb) throws Exception{
		  if(minMaxOK(nb,0,25, "Max depth for ADF")){
			  if(adfParameters[MAXDEPTHADF] > 0 && nb < 1) 
					   throw new Exception("Max depth for ADF cannot be 0 if number of ADFs > 0 (ADFs are used).");
			  else
				  adfParameters[MAXDEPTHADF] = nb;
		  }
	  }
	  
	  private void checkAndSetBiasConstant(double bCt) throws Exception{
		  if(bCt <= 0.0 || bCt >= 1.0)
			  throw new Exception("Bias constant must be greater than 0.0 and lower than 1.0.");
		  else
			  biasConstant = bCt;
	  }
	  
	  private int checkAndSetInt(int value, int defaultValue, int min, int max, String paramName) throws Exception{
		  if(minMaxOK(value,min,max,paramName))
			  return value;
		  else
			  return defaultValue;
	  }
	  
	  private double checkAndSetDouble(double value, double defaultValue, double min, double max, String paramName) throws Exception{
		  if(minMaxOK(value,min,max,paramName))
			  return value;
		  else
			  return defaultValue;
	  }
	  
	  private boolean sameContent(double[] a, double[] b){
		  for(int i=0;i<a.length;i++)
			  if(a[i] != b[i])
				  return false;
		  return true;
	  }
	  
	  private boolean sameContent(int[] a, int[] b){
		  for(int i=0;i<a.length;i++)
			  if(a[i] != b[i])
				  return false;
		  return true;
	  }
	  
	  private String padWithChar(int[] values, String ch){
		 String output = "";
		 for(int i=0;i<values.length-1;i++)
			 output += "" + values[i] + ch;
		 output += values[values.length-1];
		 return output;
	  }
	  
	  private String padWithChar(double[] values, String ch){
		 String output = "";
		 for(int i=0;i<values.length-1;i++)
			 output += "" + values[i] + ch;
		 output += values[values.length-1];
		 return output;
	  }
	  
	  // Modified from weka.core.Utils to get multple parameters on an option
	  public String getOptions(String flag, String [] options)throws Exception {
	    String newString;

	    if (options == null)
	      return "";
	    for (int i = 0; i < options.length; i++) {
	      if ((options[i].length() > 0) && (options[i].charAt(0) == '-')) {
		
		// Check if it is a negative number
		try {
		  Double.valueOf(options[i]);
		} catch (NumberFormatException e) {
		  if (options[i].equals("-" + flag)) {
		    if (i + 1 == options.length) {
		      throw new Exception("No value given for -" + flag + " option.");
		    }
		    options[i] = "";
		    newString = new String(options[i + 1]);
		    options[i + 1] = "";
		    int j=1;
		
		    while(i+j+1 < options.length){
		    	if(options[i + j + 1].length() > 0)
			    	if(options[i + j + 1].charAt(0) != '-'){
			    		newString += "," + options[i + j + 1];
			    		options[i + j + 1] = "";
			    	}else
			    		break;
		    	else
		    		break;
		    	j++;
		    }
		    return newString;
		  }
		  if (options[i].charAt(1) == '-') {
		    return "";
		  }
		}
	      }
	    }
	    return "";
	  }
	  
	  /**
	   * @param options the list of options as an array of strings
	   * @exception Exception if an option is not supported
	   */
	  public void setOptions(String[] options) throws Exception {
	    
		// General options
		  
	    // Population
	    String pString = Utils.getOption("pop", options);
	    if (pString.length() != 0) {int pSize = Integer.parseInt(pString); 
	    	populationSize = checkAndSetInt(pSize, DEFAULTPOPULATIONSIZE, 1, 100000, "Population size");}
	    // Validation proportion
	    String pvString = Utils.getOption("pv", options);
	    if (pvString.length() != 0) {double pV = Double.parseDouble(pvString); 
	    	proportionValidation = checkAndSetDouble(pV, DEFAULTPROPORTIONVALIDATION, 0.0, 1.0, "Proportion validation");}
	    // Depth
	    String depthString = Utils.getOption("de", options);
	    if (depthString.length() != 0) { int depth = Integer.parseInt(depthString);
	    	maxDepth = checkAndSetInt(depth,DEFAULTMAXDEPTH, 1, 50, "Max depth");}
	    // Class weights
	    if(Utils.getFlag("cw", options))
	    	classWeightsCode = USECLASSWEIGHTS;
	    
	    // Pre-processing
	    // No pre-processing
	    if(Utils.getFlag("no", options))
	    	preProcessingCode = NOPREPROCESSING;
	    // Linear normalization [0,1]
	    if(Utils.getFlag("ln", options))
	    	preProcessingCode = LINEARNORMALIZATION;
	    // Statistical normalization (mean, std. dev.)
	    if(Utils.getFlag("sn", options))
	    	preProcessingCode = STATISTICALNORMALIZATION;
	    
	    // ADFs options
	    setADFs(getOptions("adf", options));
	    
	    // Functions
	    String funcString = Utils.getOption("func", options);
	    if(funcString.length() != 0)
	    	functionsString = funcString;
	    
	    // Population initializer
	    // Full
	    if(Utils.getFlag("fi", options))
	    	populationInitializerCode = FULL;
	    // Grow
	    if(Utils.getFlag("gi", options))
	    	populationInitializerCode = GROW;
	    // Half and Half
	    if(Utils.getFlag("hh", options))
	    	populationInitializerCode = RAMPEDHALFANDHALF;
	    
	    // Genetic operators
	    // Proportion
	    setOperatorProportion(getOptions("pr", options));
	    // Parents
	    setOperatorParents(getOptions("pa", options));
	    // Children
	    setOperatorChildren(getOptions("ch", options));
	    
	    // Fitness evaluators
		// Classifier
	    if(Utils.getFlag("cl", options))
	    	fitnessEvaluatorCode = STANDARDCLASSIFIER;
	    // RMSE
	    if(Utils.getFlag("rm", options))
	    	fitnessEvaluatorCode = RMSEEVALUATOR;
	    // Error Sum
	    if(Utils.getFlag("es", options))
	    	fitnessEvaluatorCode = ERRORSUMEVALUATOR;
		// One class confidence Evaluator
	    if(Utils.getFlag("oc", options))
	    	fitnessEvaluatorCode = ONECLASSCONFIDENCEEVALUATOR;
		// One class Evaluator
	    if(Utils.getFlag("of", options))
	    	fitnessEvaluatorCode = ONECLASSEVALUATOR;
	    if(Utils.getFlag("ow", options))
	    	fitnessEvaluatorCode = ONECLASSWEIGHTEVALUATOR;
	    
	    // Program Selector
		// Fitness proportionnal
	    if(Utils.getFlag("fp", options))
	    	programSelectorCode = FITNESSPROPORTIONNAL;
	    // Tournament
	    if(Utils.getFlag("to", options))
	    	programSelectorCode = TOURNAMENT;
	    // Linear Ranking
	    String lrString = getOptions("lr", options);
	    setmMinusMplus(lrString);
	    if(lrString.length() > 0)
	    	programSelectorCode = LINEARRANKING;
	    // Exponential ranking
	    String erString = Utils.getOption("er", options); 
	    if (erString.length() != 0) { double bCt = Double.parseDouble(erString); programSelectorCode = EXPONENTIALRANKING;
	    	checkAndSetBiasConstant(bCt); }
	    
	    // Elite Manager
	    // Keep bests
	    String kString = Utils.getOption("ke", options);
	    if (kString.length() != 0) { int eSize = Integer.parseInt(kString); eliteManagerCode = KEEPBESTS;
	    	eliteSize = checkAndSetInt(eSize, DEFAULTELITESIZE, 0, populationSize, "Elite population size"); }
	    // Simplify and Keep bests
	    String skString = Utils.getOption("sk", options);
	    if (skString.length() != 0) {
	    	int eSize = Integer.parseInt(skString); eliteManagerCode = SIMPLIFYANDKEEPBESTS;
	    	eliteSize = checkAndSetInt(eSize, DEFAULTELITESIZE, 0, populationSize, "Elite population size"); }
	   
	    // Evolution Controller	   
	    // Select First
	    if(Utils.getFlag("sf", options))
	    	evolutionControllerCode = SELECTFIRST;
	    // Select After
	    String saString = Utils.getOption("sa", options);
	    if (saString.length() != 0) {
	    	int npSize = Integer.parseInt(saString); evolutionControllerCode = SELECTAFTER;
	    	newPopulationSize = checkAndSetInt(npSize, populationSize, 0, 100000, "Number of children produced befor selection"); }
	    // Continuous
	    if(Utils.getFlag("co", options))
	    	evolutionControllerCode = CONTINUOUS;
	    
	    // Completion option
	    setCompletion(getOptions("com", options));
	  }

	  private void adjustGeneticOperatorProportion(){
		  double sum = operatorProportion[0];
		  
		  for(int k=1;k<operatorProportion.length;k++){
			  sum += operatorProportion[k];
		  
			  if(sum > 1.0){
				  operatorProportion[k] = 1.0 - (sum - operatorProportion[k-1]);
				  for(int i=k+1;i<operatorProportion.length;i++)
					  operatorProportion[i] = 0;
				  if(sum > 1.00001){
					  double newSum = 0.0;
					  for(int z=0;z<operatorProportion.length;z++)
						  newSum += operatorProportion[z];
					  System.out.println("Genetic Operator Proportions have been modified from sum = " + sum + " to sum = 1.0.");
				  }
				  return;
			  }
		  }
		  
		  if(sum < 1.0){
			  if(sum < 0.99999)
			  	System.out.println("Genetic Operator Proportions have been modified from sum = " + sum + " to sum = 1.0.");
			  operatorProportion[NEWPROGRAM] += 1.0 - sum;
		  }
	  }
	  
	  /**
	   * Gets the current settings of the GeneticProgramming classifier.
	   *
	   * @return an array of strings suitable for passing to setOptions
	   */
	  public String [] getOptions() {

	    String [] options = new String [40];
	    int current = 0;

	    // General options

	    if(populationSize != DEFAULTPOPULATIONSIZE){ options[current++] = "-pop";
	    options[current++] = "" + populationSize;}
	    if(proportionValidation != DEFAULTPROPORTIONVALIDATION){ options[current++] = "-pv";
	    options[current++] = "" + proportionValidation;}
	    if(maxDepth != DEFAULTMAXDEPTH){options[current++] = "-de";
	    options[current++] = "" + maxDepth;}
	    if(classWeightsCode != DEFAULTCLASSWEIGHTS)
	    	options[current++] = "-cw";
	    
	    // Pre-processing
	    if(preProcessingCode != DEFAULTPREPROCESSINGCODE){
		    switch(preProcessingCode){
	    	case NOPREPROCESSING:
	    	    options[current++] = "-no"; break;
	    	case LINEARNORMALIZATION:
	    	    options[current++] = "-ln"; break;
	    	case STATISTICALNORMALIZATION:
	    	    options[current++] = "-sn"; break;
		    }
	    }
	    
	    // ADFs
	    if(!sameContent(adfParameters,DEFAULTADFPARAMETERS)){options[current++] = "-adf";
	    options[current++] = padWithChar(adfParameters," ");}
	    
	    // Functions
	    if(functionsString.compareTo(DEFAULTFUNCTIONSSTRING) != 0){ options[current++] = "-func";
	    options[current++] = functionsString;}	
	    
	    // Population Initializer
	    if(populationInitializerCode != DEFAULTPOPULATIONINITIALIZER){
		    switch(populationInitializerCode){
	    	case FULL:
	    	    options[current++] = "-fi"; break;
	    	case GROW:
	    	    options[current++] = "-gi"; break;
	    	case RAMPEDHALFANDHALF:
	    		options[current++] = "-hh"; break;
		    }
	    }
	    
	    // Operators
	    if(!sameContent(operatorProportion,DEFAULTOPERATORPROPORTION)){options[current++] = "-pr";
	    options[current++] = padWithChar(operatorProportion," ");}
	    if(!sameContent(operatorParents,DEFAULTOPERATORPARENTS)){options[current++] = "-pa";
	    options[current++] = padWithChar(operatorParents," ");}
	    if(!sameContent(operatorChildren,DEFAULTOPERATORCHILDREN)){options[current++] = "-ch";
	    options[current++] = padWithChar(operatorChildren," ");}  
	    
	    // Fitness evaluator
	    if(fitnessEvaluatorCode != DEFAULTFITNESSEVALUATOR){
		    switch(fitnessEvaluatorCode){
	    	case STANDARDCLASSIFIER:
	    	    options[current++] = "-cl"; break;
	    	case RMSEEVALUATOR:
	    	    options[current++] = "-rm"; break;
	    	case ERRORSUMEVALUATOR:
	    		options[current++] = "-es"; break;
	    	case ONECLASSCONFIDENCEEVALUATOR:
	    		options[current++] = "-oc"; break;
	    	case ONECLASSEVALUATOR:
	    		options[current++] = "-of"; break;
	    	case ONECLASSWEIGHTEVALUATOR:
	    		options[current++] = "-ow"; break;
		    }
	    }
	    
	    // Program selector
	    if(programSelectorCode != DEFAULTPROGRAMSELECTOR || mMinus != DEFAULTMMINUS ||
	    		mPlus != DEFAULTMPLUS || biasConstant != DEFAULTBIASCONSTANT){
		    switch(programSelectorCode){
		    	case FITNESSPROPORTIONNAL:
		    	    options[current++] = "-fp"; break;
		    	case TOURNAMENT:
		    	    options[current++] = "-to"; break;
		    	case LINEARRANKING:
		    		options[current++] = "-lr";
		    	    options[current++] = "" + mMinus + " " + mPlus; break;
		    	case EXPONENTIALRANKING:
		    		options[current++] = "-er";
		    	    options[current++] = "" + biasConstant; break;
		    }
	    }
	    
	    // Elite manager
	    if(eliteManagerCode != DEFAULTELITEMANAGER || eliteSize != DEFAULTELITESIZE){
		    switch(eliteManagerCode){
	    	case KEEPBESTS:
	    	    options[current++] = "-ke"; break;
	    	case SIMPLIFYANDKEEPBESTS:
	    		options[current++] = "-sk"; break;
		    }
		    options[current++] = "" + eliteSize;
	    }
		
		// Evolution controller
	    if(evolutionControllerCode != DEFAULTEVOLUTIONCONTROLLER || newPopulationSize != DEFAULTPOPULATIONSIZE){
		    switch(evolutionControllerCode){
	    	case SELECTFIRST:
	    	    options[current++] = "-sf"; break;
	    	case SELECTAFTER:
	    	    options[current++] = "-sa";
	    	    options[current++] = "" + newPopulationSize; break;
	    	case CONTINUOUS:
	    		options[current++] = "-co"; break;
		    }
	    }
		
	    //Completion
	    if(!sameContent(completion,DEFAULTCOMPLETION)){
	    options[current++] = "-com";
	    options[current++] = padWithChar(completion, " ");}

	    while (current < options.length) {
	      options[current++] = "";
	    }
	    return options;
	  }


// General parameters  
	    
	  // Population size
	  public int getPopulationSize() {
	    return populationSize;
	  }	  
	  public void setPopulationSize(int size) {	    
	    populationSize = size;
	  }
	  public String populationSizeTipText() {
	    return "The number of programs in the population.";
	  }
	  
	  // Proportion validation
	  public double getProportionValidation() {
	    return proportionValidation;
	  }	  
	  public void setProportionValidation(double pv) {	    
		  proportionValidation = pv;
	  }
	  public String proportionValidationTipText() {
	    return "The proportion of training data kept for validation.";
	  }
	  
	  // Maximum depth
	  public void setMaxDepth(int d) {	    
	  	maxDepth = d;
	  }
	  public int getMaxDepth(){
	  	return maxDepth;
	  }
	  public String maxDepthTipText() {
	    return "The maximum depth of program trees.";
	  }

		  
	    // Pre-processing
		public void setpreProcessing(SelectedTag newMethod) {
			if (newMethod.getTags() == TAGS_PREPROCESSING) {
				preProcessingCode = newMethod.getSelectedTag().getID();	    	     
			}	  
		}
		public String preProcessingTipText() {
			return "Kind of pre-processing for input data.";
		}
		public SelectedTag getpreProcessing() {
			  return new SelectedTag(preProcessingCode, TAGS_PREPROCESSING);
		}
	
		
//		 Class Weights
		public void setClassWeights(SelectedTag newMethod) {
			if (newMethod.getTags() == TAGS_CLASSWEIGHTS) {
				classWeightsCode = newMethod.getSelectedTag().getID();	    	     
			}	  
		}

		/*
		public String classWeightsTipText() {
			return "If class weights are to be used to create hybrid classifier.";
		}
		public SelectedTag getClassWeights() {
			  return new SelectedTag(classWeightsCode, TAGS_CLASSWEIGHTS);
		}
		*/
	  
// ADFs
	  public void setADFs(String input) throws Exception{
		  if(input.length() > 0){
			  String[] inputs = input.split(",");
			  int i = inputs.length;
			  if(i-- > 0) if(inputs[0].length() > 0) adfParameters[NBOFADFS] = checkAndSetInt(Integer.parseInt(inputs[0]),
					  DEFAULTADFPARAMETERS[NBOFADFS], 0, 50, "Number of ADF per program");
			  if(i-- > 0) if(inputs[1].length() > 0)  adfParameters[MINNBOFARGSADF] = checkAndSetInt(Integer.parseInt(inputs[1]),
					  DEFAULTADFPARAMETERS[MINNBOFARGSADF], 0, 50, "Min number of args for ADFs");
			  if(i-- > 0) if(inputs[2].length() > 0) adfParameters[MAXNBOFARGSADF] = checkAndSetInt(Integer.parseInt(inputs[2]),
					  DEFAULTADFPARAMETERS[MAXNBOFARGSADF], adfParameters[MINNBOFARGSADF], 50, "Max number of args for ADFs");
			  if(i-- > 0) if(inputs[3].length() > 0) checkAndSetMaxDepthADF(Integer.parseInt(inputs[3]));
		  }
	  }
	  public String getADFs(){
		  return padWithChar(adfParameters, ",");
	  }
	  public String ADFsTipText() {
		    return "Automatically Defined Functions (ADF) parameters : Nb for each program, min args, max args, max depth of program.";
	  }  

//   Functions
	  public void setFunctions(String input){
		  if(input.length() > 0)
			  functionsString = input;
	  }
	  public String getFunctions(){
		  return functionsString;
	  }
	  public String functionsTipText(){
		  return "Functions available for programs -- available functions are " + ALLFUNCTIONSSTRING;
	  }
	  
//	 Population initializer
		public void setPopulationInitializer(SelectedTag newMethod) {
			if (newMethod.getTags() == TAGS_POPULATIONINITIALIZER) {
				populationInitializerCode = newMethod.getSelectedTag().getID();	    	     
			}	  
		}
		public SelectedTag getPopulationInitializer() {
			  return new SelectedTag(populationInitializerCode, TAGS_POPULATIONINITIALIZER);
		}
		public String populationInitializerTipText() {
			return "Method for initializing a population of programs. Either Grow method " + 
			"Full method, or Ramped Half and Half (recommended).";
		}
			
	  
// Operators
	  	// Proportion
		public void setOperatorProportion(String input) throws Exception{
			  if(input.length() > 0){
				  String[] inputs = input.split(",");
				  int operator = 0;
				  while(operator < inputs.length && operator < operatorProportion.length){
					  if(inputs[operator].length() > 0)
					  operatorProportion[operator] = checkAndSetDouble(Double.parseDouble(inputs[operator]),
							  DEFAULTOPERATORPROPORTION[operator], 0.0, 1.0, OPERATORNAMES[operator] + " proportion"); operator++;
				  }
				  adjustGeneticOperatorProportion();
				  
			  }
		  }
		  public String getOperatorProportion(){
			  return padWithChar(operatorProportion, ",");
		  }
		  public String operatorProportionTipText() {
			    return "Operator proportions : crossover, mutation, mutation (node only), reproduction, new program -- " +
			    		"Total must be equal to 1.0.";
		  }  

		  // Parents
			public void setOperatorParents(String input) throws Exception{
				  if(input.length() > 0){
					  String[] inputs = input.split(",");
					  int operator = 0;
					  while(operator < inputs.length && operator < operatorParents.length){
						  if(inputs[operator].length() > 0)
						  operatorParents[operator] = checkAndSetInt(Integer.parseInt(inputs[operator]),
								  DEFAULTOPERATORPARENTS[operator], 1, populationSize, OPERATORNAMES[operator] + " parents");operator ++;}
					  
				  }
			  }
			  public String getOperatorParents(){
				  return padWithChar(operatorParents, ",");
			  }
			  public String operatorParentsTipText() {
				    return "Operator parents (number) : crossover, mutation, mutation (node only), reproduction, new program.";
			  }  

			  // Children
			public void setOperatorChildren(String input) throws Exception{
				  if(input.length() > 0){
					  String[] inputs = input.split(",");
					  int operator = 0;					  
					  while(operator < inputs.length && operator < operatorChildren.length){
						  if(inputs[operator].length() > 0)
						  operatorChildren[operator] = checkAndSetInt(Integer.parseInt(inputs[operator]),
								  DEFAULTOPERATORCHILDREN[operator], 1, operatorParents[operator], OPERATORNAMES[operator] + " children");operator ++;}
				  }
			  }
			  public String getOperatorChildren(){
				  return padWithChar(operatorChildren, ",");
			  }
			  public String operatorChildrenTipText() {
				    return "Operator children (number) : crossover, mutation, mutation (node only), reproduction, new program.";
			  }  
	  
// Fitness evaluator
		public void setFitnessEvaluator(SelectedTag newMethod) {
			if (newMethod.getTags() == TAGS_FITNESSEVALUATOR) {
				fitnessEvaluatorCode = newMethod.getSelectedTag().getID();
				if(fitnessEvaluatorCode == ERRORSUMEVALUATOR || fitnessEvaluatorCode == RMSEEVALUATOR ){
					eliteSize = 1;
					classWeightsCode = NOCLASSWEIGHTS;
				}
			}	  
		}
		public String fitnessEvaluatorTipText() {
			return "Method for Solution fitness evaluation. Either standard classifier, for " + 
			"nominal classes, Error sum or RMS error which are for continuous problems.";
		}
		public SelectedTag getFitnessEvaluator() {
			  return new SelectedTag(fitnessEvaluatorCode, TAGS_FITNESSEVALUATOR);
		}
		
// Program selector
		// choices
		public void setProgramSelector(SelectedTag newMethod) {
			if (newMethod.getTags() == TAGS_PROGRAMSELECTOR) {
				programSelectorCode = newMethod.getSelectedTag().getID();	    	     
			}	  
		}
		public String programSelectorTipText() {
			return "Method for program selection for reproduction. Either fitness parentsnal, " + 
			"tournament (continuous evolution preferred), linear or exponential ranking.";
		}
		public SelectedTag getProgramSelector() {
			  return new SelectedTag(programSelectorCode, TAGS_PROGRAMSELECTOR);
		}
		
		// parameters
		  // Children
		public void setmMinusMplus(String input) throws Exception{
			  if(input.length() > 0){
				  String[] inputs = input.split(",");
				  int i = inputs.length;
				  if(i-- > 0) if(inputs[0].length() > 0) mMinus = checkAndSetDouble(Double.parseDouble(inputs[0]), 
						  DEFAULTMMINUS, 	0.0, 1.0, "mMinus");
				  if(i-- > 0) if(inputs[1].length() > 0) mPlus = checkAndSetDouble(Double.parseDouble(inputs[1]),
						  DEFAULTMPLUS, mMinus, 2.0 - mMinus, "mPlus");
				  double total = mMinus + mPlus;
				  if(total < 1.999 || total > 2.001)
					  throw new Exception("mMinus + mPlus must be equal to 2.0");
			  }
		  }
		
		  public String getmMinusMplus(){
			  return "" + mMinus + "," + mPlus ;
		  }
		  public String mMinusMplusTipText() {
			    return "Probability of program being selected * Number of programs : " +
			    	"mMinus (for worst program), mPlus (for best program) -- Use these parameters " +
			    	"only if linear ranking selection is used.";
		  }
		  
		  // biasConstant
		  public void setBiasConstant(double p) {	    
			  biasConstant = p;
			  }
		  public double getBiasConstant(){
		  	return biasConstant;
		  }
		  public String biasConstantTipText() {
		    return "Bias constant, from 0 to 1 - Use this parameter only if exponential ranking selection is used.";
		  } 
		  
// Elite manager
			// choices
			public void setEliteManager(SelectedTag newMethod) {
				if (newMethod.getTags() == TAGS_ELITEMANAGER) {
					eliteManagerCode = newMethod.getSelectedTag().getID();	    	     
				}	  
			}
			public String eliteManagerTipText() {
				return "Method for elite management. Either keep bests " + 
				"or simplify and keep bests.";
			}
			public SelectedTag getEliteManager() {
				  return new SelectedTag(eliteManagerCode, TAGS_ELITEMANAGER);
			}
			
			// parameters
				// eliteSize
			  public void setEliteSize(int p) {	    
				  eliteSize = p;
				  }
			  public int getEliteSize(){
			  	return eliteSize;
			  }
			  public String eliteSizeTipText() {
			    return "Size of the elite population.";
			  } 
			  
// Evolution controller
			// choices
			public void setEvolutionController(SelectedTag newMethod) {
				if (newMethod.getTags() == TAGS_EVOLUTIONCONTROLLER) {
					evolutionControllerCode = newMethod.getSelectedTag().getID();	    	     
				}	  
			}
			public String evolutionControllerTipText() {
				return "Method for control of genetic evolution. Either select first, " + 
				"select after or continuous.";
			}
			public SelectedTag getEvolutionController() {
				  return new SelectedTag(evolutionControllerCode, TAGS_EVOLUTIONCONTROLLER);
			}
			
			// parameters
				// newPopulationSize
			  public void setNewPopulationSize(int p) {	    
				  newPopulationSize = p;
			  }
			  public int getNewPopulationSize(){
			  	return newPopulationSize;
			  }
			  public String newPopulationSizeTipText() {
			    return "Size of children population (for select after method).";
			  } 
			
// Completion parameters	
	public void setCompletion(String input) throws Exception{
		  if(input.length() > 0){
			  String[] inputs = input.split(",");
			  int param = 0;					  
			  while(param < inputs.length && param < completion.length){
				  if(inputs[param].length() > 0)
				  completion[param] = checkAndSetDouble(Double.parseDouble(inputs[param]),
						  DEFAULTCOMPLETION[param], 0.0, 1000000000000.0, COMPLETIONNAMES[param]);param ++;}
		  }
	  }
	  public String getCompletion(){
		  return padWithChar(completion,",");
	  }
	  public String completionTipText() {
		    return "Completion parameters : target fitness, maximum generation, maximum total time in minutes.";
	  }  
				  
	public void update(Observable o, Object arg) {
    	// String message = (String) arg;
    	// System.out.println("GeneticProgramming.update().  message=" + message + "  objet=" +o);
    	if (arg=="generation completed"){
    		System.out.println("Generation completed");
    		//mettre � jour le graphique si utilis� (non impl�ment�)
    		// GPExperiment GPE = (GPExperiment) o;   	    
    	}else if (arg=="state changed"){
    		//System.out.println("new state:" + ((GPController)o).getState());
    		GPController GPC = (GPController) o;
    		if (GPC.getState() == GPController.COMPLETED ){
    			// buildComplete[GPC.getExperimentNumber()] = true;
    		}
    	}
	}
	
	public static void main(String[] args){
		try{
			System.out.println(Evaluation.evaluateModel(new GeneticProgramming(), args));
		}catch(Exception E){
			System.err.println(E.getMessage());
		}
	}
	
	public String toString() {
		return GPEC.toString();
	}
	
}