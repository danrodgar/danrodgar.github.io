package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ADF;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneNode;
import weka.classifiers.functions.geneticprogramming.MainProgramTree;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramTree;
import weka.core.Instances;

public class MainProgramTree extends ProgramTree {

// 	Here we have links to all of the program's Automatically Defined Functions.
	private ADF[] ADFs;
	
//	 The main constructor for this class
    public MainProgramTree(ProgramRules PR) {
    	trainingFitness = 0;
    	
        // ADF initialization, if necessary
    	if(PR.withADFs()){
    		int nbADFs = PR.getNbOfADFs();
    		ADFs = new ADF[nbADFs];
            for (int i = 0; i < nbADFs; i++) {
                ADFs[i] = new ADF(PR, i);
            }
    	}else{
    		ADFs = null;
    	}
    	
        firstNode = new GeneNode();        
    }
    
//  Methods for Main Program Tree creation
    public void growInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
    	
//    	ADF construction
    	if(PR.withADFs()){
    		int nbADFs = PR.getNbOfADFs();
    		for (int i = 0; i < nbADFs; i++) {
                ADFs[i].growInit(PR,i);
            }
    	}
    	
        // Construction of the program itself, recursively by its GeneNodes
    	size = firstNode.growInit(PR);
		computeFitness(trainIns, valIns, fe, valProp);
    }
    
    public void fullInit(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
    	
//    	ADF construction
    	if(PR.withADFs()){
    		int nbADFs = PR.getNbOfADFs();
    		for (int i = 0; i < nbADFs; i++) {
    			ADFs[i].fullInit(PR,i);
            }
    	}
    	
// Construction of the program itself, recursively by its GeneNodes
    	size = firstNode.fullInit(PR);
    	computeFitness(trainIns, valIns, fe, valProp);
    }
    
    
// A copy Constructor
    public MainProgramTree(MainProgramTree program, ProgramRules PR){
    	size = program.size;
    	trainingFitness = program.trainingFitness;
    	validationFitness = program.validationFitness;
    	wasValidated = program.wasValidated;
    	totalFitness = program.totalFitness;
    	error = program.error;			
    	firstNode = (GeneNode)program.firstNode.clone();
    	
    	// ADF copy, if necessary
    	if(PR.withADFs()){
    		int nbADFs = PR.getNbOfADFs();
        	ADFs = new ADF[nbADFs];
    	    	for(int i=0;i<nbADFs;i++){
    	    		ADFs[i]=(ADF)program.ADFs[i].clone();
    	    	}
    	}else
    		ADFs = null;
    	
// Construction of the program itself, recursively by its GeneNodes
        firstNode = (GeneNode) program.firstNode.clone();   
    }
    
    public Program clone(ProgramRules PR){
    	return new MainProgramTree(this, PR);
    }

    public void crossover(ProgramRules PR, Program otherProgram, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp) throws Exception{
    	if(this.getClass()!=otherProgram.getClass()){
    		Exception e = new Exception("Trying to cross programs of two diffent types!");
    		throw e;
    	}
   		crossover(PR, (MainProgramTree)otherProgram, fe, trainIns, valIns, true, valProp);
    }
    
    public void crossover(ProgramRules PR, MainProgramTree otherProgram, FitnessEvaluator fe, Instances trainIns, Instances valIns, boolean ok, double valProp){

    	GeneNode crossoverPoints[];    	
    	crossoverPoints = selectNodesForCrossover(PR.getMaxDepth(), otherProgram);
    	
    	crossoverPoints[0].switchNode(this, otherProgram, crossoverPoints[1]);
		
		if(PR.withADFs()){
			for(int i=0;i<PR.getNbOfADFs();i++){
	   			ADFs[i].crossover(PR, otherProgram.getADF(i));
			}
		}
		
		recompute();
		computeFitness(trainIns, valIns, fe, valProp);
    	
		otherProgram.recompute();
		otherProgram.computeFitness(trainIns, valIns, fe, valProp);
    }
    
    
//  Actual mutation method (whole sub-tree is mutated)
     public void mutation(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
     	firstNode.getRandomNode().mutate(PR);
     	if(PR.withADFs()){
			for(int i=0;i<PR.getNbOfADFs();i++){
	   			ADFs[i].mutation(PR, fe, trainIns, valIns, i);
			}
		}
     	
     	recompute();
     	computeFitness(trainIns, valIns, fe, valProp);
     }
     
//  Mutation method where only one node is mutated
     public void mutationNodeOnly(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double valProp){
     	getFirstNode().getRandomNode().mutateNode(PR);
     	if(PR.withADFs()){
			for(int i=0;i<PR.getNbOfADFs();i++){
	   			ADFs[i].mutationNodeOnly(PR, fe, trainIns, valIns, i);
			}
		}
     	
     	recompute();
     	computeFitness(trainIns, valIns, fe, valProp);
     }
    
    public ADF[] getADFs() {
        return ADFs;
    }

    public ADF getADF(int i) {
        return ADFs[i];
    }
    
//  Use GeneNode's toString method and prints the whole ADFs recursively too.
     public String toString(String inputNames[], String classNames[], ProgramRules PR) {
         String s = firstNode.toString(inputNames, classNames);
         int nbADFs = PR.getNbOfADFs();
         if (nbADFs > 0) {
             for (int i = 0; i < nbADFs; i++) {
                 s = s + "\nCode for ADF " + i + "\n";
                 s = s + ADFs[i].toString(classNames);
             }
         }
         return s;
     }

}
