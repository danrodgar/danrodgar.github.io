package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ADF;

public class ADFRules implements java.io.Serializable{
	private int nbADFs;
	private int maxDepthADF;
	private int nbInputsADF[];
	
	private ADF[] currentADF;
	
	public ADFRules(){
		nbADFs = 0;
		maxDepthADF = 0;
		nbInputsADF = null;
	}
	
	public ADFRules(int nADFS, int minNbArgsADF, int maxNbArgsADF, int mxDepthADF){
		nbADFs = nADFS;
		nbInputsADF = new int[nADFS];
		for (int i=0;i<nbADFs;i++)
			nbInputsADF[i] = minNbArgsADF+(int)(Math.random()*(maxNbArgsADF+1-minNbArgsADF));
		maxDepthADF = mxDepthADF;
	}
	
	public int getNbOfADFs(){
		return nbADFs;
	}
	
	public int getNbOfInputsADF(int ADFnum){
		return nbInputsADF[ADFnum];
	}
	
	public int getMaxDepthADF(){
		return maxDepthADF;
	}
	
	public void setCurrentADFs(ADF ADFs[]){
		currentADF = ADFs;
	}
	
	public ADF getADF(){
		return currentADF[(int)Math.random()*nbADFs];
	}
	
	public ADF getADF(int ADFnum){
		return currentADF[ADFnum];
	}
	
	public Object clone(){
		ADFRules theClone = new ADFRules();
		theClone.nbADFs = nbADFs;
		theClone.maxDepthADF = maxDepthADF;
		theClone.nbInputsADF = (int[])nbInputsADF.clone();
		return theClone;
	}
	public String toString(){
		String s = "";
		if(nbADFs > 0){
			s += "Number of ADFs = " + nbADFs + "\n";
			s += "Number of inputs for ADF\n";
			for (int i=0;i<nbADFs;i++)
				s += "\t ADF no." + i + " : " + nbInputsADF[i] + " inputs\n";
			s += "Maximum depth for ADF = " + maxDepthADF;
		}else{
			s += "ADFs are not used.";
		}
		return s;
	}
	
	

}
