package weka.classifiers.functions.geneticprogramming;

import java.util.Enumeration;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.core.*;


/**
 * Root Mean Square Error Evaluator.
 * Evaluates the fitness of a program using the root mean square over a set
 * of instances.  Single instances cannot be evaluated using this evaluator.
 * Note: fitness is the negated value of the result so that high fitness is better than
 * a low fitness.  This should be fixed (or accepted as a good solution).
 * @author Administrateur
 */
public class RMSEEvaluator implements FitnessEvaluator, java.io.Serializable {

	public double measureFitness(Instances ins, Program prog) {
				
		// double mean = ins.meanOrMode(ins.classIndex()); 
		
		double sumSquaredErrors=0; 
		Enumeration enu = ins.enumerateInstances();		
			while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
				
	            double[] record = instance.toDoubleArray();
	            // Note GAB: incertain que classValue est le bon champ pour une estimation continue.
	            sumSquaredErrors +=Math.pow(prog.execute(record)- instance.classValue(),2);
			}			
			double RMSE = Math.sqrt(sumSquaredErrors/(double)ins.numInstances());
			

		return(RMSE);
	}

	public double measureFitness(Instance instance, Program prog) {		
		return prog.execute(instance.toDoubleArray())- instance.classValue();
	}
	
	public boolean lowerIsBetter(){
		return true;
	}
	
	public Double getInferiorBound(){
		return new Double(0);
	}
	
	public Double getSuperiorBound(){
		return new Double(Double.POSITIVE_INFINITY);
	}

	public boolean isNominal() {
		return false;
	}

	public boolean isNumeric() {
		return true;
	}

	public String toString(){
		return new String("Root Mean Square Error Fitness Evaluator : computes fitness as the root of the mean of the squared error " +
				"for each data instance.");
	}
	
}
