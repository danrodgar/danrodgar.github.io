/*
 * Created on Dec 1, 2004
 */
package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ADFCall;
import weka.classifiers.functions.geneticprogramming.ADFRules;
import weka.classifiers.functions.geneticprogramming.ClassChooser;
import weka.classifiers.functions.geneticprogramming.Constant;
import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.Function;
import weka.classifiers.functions.geneticprogramming.FunctionCall;
import weka.classifiers.functions.geneticprogramming.FunctionRules;
import weka.classifiers.functions.geneticprogramming.Input;

/**
 * @author Yan Levasseur
 *
 * This class contains all rules and constants necessary
 * for the computation and creation of the program prees.
 *
 */
public class ProgramRules implements java.io.Serializable{

	private int maxDepth;
	private int nbOfInputs;
	private int nbOfClasses; // when = 0, means that output must be continuous
	private int nbOfPossibleContents;
	
	private double proportionInput;
	private double proportionFloatConstant;
	
	private ADFRules ADFR;
	private FunctionRules functionRules;
	
	public ProgramRules(int depth, int inputs, int classes, double pI, double pFC,
			ADFRules ADFRule, FunctionRules FR){
		
		maxDepth = depth;	
		nbOfInputs = inputs;
		nbOfClasses = classes;
		
		proportionInput = pI;
		if(classes > 0)
			proportionFloatConstant = pFC;
		else
			proportionFloatConstant = 1.0;
		
		ADFR = ADFRule;
		functionRules = FR;
		
		nbOfPossibleContents = nbOfInputs + functionRules.getSize();
	}
	
	public ProgramRules(int depth, int inputs, int classes, double pI, double pFC,
			ADFRules ADFRule, String[] functionsStrings) throws Exception{
		
		maxDepth = depth;	
		nbOfInputs = inputs;
		nbOfClasses = classes;
		
		proportionInput = pI;
		if(classes > 0)
			proportionFloatConstant = pFC;
		else
			proportionFloatConstant = 1.0;
		
		ADFR = ADFRule;
		
		functionRules = new FunctionRules(functionsStrings, ADFRule);
		
		nbOfPossibleContents = inputs + functionRules.getSize();
	}

	// When we want equal chances of getting terminals and functions, Grow method
	public Content getContentGrow(int depth){
		// Out of Z possible contents (made of X inputs + Y functions), input chances are X / Z
		// and functions' probability are Y / Z 
		if(((int)(Math.random() *(double)(nbOfPossibleContents))) < nbOfInputs)
			return getTerminal();
		else{
			return getContentFull(depth);
		}
	}
	
	// When wanted argument type is unknown or for Full method
	public Content getContentFull(int depth){
		if(depth >= maxDepth)
			return getTerminal();
		else{
			Function fct = functionRules.getFunction();
			if(fct.isADF())
				return new ADFCall(fct);
			else
				return new FunctionCall(fct);
		}
	}
	
	// Used when Parent needs particular type of content to work properly, Grow method
	public Content getContentGrow(int argType, int depth){
		if(((int)(Math.random() *(double)(nbOfPossibleContents))) < nbOfInputs)
			return getTerminal();
		else{
			return getContentFull(argType, depth);
		}
	}
	
	// Used when Parent needs particular type of content to work properly, Full method
	public Content getContentFull(int argType, int depth){
		if(depth >= maxDepth)
			return getTerminal();
		else{
			Function fct = functionRules.getFunctionByType(argType);
			if(fct == null)
				fct = functionRules.getFunction();
			if(fct.isADF())
				return new ADFCall(fct);
			else
				return new FunctionCall(fct);
		}
	}
	
	// Used when switching only a node and wanting to keep the same number of arguments
	public Content getContentByNbArg(int nbArg){
		if(nbArg<=0)
			return getTerminal();
		else{
			Function fct = functionRules.getFunctionByNbArg(nbArg);
			if(fct.isADF())
				return new ADFCall(fct);
			else
				return new FunctionCall(fct);
		}
	}	
	
	// Used for ADFs, Grow method
	public Content getContentForADFGrow(int depth, int ADFNumber){
		int nbPossibleInputs = ADFR.getNbOfInputsADF(ADFNumber);
		if(((int)(Math.random() *(double)(nbPossibleInputs + functionRules.getSize()))) < nbPossibleInputs)
			return getTerminal(nbPossibleInputs);
		else{
			return getContentForADFFull(depth, ADFNumber);
		}
	}
	
	// Used for ADFs, Full method
	public Content getContentForADFFull(int depth, int ADFNumber){
		if(depth >= ADFR.getMaxDepthADF())
			return getTerminal(ADFR.getNbOfInputsADF(ADFNumber));
		else{
			Function fct = functionRules.getNonADFFunction();
			return new FunctionCall(fct);
		}
	}
	
//	 Used for ADFs when parent need specific content to work properly, Grow method
	public Content getContentForADFGrow(int argType, int depth, int ADFNumber){
		int nbPossibleInputs = ADFR.getNbOfInputsADF(ADFNumber);
		if(((int)(Math.random() *(double)(nbPossibleInputs + functionRules.getSize()))) < nbPossibleInputs)
			return getTerminal(nbPossibleInputs);
		else{
			return getContentForADFFull(argType, depth, ADFNumber);
		}
	}
	
	// Used for ADFs when parent need specific content to work properly, Full method
	public Content getContentForADFFull(int argType, int depth, int ADFNumber){
		if(depth >= ADFR.getMaxDepthADF())
			return getTerminal(ADFR.getNbOfInputsADF(ADFNumber));
		else{
			Function fct = functionRules.getNonADFFunctionByType(argType);
			if(fct == null)
				fct = functionRules.getNonADFFunction();
			return new FunctionCall(fct);
		}
	}
	
	// Used for ADFs when wanting to switch a node with another with same number of arguments
	public Content getContentForADFByNbArg(int nbArg, int ADFno){
		if(nbArg<=0)
			return getTerminal(ADFR.getNbOfInputsADF(ADFno));
		else
			return new FunctionCall(functionRules.getNonADFFunctionByNbArg(nbArg));
	}
	
	// Used to get any Terminal, from all inputs
	public Content getTerminal(){
		if(Math.random() < proportionInput)
			return new Input(nbOfInputs);
		else
			return getConstant();
	}
	
	// Used for ADFs, beacause they have a limited number of inputs, setted by user
	public Content getTerminal(int nbInputs){
		if(nbInputs < 1)
			return getConstant();
		if(Math.random() < proportionInput)
			return new Input(nbInputs);
		else
			return getConstant();
	}
		
	// To get a Constant
	public Content getConstant(){
    	if(Math.random() < proportionFloatConstant)
    		return new Constant();    	
    	else	
    		return new ClassChooser(nbOfClasses);
	}
	
	// To get a specified constant (for example PI or other)
	public Content getConstant(double constantValue){
    		return new Constant(constantValue);
	}
	
	// To see if using ADFs
	public boolean withADFs(){
		if(ADFR != null)
			return true;
		else
			return false;
	}
	
	public ADFRules getADFRules(){
		return ADFR;
	}
	
	public int getNbOfADFs(){
		if(ADFR==null)
			return 0;
		else
			return ADFR.getNbOfADFs();
	}
	
	public int getMaxDepth(){
		return maxDepth;
	}
	
	public void setMaxDepth(int mxDepth){
		maxDepth = mxDepth;
	}

	public void setADFR(ADFRules ADFrules){
		ADFR = ADFrules;
	}
	
	public Object clone(){
		return new ProgramRules(maxDepth, nbOfInputs, nbOfClasses, proportionInput,
				proportionFloatConstant, (ADFRules)ADFR.clone(),
				(FunctionRules)functionRules.clone());
	}
	
	public String toString(){
		return "\nMaximum depth of program tree: " + maxDepth +
		       "\nNumber of Inputs for programs: " + nbOfInputs + 
		       "\nNumber of available classes: " + nbOfClasses +
		       "\nNumber of possible content (input and functions) for nodes: " + nbOfPossibleContents +
		       "\nProportion of input in terminals : " + proportionInput +
		       "\nProportion of float constants (comprared to integer constants): " + proportionFloatConstant +
		       "\n" + ADFR.toString() +
		       "\n" + functionRules.toString();		       
	}
}
