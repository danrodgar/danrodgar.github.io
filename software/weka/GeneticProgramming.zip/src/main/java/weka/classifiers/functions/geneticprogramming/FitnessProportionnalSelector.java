package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;

public class FitnessProportionnalSelector extends ProgramSelector {

	double probability[];
	
	public void prepareRanking(Vector pop, FitnessEvaluator FE, double pV) {
		int popSize = pop.size();
		probability = new double[popSize];
		
		double sumFitness = 0;
		double bestFitness;
		double fitness;
		int i;
	
		if(FE.lowerIsBetter()){
			bestFitness = Double.POSITIVE_INFINITY;
			for(i=0;i<popSize;i++){
				fitness = ((Program)pop.get(i)).getTrainingFitness();
				if(fitness < bestFitness)
					bestFitness = fitness;
				sumFitness += fitness;
			}
			
			for(i=0;i<popSize;i++){
				probability[i] = 1.0 - ( ((Program)pop.get(i)).getTrainingFitness() / sumFitness);
			}			
		}else{
			bestFitness = 0;
			for(i=0;i<popSize;i++){
				fitness = ((Program)pop.get(i)).getTrainingFitness();
				if(fitness > bestFitness)
					bestFitness = fitness;
				sumFitness += fitness;
			}
			
			for(i=0;i<popSize;i++){
				probability[i] = ((Program)pop.get(i)).getTrainingFitness() / sumFitness;
			}			
		}

	}

	public Vector selectPrograms(Vector pop, FitnessEvaluator FE, int number, double pV) {
		Vector programPositions = new Vector();
		for(int i = 0;i<number;i++){
			int selected = -1;
			double sum = 0;
			double random = Math.random();
			do{
				selected++;
				sum += probability[selected];
			}
			while(sum < random);
			
			programPositions.add(new ProgramPosition(selected, (Program)pop.get(selected)));
		}
		sortProgramPositions(programPositions, FE, 0.0);
		return programPositions;
	}

	public boolean usuallyReplaces() {
		return false;
	}
	
	public Object clone(){
		return new FitnessProportionnalSelector();
	}
	
	public String toString(){
		return new String("Fitness-proportionnal Selector : selects programs with probability based on " +
				"fitness (with fitness / sumFitness probability for each program).");
	}

}
