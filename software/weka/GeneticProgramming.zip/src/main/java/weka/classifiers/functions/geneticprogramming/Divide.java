package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Divide extends Function {

	public Divide(ArgumentType AT){
		super(AT);
		name = "/";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 2;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		if(argVal[1] == (double) 0.0)
			return (double) 1.0;
		return argVal[0] / argVal[1];
	}
}
