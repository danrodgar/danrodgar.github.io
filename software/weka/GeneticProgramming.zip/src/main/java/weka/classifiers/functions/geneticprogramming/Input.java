/*
 * Created on 2005-12-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.Content;
import weka.classifiers.functions.geneticprogramming.Input;
import weka.classifiers.functions.geneticprogramming.Program;

/**
 * @author vision
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Input extends Content implements Serializable, Cloneable {

	private int inputNo;
	
	public Input(int noOfInputs){
		inputNo = (int)(Math.random()*noOfInputs);
	}
	
	public Input(Input toCopy){
		inputNo = toCopy.inputNo;
	}
	
	public int getInputNo(){
		return inputNo;
	}
	
	public Object getContent(){
		return new Integer(inputNo);
	}
	
	public void setInputNo(int i){
		inputNo = i;
	}
		
	public int nbOfChildren(){
		return 0;
	}
	
	// Clone
	public Object clone(){
		return new Input(this);
	}
	
	// Evaluation of the Node.
	public double execute(Program prog, double inputArgs[], double childArgs[]){
		return inputArgs[inputNo];
	}
	
	public int getTypeOfArg(int argNumber){
		return -1;
	}
	
	// Management of text format output.
	public String toString(String inputNames[], String classNames[],  int nbChild, String childString[]){
		String outputString;
		if (inputNames == null){
			outputString = "Input#" + (inputNo+1);
		}else{
			if(inputNames[inputNo].length() > 25){
				outputString = "Input#" + (inputNo+1);
			}else{
				outputString = inputNames[inputNo];
			}
		}
		return outputString;
	}
	
	// Management of text format output.
	public String toStringADF(int nbChild, String classNames[],  String childString[]){
		return "Input#" + (inputNo+1);
	}
}
