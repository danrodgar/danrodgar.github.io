package weka.classifiers.functions.geneticprogramming;

import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramPosition;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;

public class ExponentialRankingSelector extends ProgramSelector {

	double probability[];
	double biasConstant;

	public ExponentialRankingSelector(double bConstant) throws Exception{
		// bConstant is a Bias Constant that must be between 0 and 1
		if((bConstant <= 0) || (bConstant >=1 )){
			Exception e = new Exception("The Bias Constant for ExponentialRankingSelector must be greater than 0 and less than 1.\n");
			throw e;
		}
		biasConstant = bConstant;
	}
	
	public void prepareRanking(Vector pop, FitnessEvaluator FE, double pV) {
		int rank,popSize = pop.size();		
		probability = new double[popSize];
		
		ProgramSelector.sortProgramPopulation(pop, FE, 0.0); 	
		
		double sum = 0, newSum = 0;
		for(rank=0;rank<popSize;rank++){
			// probability[rank] = Math.pow(biasConstant, (double) popSize) * ((biasConstant - 1.0)/(Math.pow(biasConstant, (double) popSize)-1.0))-((double)rank+1);
			// probability[rank] = biasConstant + Math.pow( (((double)rank) / ((double) popSize - 1.0)),(double)rank) * (1.0 - biasConstant);
			probability[rank] = Math.exp((double)-rank * biasConstant);
			sum += probability[rank];
		}	
		
		for(rank=0;rank<popSize;rank++){
			// probability[rank] = Math.pow(biasConstant, (double) popSize) * ((biasConstant - 1.0)/(Math.pow(biasConstant, (double) popSize)-1.0))-((double)rank+1);
			probability[rank] /= sum;
			newSum += probability[rank];
		}	
		
		probability[popSize-1] += Math.max(1.0 - newSum, 0.0);
	}
		
	public Vector selectPrograms(Vector pop, FitnessEvaluator FE, int number, double pV) {
		Vector programPositions = new Vector();
		for(int i = 0;i<number;i++){
			int selected = -1;
			double sum = 0;
			double random = Math.random();
			do{
				selected++;
				sum += probability[selected];
			}
			while(sum < random);
			
			programPositions.add(new ProgramPosition(selected, (Program)pop.get(selected)));
		}
		ProgramSelector.sortProgramPositions(programPositions, FE, 0.0);
		return programPositions;
	}

	public boolean usuallyReplaces() {
		return false;
	}
	
	public Object clone(){
		try{
			return new ExponentialRankingSelector(biasConstant);
		}catch(Exception E){
			E.printStackTrace();
		}
		return null;
	}
	
	public String toString(){
		return new String("Exponential Ranking Selector : selects programs with probability based on " +
				"of an exponential after ranking programs with fitness. Bias constant is " + biasConstant);
	}

}
