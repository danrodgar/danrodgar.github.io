package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;

/**
 * Class used to determine if the evolution should end.  Encapsulates the target
 * criterions and check the actual values against them.  Supports the following
 * targets:  Maximum time, Maximum Fitness, Maximum Generations.
 * 
 * Maxmimum fitness has to be specified, but other parameters are not mandatory.
 * <B>Because of quantization and rounding errors, a fitness of 1 is not always possible
 * in continuous evaluations. It is thus advisable to set it to a slightly inferior value,
 * such as 0.99. </B>
 * 
 * @author Yan Levasseur
 * @author Gabriel Valois
 *
 */
public class CompletionManager implements Serializable{

    double targetFitness;	//Fitness to attain.
    double maxMinutes;		//Maximum Duration of evolution in minutes. 0=inf.
    int maxGenerations;		//Maximum number of generation to perform. 0=inf.
    double startedTime;		//Time at which the time counter was started.
    String end;
        

    /**
     * Create a new completion manager with the specified paramaters.  The timer
     * is automatically started.
     * @param targetfitness
     * @param generations
     * @param seconds
     */
    public CompletionManager(double targetF, int generations, double minutes) {
        targetFitness = targetF;
        maxGenerations = generations;
        maxMinutes= minutes;
    }
    
    public void start(){
    	startedTime = System.currentTimeMillis();
        startTimer();
    }

    /**
     * Set the fitness to attain.  Evolution will end if the current fitness is greater
     * or equal to the targetFitness.  Warning: read class description before using.
     * @param fitness fitness to attain.
     */
    public void setFitnessGoal(double fitness){
    	targetFitness = fitness;
    }
    
    /**
     * Set the maximum number of generation create.  Evolution will stop if the specified
     * number of generations is attained.
     * @param nbGen Maximum number of generations. Set to 0 to disable.
     */
    public void setMaxGenerations(int nbGen){
    	maxGenerations = nbGen;
    }
    
    /**
     * Set the maximum duration of evolution.  Evolution will stop if the specified
     * duration has elapsed.  Note: the timer is not stopped if the evolution is paused.
     * @param seconds  Maximum duration of evolution. Set to 0 to disable.
     */    
    public void setDuration(int minutes){
    	maxMinutes = minutes;
    }
    
    /**
     * Check the specified values again the parameters of this object to determine
     * if the evolution should stop.
     * @param curGen The actual generation
     * @param actualFitness The actuel fitness
     * @return true if evolution should be complete, false otherwise.
     */
    public boolean isCompleted(int curGen, double actualFitness, FitnessEvaluator fe) {
     
    	boolean completed=false;
    	
    	// Check if maximum number of generations attained
    	if(maxGenerations != 0){
    		if (curGen >= maxGenerations){
    			completed=true;
    			end = "Evolution ended at " + (curGen) + "th generation. (T = " + getTime() + " minutes, F = " + actualFitness + ")";
    		}
    	}    	    	
    	
    	// check if maximum time attained
    	if (maxMinutes != 0) {
    		if(getTime()>maxMinutes){	
                end = "Evolution ended after " + getTime() + " minutes. (G = " + curGen + ", F = " + actualFitness + ")";
                completed=true;
            }
        }
    	    	
    	//check if maximum fitness attained
    	if((fe.lowerIsBetter() && actualFitness <= targetFitness) || (!(fe.lowerIsBetter()) && actualFitness >= targetFitness)){
    		end = "Evolution ended with fitness " + actualFitness + " attained. (G = " + curGen + ", T = " + getTime() + " minutes)";
    		completed=true;
    	}
    	
    	return completed;
    }


    /**
     * Reset the timer. 
     */
    public void startTimer() {
        startedTime = System.currentTimeMillis();
    }
    
    /**
     * @return number of minutes since the timer was started or object constructed.
     */
    public double getTime() {
        return  ((System.currentTimeMillis()-startedTime)/60000);
    }    

    public String getEndMessage() {
        return end;
    }
    
    public Object clone(){
    	return new CompletionManager(targetFitness, maxGenerations, maxMinutes);
    }
    
    public String toString(){
    	return "Target fitness = " + targetFitness + "\nMaximum time = " + maxMinutes + " minutes" + "\nMax generations = " + maxGenerations;
    } 
}
