package weka.classifiers.functions.geneticprogramming;

import java.util.Enumeration;

import weka.core.Instance;
import weka.core.Instances;

public class OneClassWeightEvaluator implements FitnessEvaluator, java.io.Serializable {

	private int currentClass;
	
	public OneClassWeightEvaluator(int theClass){
		currentClass = theClass;
	}
	
	public Double getInferiorBound() {
		return new Double(0.0);
	}

	public Double getSuperiorBound() {
		return new Double(1.0);
	}

	public boolean isNominal() {
		return true;
	}

	public boolean isNumeric() {
		return false;
	}

	public boolean lowerIsBetter() {
		return false;
	}

	public double measureFitness(Instances ins, Program prog) {
		
		float scoreSum = 0; 
		Enumeration enu = ins.enumerateInstances();		
			while(enu.hasMoreElements()){
				Instance instance = (Instance)enu.nextElement();
	            double[] record = instance.toDoubleArray();
	            
	            double score = prog.execute(record);
	            
	            if(new Double(score).isNaN())
	            	score = 0.0;
	            else if(score > 1.0)
	            	score = 1.0;
	            else if(score < 0.0)
	            	score = 0.0;
	            
	            double w = instance.weight();
	            double c = instance.classValue();
	            
	            if(score >= 0.5 &&  c == currentClass)
	            	scoreSum += score * w  ; // scores !
	            
	            else if(score < 0.5 && c != currentClass)
	            	scoreSum += (1.0 - score) * w ; // scores !
	            
	            else if(score >= 0.5 && c != currentClass)
	            	scoreSum -= score * w; // wrong !
	            
	            else // if(score < 0.5 && c == currentClass)
	            	scoreSum -= (1.0 - score) * w; // wrong !
			}			
			
			return ((scoreSum + (double)ins.numInstances() )/ (2.0 * (double)ins.numInstances()));
	}

	public double measureFitness(Instance ins, Program prog) {
		double[] record = ins.toDoubleArray();
        
        double score = (float)prog.execute(record);
        
        if(new Double(score).isNaN())
        	score = 0.0;
        else if(score > 1.0)
        	score = 1.0;
        else if(score < 0.0)
        	score = 0.0;
        return score;
	}
	
	public String toString(){
		return new String("One Class Weight Evaluator : returns confidence (0.0 to 1.0) of instance being of current class");
	}

}