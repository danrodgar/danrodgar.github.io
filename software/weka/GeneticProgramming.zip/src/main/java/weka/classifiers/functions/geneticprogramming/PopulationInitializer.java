package weka.classifiers.functions.geneticprogramming;
import java.util.Vector;

import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.Program;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.core.Instances;

public interface PopulationInitializer {
	
	public abstract Program createProgram(ProgramRules PR, FitnessEvaluator fe, Instances trainIns, Instances valIns, double pV);
	public abstract Vector createPopulation(int popSize, ProgramRules PR, FitnessEvaluator fe, EliteManager EM, Instances trainIns, Instances valIns, double pV);
	public abstract String getProgramTypeString();
	public abstract Object clone();
}
