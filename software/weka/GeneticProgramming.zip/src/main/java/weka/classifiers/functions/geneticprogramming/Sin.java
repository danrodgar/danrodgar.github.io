package weka.classifiers.functions.geneticprogramming;

import java.io.Serializable;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class Sin extends Function {
	
	public Sin(ArgumentType AT){
		super(AT);
		name = "Sin";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 1;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		return Math.sin(argVal[0]);
	}
}