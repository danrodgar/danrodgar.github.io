package weka.classifiers.functions.geneticprogramming;

import weka.classifiers.functions.geneticprogramming.ArgumentType;
import weka.classifiers.functions.geneticprogramming.Function;

public class SquareRoot extends Function {

	public SquareRoot(ArgumentType AT){
		super(AT);
		name = "Sqrt";
		functionType = AT.checkType("Arithmetic");
		
		nbArgs = 1;
		argTypes = new int[nbArgs];
		for(int i=0;i<nbArgs;i++)
			argTypes[i] = AT.checkType("Arithmetic");
	}
	
	public double execute(double argVal[]){
		if(argVal[0]>=0)
			return Math.sqrt(argVal[0]);
		else
			return -Math.sqrt(-argVal[0]);
	}
}
