package weka.classifiers.functions.geneticprogramming;
import weka.classifiers.functions.geneticprogramming.EliteManager;
import weka.classifiers.functions.geneticprogramming.FitnessEvaluator;
import weka.classifiers.functions.geneticprogramming.GeneticOperator;
import weka.classifiers.functions.geneticprogramming.ProgramRules;
import weka.classifiers.functions.geneticprogramming.ProgramSelector;
import weka.core.Instances;
import java.util.Vector;

public abstract class EvolutionController implements java.io.Serializable{
	
	boolean doReplacement;
	
	abstract public Vector evolveOneGeneration(Instances trainIns, Instances valIns, Vector pop, FitnessEvaluator FE, ProgramSelector PS, EliteManager EM, Vector operators, ProgramRules PR, double pV);
	abstract public Object clone();
	
	protected GeneticOperator getGeneticOperator(Vector operators) throws Exception{
		int i=0, nbOfOperators = operators.size();
		double random = Math.random();
		double sum = ((GeneticOperator)operators.get(i)).getProportion();
		
		while(sum < random && i<nbOfOperators){
			sum += ((GeneticOperator)operators.get(++i)).getProportion();
		}
		
		if(i >= nbOfOperators){
			Exception E = new Exception("The total of your genetic operators' probabilities is less than 100% (1.0)");
			throw E;
		}
		return ((GeneticOperator)operators.get(i));
	}
}
