package main.java.mnds.util_ens;

import java.util.ArrayList;

import main.java.mnds.algorithms.ENS_NDT;

public class NDNode {
	public NDSplit Split;
	private ArrayList<double[]> Points;

	public NDNode WorseNode;
	public NDNode BetterNode;

	public boolean IsBranch() {
		return Points == null;
	}

	//	public boolean IsLeaf() {
	//		return Points != null;
	//	}

	//EMPTY CONSTRUCTOR
	public NDNode() {
		Split = null;
		Points = null;
	}

	public NDNode(NDSplit split) {
		Split = split;
		Points = new ArrayList<double[]>(ENS_NDT.N);
	}

	public void AddPoint(double[] point) {
		if (Points != null) { //(IsLeaf()) {
			Points.add(point);
			if (Points.size() > ENS_NDT.BUCKET_SIZE && Split != null)
				SplitLeaf();
			return;
		}

		if (Split.IsWorse(point))
			WorseNode = AddPointToNode(point, WorseNode, Split.WorseSplit);
		else
			BetterNode = AddPointToNode(point, BetterNode, Split.BetterSplit);
	}

	public boolean Dominates(double[] s) {
		for (double[] f : Points) {
			if (Dominates(f, s, ENS_NDT.M))
				return true;
		}
		return false;
	}

	private void SplitLeaf() {
		ArrayList<double[]> points = Points;
		Points = null;

		for (double[] point : points)
			AddPoint(point);
	}

	private NDNode AddPointToNode(double[] point, NDNode node, NDSplit split) {
		if (node == null)
			node = new NDNode(split);
		else if (null == node.Split) { //|@# GESTION EMPTY
			node.Split = split;
		}
		node.AddPoint(point);
		return node;
	}

	private boolean Dominates(double[] a, double[] b, int M) {
		boolean dominates = false;
		for (int i = 0; i < M; ++i) {
			ENS_NDT.comparisonCounter++;
			if (b[i] < a[i])
				return false;
			ENS_NDT.comparisonCounter++;
			if (a[i] < b[i])
				dominates = true;
		}
		return dominates;
	}

	@Override
	public String toString() {
		String w = "{}", b = "{}", s = "{*";
		int M = ENS_NDT.M;
		if (Points != null)
			for (int i = 0; i < Points.size(); i++)
				s = s + (int) Points.get(i)[M] + " ";
		s = s + "}";

		if (WorseNode != null)
			w = WorseNode.toString();
		if (BetterNode != null)
			b = BetterNode.toString();
		s = w + "<-" + s + "->" + b;
		return s;
	}
}
