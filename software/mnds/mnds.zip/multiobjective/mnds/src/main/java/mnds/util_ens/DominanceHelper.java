package main.java.mnds.util_ens;

/**
 * This is a helper class for the ENS-SS and ENS-BS algorithms.
 * Original implementation by:
 * M. Buzdalov
 * https://github.com/mbuzdalov/non-dominated-sorting/
 * The code has been modified the minimum necessary to include it in this
 * project.
 * 
 */

public final class DominanceHelper {
	private DominanceHelper() {
	}

	private static final int HAS_LESS_MASK = 1;
	private static final int HAS_GREATER_MASK = 2;

	private static final int[] REINDEX = { 0, -1, 1, 0 };
	public static long comparisonCounter;
	//	public static boolean strictlyDominates(double[] a, double[] b) {
	//		return detailedDominanceComparison(a, b, HAS_GREATER_MASK) == HAS_LESS_MASK;
	//	}

	public static int dominanceComparison(double[] a, double[] b, int dim) {
		int rv = detailedDominanceComparison(a, b, HAS_GREATER_MASK | HAS_LESS_MASK, dim);
		return REINDEX[rv];
	}

	private static int detailedDominanceComparison(double[] a, double[] b, int breakMask, int dim) {
		comparisonCounter = 0;
		// int dim = a.length;// como usamos el ultimo obj para el id de la solucion, hay que pasar este valor
		int result = 0;
		for (int j = 0; j < dim; ++j) {
			//double ai = a[j], bi = b[j];
			//if (ai < bi) {
			comparisonCounter += 2;
			if (a[j] < b[j]) {
				result |= HAS_LESS_MASK;
				comparisonCounter--;
			} else if (a[j] > b[j]) {//if (ai > bi) {
				result |= HAS_GREATER_MASK;
			}
			if ((result & breakMask) == breakMask) {
				break;
			}
		}
		return result;
	}

	public static boolean strictlyDominates(double[] a, double[] b, int dim) {
		comparisonCounter = 0;
		//int dim = a.length; // como usamos el ultimo obj para el id de la solucion, hay que pasar este valor
		int result = 0;
		for (int j = 0; j < dim; ++j) {
			//double ai = a[j], bi = b[j];
			comparisonCounter += 2;
			if (a[j] < b[j]) {//if (ai < bi) {
				result |= HAS_LESS_MASK;
				comparisonCounter--;
			} else if (a[j] > b[j]) {//if (ai > bi) {
				result |= HAS_GREATER_MASK;
			}
			if ((result & HAS_GREATER_MASK) == HAS_GREATER_MASK) {
				return false;
			}
		}
		return result == 1;
	}
}
