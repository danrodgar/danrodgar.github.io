package main.java.mnds.tools;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * @author Javier Moreno
 */

public final class Tools {
	private Tools() {
	}

	public static boolean createLogger(String logName) {
		PrintWriter logger = null;
		try {
			logger = new PrintWriter(logName, "UTF-8");
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
			return false;
		}
		logger.flush();
		logger.close();
		return true;
	}

	public static PrintWriter openLogger(String logName) {
		PrintWriter logger = null;
		try {
			logger = new PrintWriter(new FileWriter(logName, true));
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return logger;
	}

	public static void closeLogger(PrintWriter pw) {
		if (null != pw) {
			pw.flush();
			pw.close();
		}
	}
}
