package main.java.mnds.algorithms;

/**
 * This class implements the HNDS algorithm
 * 
 * @author Javier Moreno
 * 
 */
public class HNDS {
	private static final int INSERTIONSORT = 9;
	protected double[][] _Q, _R;
	protected int[] ranks = null;
	protected double[] temp;
	protected static long comparationCounter;
	protected static int _N, _M;
	protected double[][] _ND;

	public HNDS(int n, int m) {
		_N = n;
		_M = m;
		_R = new double[_N][];
		ranks = new int[_N];
		_ND = new double[_N][];
	}

	final public void close() {
		_R = null;
		ranks = null;
		_ND = null;
	}

	final public long getComparisonCounter() {
		return comparationCounter;
	}

	private static final int HAS_LESS_MASK = 1;
	private static final int HAS_GREATER_MASK = 2;

	final public static boolean notDominates(double[] a, double[] b) {
		int result = 0;
		for (int j = 0; j < _M; j++) {
			comparationCounter += 2;
			if (a[j] < b[j]) {
				result |= HAS_LESS_MASK;
				comparationCounter--;
			} else if (a[j] > b[j]) {
				result |= HAS_GREATER_MASK;
			}
			if ((result & HAS_GREATER_MASK) == HAS_GREATER_MASK) {
				return true;
			}
		}
		return result != 1;
	}

	final private static int compare(double[] s1, double[] s2) {
		for (int obj = 0; obj < _M; obj++) {
			comparationCounter += 2;
			if (s1[obj] < s2[obj]) {
				comparationCounter--;
				return -1;
			} else if (s1[obj] > s2[obj]) {
				return 1;
			}
		}
		return 0;
	}

	final private void mergesort(double src[][], double dest[][], int low, int high) {
		int i, j, s;
		if (high - low < INSERTIONSORT) {
			for (i = low; i < high; i++) {
				for (j = i; j > low && compare(dest[j - 1], dest[j]) > 0; j--) {
					temp = dest[j];
					dest[j] = dest[j - 1];
					dest[j - 1] = temp;
				}
			}
			return;
		}
		int mid = (low + high) >> 1;
		mergesort(dest, src, low, mid);
		mergesort(dest, src, mid, high);
		for (s = low, i = low, j = mid; s < high; s++) {
			dest[s] = (j >= high || (i < mid && compare(src[i], src[j]) <= 0)) ? src[i++] : src[j++];
		}
	}

	final public int[] sort(double[][] p) {
		comparationCounter = 0;
		_Q = p.clone();
		double[][] tmp;
		int lastR = 0;
		int i = 0, j, k = -1;
		int qLength = _N;
		while (qLength > 0) {
			k++;
			mergesort(p, _Q, 0, qLength);
			while (qLength > 0) {
				i = 0;
				ranks[(int) _Q[0][_M]] = k;
				for (j = 1; j < qLength; j++) {
					if (notDominates(_Q[0], _Q[j])) // if Q0 do not dominates Qj
						_ND[i++] = _Q[j];
					else
						_R[lastR++] = _Q[j];
				}
				// move ND to Q
				tmp = _Q;
				_Q = _ND;
				_ND = tmp;
				// move ND to Q
				qLength = i;
			}
			//Move R to Q
			tmp = _Q;
			_Q = _R;
			_R = tmp;
			// Move R to Q
			if (_Q == _ND || _R == _ND)
				throw (new RuntimeException("Error HNDS"));

			qLength = lastR;
			lastR = 0; // clearR
			p = _Q.clone();
		}
		return ranks;
	}
}
