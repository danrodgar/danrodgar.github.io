package main.java.mnds.util_ens;

import main.java.mnds.algorithms.ENS_NDT;

public class NDIndividual {
	// NDIndividual specific information
	public int Id;
	//public double[] Inputs;
	public double[] Outputs;
	public int Rank;

	// For T-ENS
	//public ArrayList<NDIndividual> Branch = new ArrayList<NDIndividual>();
	//public int[] ObjSeq = null;

	public NDIndividual() {
	}

	public NDIndividual(double[] outputs) {
		Outputs = new double[ENS_NDT.M + 1];
		System.arraycopy(outputs, 0, Outputs, 0, ENS_NDT.M + 1);
		Id = (int) outputs[ENS_NDT.M];
	}

	public NDIndividual(int inputCount, int outputCount) {
		//		if (inputCount > 0)
		//			Inputs = new double[inputCount];

		if (outputCount > 0)
			Outputs = new double[outputCount];
	}

	public NDIndividual(NDIndividual source) {
		Rank = source.Rank;
		//		if (source.Inputs != null) {
		//			Inputs = new double[source.Inputs.length];
		//			System.arraycopy(source.Inputs, 0, Inputs, 0, source.Inputs.length);
		//		}
		if (source.Outputs != null) {
			Outputs = new double[ENS_NDT.M + 1];
			System.arraycopy(source.Outputs, 0, Outputs, 0, ENS_NDT.M + 1);
		}
		Id = source.Id;
	}

	/*
	public NDIndividual Clone() {
		NDIndividual clone = new NDIndividual();
		clone.Rank = Rank;
		//		if (Inputs != null) {
		//			clone.Inputs = new double[Inputs.length];
		//			System.arraycopy(Inputs, 0, clone.Inputs, 0, Inputs.length);
		//		}
		if (Outputs != null) {
			clone.Outputs = new double[Outputs.length];
			System.arraycopy(Outputs, 0, clone.Outputs, 0, Outputs.length);
		}
		clone.Id = Id;
		return clone;
	}
	*/

	public void Reset() {
		Rank = 0;
		//ObjSeq = null;
		//Branch = null;
	}

	@Override
	public String toString() {
		String s = "i" + Id;
		return s;
	}
}
