package main.java.mnds.tools;

/**
 * @author Javier Moreno
 */

public class Range {
	double _min, _max;

	public Range() {
		_min = Double.POSITIVE_INFINITY;
		_max = Double.NEGATIVE_INFINITY;
	}

	@Override
	public String toString() {
		return new String("[" + _min + " " + _max + "]");
	}

	public Range(double minLeft, double maxRight) {
		if (minLeft < maxRight) {
			_min = minLeft;
			_max = maxRight;
		} else {
			_max = minLeft;
			_min = maxRight;
		}
	}

	public double getMin() {
		return _min;
	}

	public double getMax() {
		return _max;
	}
}
