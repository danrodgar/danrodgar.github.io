package main.java.mnds.util_ens;

import java.util.Arrays;
import java.util.Comparator;

import main.java.mnds.algorithms.ENS_NDT;

public class NDSplit {
	public int Dimensions;
	public int SplitDimension;
	public double SplitValue;
	public NDSplit WorseSplit;
	public NDSplit BetterSplit;
	private static int ComparerDimension;

	public boolean IsWorse(double[] point) {
		//ENS_NDT.comparisonCounter++;
		return point[SplitDimension] >= SplitValue;
	}

	public boolean IsBetter(double[] point) {
		//ENS_NDT.comparisonCounter++;
		return point[SplitDimension] < SplitValue;//|@# !IsWorse(point);
	}

	public static NDSplit GenerateSplits(double[][] points, int dimensions, int bucketSize) {
		return GenerateSplits(points, 0, dimensions, bucketSize, 0, points.length);
	}

	public static NDSplit GenerateSplits(double[][] points, int dimensions) {
		//default bucketSize = 2
		return GenerateSplits(points, 0, dimensions, 2, 0, points.length);
	}

	private static NDSplit GenerateSplits(double[][] points, int dimension, int dimensions, int bucketSize,
			int startIndex, int count) {
		if (count <= bucketSize)
			return null;

		//points.Sort(startIndex, count, new SplitComparer(dimension));
		Arrays.sort(points, startIndex, startIndex + count, SplitComparer);

		int betterCount = (count + 1) / 2;
		int worseCount = count / 2;
		int startIndex2 = startIndex + betterCount;
		int nextDimension = (dimension + 1) % dimensions;

		NDSplit split = new NDSplit();
		split.Dimensions = dimensions;
		split.SplitDimension = dimension;
		split.SplitValue = points[startIndex2][dimension];
		split.BetterSplit = GenerateSplits(points, nextDimension, dimensions, bucketSize, startIndex, betterCount);
		split.WorseSplit = GenerateSplits(points, nextDimension, dimensions, bucketSize, startIndex2, worseCount);

		return split;
	}

	private static Comparator<double[]> SplitComparer = new Comparator<double[]>() {
		public int compare(double[] x, double[] y) {
			ENS_NDT.comparisonCounter++;
			if (x[ComparerDimension] < y[ComparerDimension])
				return -1;
			ENS_NDT.comparisonCounter++;
			if (x[ComparerDimension] > y[ComparerDimension])
				return 1;
			return 0;
			//			return x[ComparerDimension] < y[ComparerDimension] ? -1
			//					: x[ComparerDimension] > y[ComparerDimension] ? 1 : 0;
		}
	};
}
