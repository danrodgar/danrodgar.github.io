
package main.java.mnds.algorithms;

import java.util.Arrays;

import main.java.mnds.util_ens.DominanceHelper;
import main.java.mnds.util_ens.DoubleArraySorter;

public class ENS_SS {
	protected int[] indices = null;
	protected int[] ranks = null;
	protected int[] prevIndex = null;
	protected int[] lastRankIndex = null;
	protected DoubleArraySorter sorter = null;
	protected long _comparisons;
	protected int lastRanking, n, m;

	public ENS_SS(int maximumPoints, int maximumDimension) {
		n = maximumPoints;
		m = maximumDimension;
		sorter = new DoubleArraySorter(maximumPoints);
		indices = new int[maximumPoints];
		prevIndex = new int[maximumPoints];
		ranks = new int[maximumPoints];
		lastRankIndex = new int[maximumPoints];
		_comparisons = 0;
		lastRanking = 0;
	}

	final boolean frontDominates(int frontIndex, double[][] points, double[] point) {
		int index = lastRankIndex[frontIndex];
		while (index >= 0) {
			if (DominanceHelper.strictlyDominates(points[index], point, m)) {
				_comparisons += DominanceHelper.comparisonCounter;
				return true;
			}
			_comparisons += DominanceHelper.comparisonCounter;
			index = prevIndex[index];
		}
		return false;
	}

	final public long getComparisonCounter() {
		return _comparisons;
	}

	final public void close() {
		sorter = null;
		indices = null;
		prevIndex = null;
		lastRankIndex = null;
		ranks = null;
	}

	final void sortCheckedImpl(double[][] points, int[] ranks) { //, int maximalMeaningfulRank) {
		_comparisons = 0;
		int n = ranks.length, currRank;
		int maxRank = -1, index;
		double point[];
		for (int i = 0; i < n; ++i) {
			index = indices[i];
			currRank = 0;
			//			currRank = findRank(points, index, maxRank);
			point = points[index];
			while (currRank <= maxRank) {
				if (frontDominates(currRank, points, point)) {
					++currRank;
				} else {
					break;
				}
			}
			// maxRank = setRank(index, ranks, currRank, maxRank);
			if (currRank > maxRank) {
				maxRank = currRank;
				lastRankIndex[maxRank] = -1;
			}
			prevIndex[index] = lastRankIndex[currRank];
			lastRankIndex[currRank] = index;
			ranks[index] = currRank;
		}
	}

	final public int[] sort(double[][] points) {
		int n = ranks.length;
		for (int i = 0; i < n; i++)
			indices[i] = i;
		Arrays.fill(ranks, -1);
		Arrays.fill(prevIndex, -1);
		sorter.lexicographicalSort(points, indices, 0, n, points[0].length);
		sortCheckedImpl(points, ranks);

		return ranks;
	}

}
