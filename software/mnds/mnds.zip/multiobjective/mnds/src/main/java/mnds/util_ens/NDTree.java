package main.java.mnds.util_ens;

public class NDTree {
	protected NDNode root;

	public NDTree(NDSplit split) {
		root = new NDNode(split);
	}

	public void Insert(double[] point) {
		root.AddPoint(point);
	}

	public boolean Dominates(double[] point) {
		return Dominates(point, root);
	}

	private boolean Dominates(double[] point, NDNode node) {
		if (node.IsBranch()) {
			if (node.WorseNode != null && node.Split.IsWorse(point) && Dominates(point, node.WorseNode))
				return true;
			return node.BetterNode != null && Dominates(point, node.BetterNode);
		}
		return node.Dominates(point);
	}

	@Override
	public String toString() {
		return root.toString();
	}
}
