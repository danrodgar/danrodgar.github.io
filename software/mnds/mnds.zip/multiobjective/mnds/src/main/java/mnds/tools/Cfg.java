package main.java.mnds.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * @author Javier Moreno <javier.morenom@edu.uah.es>
 */

public final class Cfg {

	public static Properties read(String fileName, String defaultConfiguration) {
		Properties prop = null;
		String dir = "";
		try {
			boolean existFile = true;
			if (Files.notExists(Paths.get(fileName))) {
				if (null != defaultConfiguration) {
					File wDir = new File(".");
					dir = wDir.getAbsolutePath();
					dir = dir.substring(0, dir.length() - 1);//quitamos el . del final
					wDir = null;
					PrintWriter defaultConf = new PrintWriter(dir + fileName, "UTF-8");
					defaultConf.print(defaultConfiguration);
					defaultConf.close();
				} else {
					existFile = false;
				}
			}
			if (existFile) {
				File file = new File(fileName);
				FileInputStream fis = new FileInputStream(file);
				byte[] data = new byte[(int) file.length()];
				fis.read(data);
				fis.close();
				String str = new String(data, "UTF-8");
				prop = new Properties();
				prop.load(new StringReader(str.replace("\\", "\\\\")));
			}
		} catch (IOException e1) {
			System.out.println("Error intentando crear el archivo: " + dir + fileName);
			System.out.println(e1.getMessage());
			e1.printStackTrace();
		}

		return prop;
	}

	public static void write(String fileName, Properties props) {
		OutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			props.store(fos, null);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != fos) {
				try {
					fos.close();
				} catch (IOException ex) {
					System.out.println("Error intentando crear el archivo: " + fileName);
					System.out.println(ex.getMessage());
					ex.printStackTrace();
				}
			}
		}
	}

	public static double[] getDoubleArray(Properties p, String key) {
		if (!existKey(p, key))
			return null;
		double[] array = null;
		String s = p.getProperty(key).trim();
		if (null != s) {
			String[] a = s.split(",");
			array = new double[a.length];
			for (int i = 0; i < a.length; i++) {
				try {
					array[i] = Double.parseDouble(a[i]);
				} catch (NumberFormatException ex) {
					array[i] = Double.POSITIVE_INFINITY;
				}
			}
		}
		return array;
	}

	public static int[] getIntegerArray(Properties p, String key) {
		if (!existKey(p, key))
			return null;
		int[] array = null;
		String s = p.getProperty(key).trim();
		if (null != s) {
			String[] a = s.split(",");
			array = new int[a.length];
			for (int i = 0; i < a.length; i++) {
				try {
					array[i] = Integer.parseInt(a[i]);
				} catch (NumberFormatException ex) {
					array[i] = Integer.MAX_VALUE;
				}
			}
		}
		return array;
	}

	public static boolean[] getBooleanArray(Properties p, String key) {
		if (!existKey(p, key))
			return null;
		boolean[] array = null;
		String value;
		String s = p.getProperty(key).trim();
		if (null != s) {
			String[] a = s.split(",");
			array = new boolean[a.length];
			for (int i = 0; i < a.length; i++) {
				value = a[i].toLowerCase();
				array[i] = value.contains("1") || value.contains("tr") || value.contains("t");
			}
		}
		return array;
	}

	public static boolean existKey(Properties p, String key) {
		return null != p.getProperty(key);
	}

	public static double getDouble(Properties p, String key) {
		return stringToDouble(p.getProperty(key), Double.MAX_VALUE);
	}

	public static int getInt(Properties p, String key) {
		return (int) stringToLong(p.getProperty(key), Integer.MAX_VALUE);
	}

	public static long getLong(Properties p, String key) {
		return stringToLong(p.getProperty(key), Long.MAX_VALUE);
	}

	public static long getTimeOut(Properties p, String key) {
		return Long.parseLong(p.getProperty(key).trim());
	}

	public static String getString(Properties p, String key) {
		if (!existKey(p, key))
			return null;
		return p.getProperty(key);
	}

	public static boolean getBoolean(Properties p, String key) {
		String s = p.getProperty(key).trim();
		s = s.toLowerCase();
		if (s.length() == 1)
			return s.charAt(0) == '1' || s.charAt(0) == 't';
		return s.contains("tr");
	}

	public static Range getRange(Properties p, String key) {
		if (!existKey(p, key))
			return null;
		double values[] = new double[2];
		String s0 = p.getProperty(key).trim();

		String s[] = s0.split(";");
		for (int i = 0; i < s.length; i++) {
			if (0 == s[i].compareToIgnoreCase("inf")) {
				values[i] = Double.POSITIVE_INFINITY;
			} else if (0 == s[i].compareToIgnoreCase("-inf")) {
				values[i] = Double.NEGATIVE_INFINITY;
			} else {
				values[i] = Double.parseDouble(s[i]);
			}
		}
		return new Range(values[0], values[1]);
	}

	/////// Conversiones numero <-> cadena
	public static String doubleToStr(double d, String zeros) {
		String total = Double.toString(d);
		if (total.length() < zeros.length()) {
			total = zeros + total;
		}
		total = total.substring(0, zeros.length());
		return total;
	}

	public static String intToStr(double d, String zeros) {
		String total = Double.toString(d);
		if (total.length() < zeros.length()) {
			total = zeros + total;
		}
		total = total.substring(0, zeros.length());
		return total;
	}

	public static double stringToDouble(String s, double defaultValue) {
		double n = defaultValue;
		try {
			if (null != s)
				n = Double.parseDouble(s.trim());
		} catch (NumberFormatException ex) {
		}
		return n;
	}

	public static long stringToLong(String s, long defaultValue) {
		long n = defaultValue;

		try {
			if (null != s)
				n = Long.parseLong(s.trim());
		} catch (NumberFormatException ex) {
		}
		return n;
	}

	public static int stringToInt(String s, int defaultValue) {
		int n = defaultValue;
		try {
			if (null != s)
				n = Integer.parseInt(s.trim());
		} catch (NumberFormatException ex) {
		}
		return n;
	}
}
