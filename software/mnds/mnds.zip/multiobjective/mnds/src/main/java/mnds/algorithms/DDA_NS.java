package main.java.mnds.algorithms;

import java.util.Arrays;
import java.util.Comparator;

public class DDA_NS {
	private static long comparisonCounter = 0;
	private int[] ranking;
	private int[] rowSetTo1, rowSetTo_1;
	private int _N, _M;
	private SolutionComparator solComparator;

	public DDA_NS(int n, int m) {
		_N = n;
		_M = m;
		rowSetTo1 = new int[_N];
		rowSetTo_1 = new int[_N];
		for (int i = 0; i < _N; i++) {
			rowSetTo1[i] = 1;
			rowSetTo_1[i] = -1;
		}
	}

	final public void freeMem() {
		ranking = null;
	}

	final public long getComparisonCounter() {
		return comparisonCounter;
	}

	private class AB {
		AB(double va, int vb) {
			a = va;
			b = vb;
		}

		double a;
		int b;

		@Override
		public String toString() {
			return "[" + b + "]=" + a + " ";
		}
	}

	private class SolutionComparator implements Comparator<AB> {
		@Override
		public int compare(AB s1, AB s2) {
			comparisonCounter += 2;
			if (s1.a < s2.a) {
				comparisonCounter--;
				return -1;
			}
			if (s1.a > s2.a)
				return 1;
			return 0;
		}
	}

	int[][] cnstCmpMat(AB[] w) {
		int i, j, b, b_1;
		int[][] C = new int[_N][_N];
		AB[] ab = new AB[_N];
		System.arraycopy(w, 0, ab, 0, _N);
		Arrays.sort(ab, solComparator); //TODO USO TIM-SORT EN VEZ DE QUICKSORT: ES +RAPIDO
		b = ab[0].b;
		System.arraycopy(rowSetTo1, 0, C[b], 0, _N);//for (j = 0; j < _N; j++) C[b][j] = 1;

		for (i = 1; i < _N; i++) {
			b = ab[i].b;
			comparisonCounter++;
			if (ab[i].a == ab[i - 1].a) {
				b_1 = ab[i - 1].b;
				System.arraycopy(C[b_1], 0, C[b], 0, _N); //for (j = 0; j < _N; j++) C[b][j] = C[b_1][j]; 
			} else {
				for (j = 0; j < _N; j++) {
					comparisonCounter++;
					if (ab[i].a <= ab[j].a)
						C[b][ab[j].b] = 1;
				}
			}
		}
		return C;
	}

	int[][] cnstDomMat(AB[][] populationT) {
		int i, j, k;
		int[][] Cy;
		int[][] D = cnstCmpMat(populationT[0]);
		for (i = 1; i < _M; i++) {
			Cy = cnstCmpMat(populationT[i]);
			for (j = 0; j < _N; j++)
				for (k = 0; k < _N; k++)
					D[j][k] += Cy[j][k];
		}
		return D;
	}

	private AB[][] transposePopulationData(double[][] populationData) {
		AB[][] populationT = new AB[_M][_N];
		for (int i = 0; i < _N; i++) {
			for (int j = 0; j < _M; j++) {
				populationT[j][i] = new AB(populationData[i][j], i);
			}
		}
		return populationT;
	}

	int[] max(int[][] D) {
		int i, j;
		int[] M = new int[_N];
		System.arraycopy(D[0], 0, M, 0, _N);
		// for (j = 0; j < _N; j++) M[j] = D[0][j];

		for (i = 1; i < _N; i++)
			for (j = 0; j < _N; j++)
				if (D[i][j] > M[j])
					M[j] = D[i][j];
		return M;
	}

	double[][] testData() {
		_N = 6;
		_M = 3;
		double[][] t = { { 0.9501, 0.4565, 0.9218 }, { 0.2311, 0.0185, 0.7382 }, { 0.6068, 0.8214, 0.1763 },
				{ 0.2311, 0.0185, 0.4057 }, { 0.8913, 0.6154, 0.9355 }, { 0.9501, 0.4565, 0.9218 } };
		return t;
	}

	final public int[] sort(double[][] populationData) {
		//populationData = testData(); //TODO: 	quitar!!!!!!!!!!!!!!!!!
		_N = populationData.length;
		_M = populationData[0].length;
		solComparator = new SolutionComparator();
		ranking = new int[_N];
		int[] Q = new int[_N + 1];
		Q[0] = 0; // Q[0] is the logical size of Q
		// population data transposing 
		AB[][] P = transposePopulationData(populationData);
		//1. Construct the dominance degree matrix of set P
		int[][] D = cnstDomMat(P);
		//2. For the solutions with indentical objective vectors, set the
		//   corresponding elements of D to zero
		int i, j;
		for (i = 0; i < _N; i++) {
			for (j = 0; j < _N; j++) {
				if (D[i][j] == _M && D[j][i] == _M) {
					D[i][j] = 0;
					D[j][i] = 0;
				}
			}
		}
		// 3. Assign the solutions Y in P to a number of fronts:
		int count = 0; // the number of assigned solutions
		int k = 0; // the first front (in paper fronts starts on 1)
		int q;
		int M[]; //  
		while (count < _N) {
			M = max(D);
			Q[0] = 0; // Q = empty set
			for (i = 0; i < _N; i++) {
				if (M[i] < _M && M[i] >= 0) {
					ranking[i] = k; //Assign rank k to solution i
					Q[++Q[0]] = i;
					count++;
				}
			}
			//set the elements of the i-th row and i-th column in D to -1 
			for (i = Q[0]; i > 0; i--) {
				q = Q[i];
				System.arraycopy(rowSetTo_1, 0, D[q], 0, _N);
				for (j = 0; j < _N; j++) {
					//D[q][j] = -1; lo hace el system.arraycopy
					D[j][q] = -1;
				}
			}
			// Fk = Q  -> Rank already asigned
			k++;
		}
		return ranking; // Q in paper
	}
}
