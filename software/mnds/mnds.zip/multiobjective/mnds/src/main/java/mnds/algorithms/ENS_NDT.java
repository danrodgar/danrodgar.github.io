package main.java.mnds.algorithms;

import java.util.Arrays;
import java.util.Comparator;

import main.java.mnds.util_ens.NDSplit;
import main.java.mnds.util_ens.NDTree;

public class ENS_NDT {
	public static int M, N;
	public static final int BUCKET_SIZE = 8;
	private int[] ranks;
	//jMetal
	public static long comparisonCounter = 0;
	protected int lastRanking;

	public ENS_NDT(int n, int m) {
		N = n;
		M = m;
		this.ranks = new int[N];
		lastRanking = 0;
	}

	final public long getComparisonCounter() {
		return comparisonCounter;
	}

	private static Comparator<double[]> ReverseLexComp = new Comparator<double[]>() {
		public int compare(double[] a, double[] b) {
			int result, outputCount = M;
			for (int oIndex = outputCount - 1; oIndex >= 0; --oIndex) {
				//int result = a[oIndex] < b[oIndex] ? -1 : a[oIndex] > b[oIndex] ? 1 : 0;
				result = 0;
				comparisonCounter += 2;
				if (a[oIndex] < b[oIndex]) {
					result = -1;
					comparisonCounter--;
				} else if (a[oIndex] > b[oIndex]) {
					result = 1;
				}
				if (result != 0)
					return result;
			}
			return 0;
		}
	};

	public void freeMem() {
		ranks = null;
	}

	public int[] sort(double[][] points) {
		double[][] individuals = new double[N][M];
		// Create a copy of the population and sort it in reverse lexicographic order
		System.arraycopy(points, 0, individuals, 0, N);
		Arrays.sort(individuals, ReverseLexComp);

		// Generate the prebalanced splits for the NDTree
		int k = M;
		NDSplit splits = NDSplit.GenerateSplits(points, k - 1, BUCKET_SIZE);

		NDTree[] NDT = new NDTree[N];
		NDTree firstNode = new NDTree(splits);
		firstNode.Insert(individuals[0]);
		NDT[0] = firstNode;
		int NDT_size = 1;

		// Do the non dominated sorting
		int j = 0;
		int nFronts = 1; //|@#nFronts
		for (int i = 1; i < N; ++i) {
			if (!FitnessEquals(individuals[i], individuals[i - 1], k)) {
				j = FrontIndexBinarySearch(individuals[i], NDT, NDT_size);
				//if (j == F.size()) { //|@#nFronts
				if (j == nFronts) {
					// F.add(new ArrayList<NDIndividual>()); //|@#nFronts
					nFronts++;
					NDT[NDT_size] = new NDTree(splits);
					NDT_size++;
				}
				NDT[j].Insert(individuals[i]);
			}
			//F.get(j).add(individuals[i]); //|@#nFronts
			ranks[(int) individuals[i][M]] = j; //rank en formato interno
		}

		return ranks;
	}

	private static int FrontIndexBinarySearch(double[] s, NDTree[] NDT, int NDT_size) {
		int i1 = 0;
		int i2 = NDT_size;
		while (i1 != i2) {
			int i = i1 + (i2 - i1) / 2;
			if (NDT[i].Dominates(s))
				i1 = i + 1;
			else
				i2 = i;
		}
		return i1;
	}

	static private boolean FitnessEquals(double[] a, double[] b, int k) {
		for (int i = 0; i < k; ++i)
			if (a[i] != b[i])
				return false;
		return true;
	}

	final public String getName() {
		return "ENS-NDT";
	}

}
