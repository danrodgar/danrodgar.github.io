package main.java.mnds.util_mnds;

/**
 * 
 * @author Javier Moreno <javier.morenom@edu.uah.es>
 * 
 *         Su objetivo es implementar las operaciones con conjuntos que necesita
 *         el algoritmo MNDS.
 *         Se parte de la premisa de que en MNDS los conjuntos nunca aumentan
 *         de tamaño: solo pueden permanecer igual o reducirse.
 * 
 */
public class MNDSBitsetManager {
	private final static int FIRST_WORD_RANGE = 0;
	private final static int LAST_WORD_RANGE = 1;
	private final static int N_BIT_ADDR = 6;
	private final static int WORD_SIZE = 1 << N_BIT_ADDR;
	private long[][] bitsets;
	private int[][] bsRanges;
	private int[] wordRanking;
	private int[] ranking;
	private int maxRank;
	private long[] incrementalBitset;
	private int incBsFstWord, incBsLstWord;

	public void freeMem() {
		incrementalBitset = null;
		bitsets = null;
		bsRanges = null;
		wordRanking = null;
		ranking = null;
	}

	public int[] getRanking() {
		return ranking;
	}

	public boolean updateSolutionDominance(int solutionId) {
		int fw = bsRanges[solutionId][FIRST_WORD_RANGE];
		int lw = bsRanges[solutionId][LAST_WORD_RANGE];
		if (lw > incBsLstWord)
			lw = incBsLstWord;
		if (fw < incBsFstWord)
			fw = incBsFstWord;

		while (fw <= lw && 0 == (bitsets[solutionId][fw] & incrementalBitset[fw]))
			fw++;
		while (fw <= lw && 0 == (bitsets[solutionId][lw] & incrementalBitset[lw]))
			lw--;
		bsRanges[solutionId][FIRST_WORD_RANGE] = fw;
		bsRanges[solutionId][LAST_WORD_RANGE] = lw;
		if (fw > lw)
			return false;
		for (; fw <= lw; fw++)
			bitsets[solutionId][fw] &= incrementalBitset[fw];
		return true;
	}

	public void computeSolutionRanking(int solutionId) {
		int fw = bsRanges[solutionId][FIRST_WORD_RANGE];
		int lw = bsRanges[solutionId][LAST_WORD_RANGE];
		if (lw > incBsLstWord)
			lw = incBsLstWord;
		if (fw < incBsFstWord)
			fw = incBsFstWord;
		if (fw > lw)
			return;
		long word;
		int i = 0, rank = 0, offset;
		for (; fw <= lw; fw++) {
			word = bitsets[solutionId][fw] & incrementalBitset[fw];
			if (word != 0) {
				i = Long.numberOfTrailingZeros(word);
				offset = fw * WORD_SIZE;
				do {
					if (ranking[offset + i] >= rank)
						rank = ranking[offset + i] + 1;
					i++;
					i += Long.numberOfTrailingZeros(word >> i);
				} while (i < WORD_SIZE && rank <= wordRanking[fw]);
				if (rank > maxRank) {
					maxRank = rank;
					break;
				}
			}
		}
		ranking[solutionId] = rank;
		i = solutionId >> N_BIT_ADDR;
		if (rank > wordRanking[i])
			wordRanking[i] = rank;
	}

	public void updateIncrementalBitset(int solutionId) {
		int wordIndex = solutionId >> N_BIT_ADDR;
		incrementalBitset[wordIndex] |= (1L << solutionId);
		if (incBsLstWord < wordIndex)
			incBsLstWord = wordIndex;
		if (incBsFstWord > wordIndex)
			incBsFstWord = wordIndex;
	}

	public void initializeSolutionBitset(int solutionId) {
		int lw = incBsLstWord;
		bsRanges[solutionId][FIRST_WORD_RANGE] = incBsFstWord;
		bsRanges[solutionId][LAST_WORD_RANGE] = lw;
		lw++;
		bitsets[solutionId] = new long[lw];
		System.arraycopy(incrementalBitset, 0, bitsets[solutionId], 0, lw);
	}

	public void clearIncrementalBitset() {
		incrementalBitset = new long[incrementalBitset.length];
		incBsLstWord = 0;
		incBsFstWord = Integer.MAX_VALUE;
	}

	public MNDSBitsetManager(int nSolutions) {
		int n = nSolutions - 1;
		int wordIndex = n >> N_BIT_ADDR;
		ranking = new int[nSolutions];
		wordRanking = new int[nSolutions];
		bitsets = new long[nSolutions][];
		bsRanges = new int[nSolutions][2];
		incrementalBitset = new long[wordIndex + 1];
		incBsLstWord = 0;
		incBsFstWord = Integer.MAX_VALUE;
	}
}
