package main.java.mnds.algorithms;

import java.util.ArrayList;

import main.java.mnds.util_mnds.MNDSBitsetManager;

public class MNDS {
	private static final int INSERTIONSORT = 7;
	private int m; // Number of Objectives
	private long comparisonCounter = 0;
	private long nonDomEarlyDetection = 0;
	private int n; // Population Size
	private int initialPopulationSize;
	private int[] ranking;
	private double[][] population; //Population to be sorted: Last objective must be the solution ID
	private double[][] work; // Work array
	private ArrayList<int[]> duplicatedSolutions;
	private MNDSBitsetManager bsManager;

	final public void freeMem() {
		population = null;
		work = null;
		duplicatedSolutions = null;
		ranking = null;
		bsManager.freeMem();
	}

	public MNDS(int populationSize, int nObjectives) {
		initialPopulationSize = populationSize;
		n = populationSize;
		m = nObjectives;
		bsManager = new MNDSBitsetManager(n);
		work = new double[n][m + 1];
		nonDomEarlyDetection = 0;
	}

	final public long getNumberOfEarlyDetections() {
		return nonDomEarlyDetection;
	}

	final public long getComparisonCounter() {
		return comparisonCounter;
	}

	final public int getNumberOfDuplicatedSolutions() {
		return duplicatedSolutions.size();
	}

	final private int compare_lex(double[] s1, double[] s2, int fromObj, int toObj) {
		for (; fromObj < toObj; fromObj++) {
			comparisonCounter++;
			if (s1[fromObj] < s2[fromObj])
				return -1;
			comparisonCounter++;
			if (s1[fromObj] > s2[fromObj])
				return 1;
		}
		return 0;
	}

	private boolean merge_sort(double src[][], double dest[][], int low, int high, int obj, int toObj) {
		int i, j, s;
		double temp[] = null;
		int destLow = low;
		int length = high - low;

		if (length < INSERTIONSORT) {
			for (i = low; i < high; i++) {
				for (j = i; j > low && compare_lex(dest[j - 1], dest[j], obj, toObj) > 0; j--) {
					temp = dest[j];
					dest[j] = dest[j - 1];
					dest[j - 1] = temp;
				}
			}
			return temp == null; //if temp==null, src is already sorted
		}
		int mid = (low + high) >>> 1;
		boolean isSorted = merge_sort(dest, src, low, mid, obj, toObj);
		isSorted &= merge_sort(dest, src, mid, high, obj, toObj);

		// If list is already sorted, just copy from src to dest.
		comparisonCounter++;
		if (src[mid - 1][obj] <= src[mid][obj]) {
			System.arraycopy(src, low, dest, destLow, length);
			return isSorted;
		}

		for (s = low, i = low, j = mid; s < high; s++) {
			if (j >= high) {
				dest[s] = src[i++];
			} else if (i < mid && compare_lex(src[i], src[j], obj, toObj) <= 0) {
				dest[s] = src[i++];
			} else {
				dest[s] = src[j++];
			}
		}
		return false;
	}

	private boolean sortFirstObjective() {
		int solutionId, p = 0;
		System.arraycopy(population, 0, work, 0, n);
		merge_sort(population, work, 0, n, 0, m);
		population[0] = work[0];
		solutionId = ((int) population[0][m]);
		bsManager.initializeSolutionBitset(solutionId);
		bsManager.updateIncrementalBitset(solutionId);
		for (int q = 1; q < n; q++) {
			if (0 != compare_lex(population[p], work[q], 0, m)) {
				population[++p] = work[q];
				solutionId = ((int) population[p][m]);
				bsManager.initializeSolutionBitset(solutionId);
				bsManager.updateIncrementalBitset(solutionId);
			} else
				duplicatedSolutions.add(new int[] { (int) population[p][m], (int) work[q][m] });
		}
		n = p + 1;
		return n > 1;
	}

	private void sortRestOfObjectives() {
		int p, solutionId, lastObjective = m - 1;
		boolean dominance;
		System.arraycopy(population, 0, work, 0, n);
		for (int obj = 1; obj < m; obj++) {
			if (merge_sort(population, work, 0, n, obj, obj + 1)) {//Population has the same order as in previous objective				
				if (obj == lastObjective) {
					for (p = 0; p < n; p++)
						bsManager.computeSolutionRanking((int) population[p][m]);
				}
				continue;
			}
			System.arraycopy(work, 0, population, 0, n);
			bsManager.clearIncrementalBitset();
			dominance = false;
			for (p = 0; p < n; p++) {
				solutionId = ((int) population[p][m]);
				if (obj < lastObjective)
					dominance |= bsManager.updateSolutionDominance(solutionId);
				else
					bsManager.computeSolutionRanking(solutionId);
				bsManager.updateIncrementalBitset(solutionId);
			}
			if (!dominance) {
				nonDomEarlyDetection++;
				return;
			}
		}
	}

	// main
	final public int[] sort(double[][] populationData) {
		//INITIALIZATION
		comparisonCounter = 0;
		population = populationData;
		duplicatedSolutions = new ArrayList<int[]>(n);
		//SORTING
		if (sortFirstObjective()) {
			sortRestOfObjectives();
		}
		ranking = bsManager.getRanking();
		// UPDATING DUPLICATED SOLUTIONS
		for (int[] duplicated : duplicatedSolutions)
			ranking[duplicated[1]] = ranking[duplicated[0]]; //ranking[dup solution]=ranking[original solution]

		n = initialPopulationSize; //equivalent to n += duplicatedSolutions.size();
		return ranking;
	}
}
