package main.java.mnds.algorithms;

import java.util.Arrays;

import main.java.mnds.util_ens.DominanceHelper;
import main.java.mnds.util_ens.DoubleArraySorter;

/**
 * This class implements the ENS-BS algorithm.
 * Original implementation by:
 * M. Buzdalov
 * https://github.com/mbuzdalov/non-dominated-sorting/
 * The code has been modified the minimum necessary to include it in this
 * project.
 * 
 */

public class ENS_BS {
	protected int[] indices = null;
	protected int[] ranks = null;
	protected int[] prevIndex = null;
	protected int[] lastRankIndex = null;
	protected DoubleArraySorter sorter = null;
	protected long _comparisons;
	protected int lastRanking, n, m;

	public ENS_BS(int maximumPoints, int maximumDimension) {
		n = maximumPoints;
		m = maximumDimension;
		sorter = new DoubleArraySorter(maximumPoints);
		indices = new int[maximumPoints];
		prevIndex = new int[maximumPoints];
		ranks = new int[maximumPoints];
		lastRankIndex = new int[maximumPoints];
		_comparisons = 0;
		lastRanking = 0;
	}

	final boolean frontDominates(int frontIndex, double[][] points, double[] point) {
		int index = lastRankIndex[frontIndex];
		while (index >= 0) {
			if (DominanceHelper.strictlyDominates(points[index], point, m)) {
				_comparisons += DominanceHelper.comparisonCounter;
				return true;
			}
			_comparisons += DominanceHelper.comparisonCounter;
			index = prevIndex[index];
		}
		return false;
	}

	final public long getComparisonCounter() {
		return _comparisons;
	}

	final public void close() {
		sorter = null;
		indices = null;
		prevIndex = null;
		lastRankIndex = null;
		ranks = null;
	}

	void sortCheckedImpl(double[][] points, int[] ranks) { //, int maximalMeaningfulRank) {
		int n = ranks.length;
		int maxRank = -1, index, currRank;
		int leftRank, rightRank;
		double point[];
		for (int i = 0; i < n; ++i) {
			index = indices[i];
			//currRank = findRank(points, index, maxRank);
			point = points[index];
			leftRank = -1;
			rightRank = maxRank + 1;

			while (rightRank - leftRank > 1) {
				currRank = (leftRank + rightRank) >>> 1;
				if (frontDominates(currRank, points, point)) {
					leftRank = currRank;
				} else {
					rightRank = currRank;
				}
			}
			//maxRank = setRank(index, ranks, rank, maxRank);
			if (rightRank > maxRank) {
				maxRank = rightRank;
				lastRankIndex[maxRank] = -1;
			}
			prevIndex[index] = lastRankIndex[rightRank];
			lastRankIndex[rightRank] = index;
			ranks[index] = rightRank;
		}
	}

	public int[] sort(double[][] points) {
		int n = ranks.length;
		for (int i = 0; i < n; i++)
			indices[i] = i;
		Arrays.fill(ranks, -1);
		Arrays.fill(prevIndex, -1);
		sorter.lexicographicalSort(points, indices, 0, n, points[0].length);
		sortCheckedImpl(points, ranks);

		return ranks;
	}

}
