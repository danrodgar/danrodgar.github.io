Introduction
------------
This project contains the implementation, in java, of the Merge Non-Dominated Sort algorithm, as well as four other algorithms with which it is compared.
Licensed under the Apache License, version 2.0.
http://www.apache.org/licenses/LICENSE-2.0.txt


Structure of the project
------------------------
/config: Contains the configuration file that defines the tests to be performed
/data: Contains the data files used in the paper
/results: Folder where the csv files of results are stored
/src/main/java/mnds/algorithms: Contains the MNDS, BOS, ENS-SS, ENS-BS, ENS-NDT, HNDS and DDA-NS algorithms
/src/main/java/mnds/performance: Contains the classes to perform the tests
/src/main/java/mnds/util_ens: Contains auxiliary classes of the ENS-SS, ENS-BS and ENS-NDT algorithms
/src/main/java/mnds/util_mnds: Contains auxiliary classes for MNDS
/src/main/java/mnds/tools: Contains auxiliary classes for read / write files


Test execution
--------------
Please, first of all, enter the configuration in the file /config/algorithmTests.config.
From the console execute: java -jar test.jar
Note: Is necessary to have Java 8 installed.
