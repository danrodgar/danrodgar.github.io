/*
 * Population.java
 *
 * Created on 04 August 2005, 12:10
 *
 */

package clustersGA;

import java.util.*;

//delete after check that it works: 
import java.io.*;
import weka.core.*;


/**
 * 
 * Empezaremos con un solo punto para tener 2 modelos.
 * Luego hay que extenderlo a mas puntos.
 * @author drg
 */
public class Population {
     
    /** Population size */
    private int _populationSize;
    private int _numGenes;
    
    /** collection of Chromosomes (Individuals) */
    ArrayList<Chromosome> _chromosomes;
       
    /** Creates a new instance of Population */
    public Population(int numGenes) {
        _numGenes = numGenes;
        _chromosomes = new ArrayList<Chromosome>();
    }
    
    public void generateInitialPopulation() {
        for (int i=0; i< _populationSize; i++) {        
            _chromosomes.add(new Chromosome(_numGenes));
        }
    }
    
    public String toString() {
        StringBuffer temp = new StringBuffer();
        temp.append("Population:\n");
        for (int i=0;i < _populationSize;i++) {
            temp.append(_chromosomes.get(i).toString());
        }     
        return temp.toString();
    }
  
 /**
   * Evaluates an entire population. Population members are evaluated using
   * FitnessFunction.
   * @param FitnessFuction for evaluating population members
   * @exception Exception if something goes wrong during evaluation
   */
  public void evaluatePopulation (FitnessFunction f)
    throws Exception {
      for (int i=0; i< _populationSize; i++) { 
          double d = f.evaluate(_chromosomes.get(i));
          _chromosomes.get(i).setFitnessValue(d);
      }

  }
  
    void sortPopulation (){
        Collections.sort(_chromosomes);     
    }
    
  /**
   * creates random population members for the initial population. Also
   * sets the first population member to be a start set (if any) 
   * provided by the user
   * @exception Exception if the population can't be created
   *   
   *  private void initPopulation () throws Exception {
   *      //_populationSize = 20;
   *      //_chromosomes = new ArrayList<Chromosome>();
   *      generateInitialPopulation();
   *      //System.out.println(this.toString());
   *  }
   */

  public int getPopulationSize () {
      return this._populationSize;
  }
  
  public void setPopulationSize (int numChromosomes) {
      this._populationSize = numChromosomes;
  }
  
  public Chromosome getChromosome (int i) {
      return _chromosomes.get(i);
  }
  
  public void addChromosome (Chromosome c) {
      _chromosomes.add(c); 
  }
  
  public Chromosome crossover (int c1, int c2) {
      Chromosome ch1 = _chromosomes.get(c1);
      ArrayList<Integer> g1 = ch1.getChromosome();
      Chromosome ch2 = _chromosomes.get(c2);
      ArrayList<Integer> g2 = ch2.getChromosome();
      ArrayList<Integer> g = new ArrayList<Integer>();
     
      for (int i=0; i<_numGenes; i++) {
        g.add((g1.get(i) + g2.get(i))/2);
        //int gene1 = ch1.get(c1);
        //int gene2 = _chromosomes.get(c2).getChromosome();
      }
      
      Chromosome ch = new Chromosome(_numGenes);
      ch.setChromosome(g);
      ch.setFitnessValue(Double.MAX_VALUE);
      return ch;
  }
  
  public void replaceChromosome (int pos, Chromosome ch) {
      _chromosomes.set(pos, ch);
  }
   
  public static void main(String[] args) {
      try{
          //For testing purposes only.
          FileReader reader=null;
          Population p = new Population (4);
          p.setPopulationSize(3);
          p.generateInitialPopulation();
          
          reader = new FileReader("C:\\Projects\\GAClusters\\data\\Reality.arff");
          Instances inst = new Instances(reader); 
          FitnessFunction f = new FitnessFunction (inst, 6, 5);
          
          System.out.println(p.toString());
          p.evaluatePopulation(f);
          p.sortPopulation();
          System.out.println(p.toString());
          
      }catch (Exception e){System.out.println(e); System.exit(-3);}
  }

}
