/*
 * Chromosome.java
 */

package clustersGA;

import java.util.*;
import java.lang.Math;

/**
 * Chromosome is an array of integers with the
 * cut points, where each cut point defines a estimation model, 
 * a regression model.
 * @author dani
 */
public class Chromosome implements Comparable<Chromosome> {
     
    
    /** 
     * Chromosome - initially will be only 1 integers so we can have 2
     * linear regression but in the future has to be modified to have more
     * than 2
     */
    //private int _chromosome;
    
    int _numGenes;
    
    /*
     * inv: Elements of chromosome are sorted g_0<g_1<...<g_numGenes */
    private ArrayList<Integer> _chromosome;
    
    /*
     * _maxValue of the integer chromosomes
     * it should be passed. TO DO
     */
    private int _maxValue = 2500; //2500 Funct Points
    
    /** Fitness Value is a real number */
    private double _fitnessValue;
    
    /** Creates a new instance of Chromosome 
    public Chromosome() {
        _numGenes = 1;
        _chromosome = new ArrayList<Integer> ();
        initChromosome();
        _fitnessValue = Double.MAX_VALUE;
    } */
    
    public Chromosome (int numGen) {
        _numGenes = numGen;
        _chromosome = new ArrayList<Integer> ();
        initChromosome();
        _fitnessValue = Double.MAX_VALUE;
    }
    
    public void setNumGenes (int ng) {
        _numGenes = ng;
    }
    
    public int getNumGenes () {
        return _numGenes;
    }
    
    private void initChromosome () {
        // Generate _numGenes number of random values and sort them
        //_chromosome = (int) (_maxValue * java.lang.Math.random());        
        for (int i=0; i<_numGenes; i++) {
            Double d = _maxValue * java.lang.Math.random();
            d.intValue();
            _chromosome.add(d.intValue());
        }
        Collections.sort(_chromosome);
    }
    
    /**
    public Chromosome(int value) {
        _chromosome = value;
    } */
    
    /**
    public Chromosome(int value, double fitVal) {
        _chromosome = value;
        _fitnessValue = fitVal;
    } */
    
    public ArrayList<Integer> getChromosome () {
        return _chromosome;
    }
    
    public void setChromosome (ArrayList<Integer> ch) {
        _chromosome = ch;
    }
    
    public double getFitnessValue () {
        return _fitnessValue;
    }
    
    public void setFitnessValue (double value) {
        _fitnessValue = value;
    }

    public void mutate () {
        //Just a maximun of 10% either side
        for (int i=0; i<_numGenes; i++) {
            double d = _chromosome.get(i);
            if (java.lang.Math.random() < 0.5){
                d = d * (1 - 0.30 * java.lang.Math.random());
            } else {
                d = d * (1 + 0.30 * java.lang.Math.random());      
            }
            _chromosome.set(i, (int) d);
        }
    }
    
    public int compareTo (Chromosome chrom) {
        Double chromFitnessVal = chrom.getFitnessValue();
        int ret = ((Double)_fitnessValue).compareTo(chromFitnessVal);
        return ret;       
    }
    
    public String toString(){
        return ("Chromosome:" + _chromosome.toString() 
                + " Fitness:" + _fitnessValue + "\n");
    }
    
    public static void main(String[] args) {
        //Just for testing purposes only       
        Chromosome ch = new Chromosome(3);
        System.out.println("Chr: " + ch.toString());
        ch.mutate();
        System.out.println("Mut: " + ch.toString());
    }
}
