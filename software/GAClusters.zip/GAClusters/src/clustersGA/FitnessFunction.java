/*
 * FitnessFunction.java
 *
 * Created on 04 August 2005, 12:53
 */

package clustersGA;

import weka.classifiers.functions.LinearRegression;
import weka.classifiers.Evaluation;
import weka.core.*;

import java.util.*;
import java.io.*;

/**
 * generar algo de weka or regression from Flannagan.
 *
 * Sobre correlation coefficients:
 * Are correlation coefficients "additive?" 
 * No, they are not. For example, an average of correlation coefficients in a
 * number of samples does not represent an "average correlation" in all those
 * samples. Because the value of the correlation coefficient is not a linear 
 * function of the magnitude of the relation between the variables, correlation
 * coefficients cannot simply be averaged. In cases when you need to average
 * correlations, they first have to be converted into additive measures. 
 * For example, before averaging, you can square them to obtain coefficients 
 * of determination which are additive (as explained before in this section), 
 * or convert them into so-called Fisher z values, which are also additive. 
 *
 * @author drg
 */
public class FitnessFunction {
    
    
    /** Instances from the arff file */
    private Instances _instances;
    
    private int _instancesClassIndex; 
    private int _evalAttr;
    
    ArrayList<Instances> arrayInst; // = new ArrayList<Instances>();
    
    
    /** Creates a new instance of FitnessFunction 
    public FitnessFunction() {
    } */
    
    /** Creates a new instance of FitnessFunction 
    public FitnessFunction(Instances instances) {
        _instances = instances;
    } */
    
    /** Creates a new instance of FitnessFunction */
    public FitnessFunction(Instances instances, int classIndex, int evalAttr) {
        _instances = instances;
        _instancesClassIndex = classIndex;
        _evalAttr = evalAttr;
        _instances.setClassIndex(_instancesClassIndex);
    }
    
    public void setClassIndex (int c) {
        _instancesClassIndex = c;
    }
    
    public int getClassIndex () {
        return _instancesClassIndex;
    }
    
    public void setEvalIndex (int evalIndex) {
        _evalAttr = evalIndex;
    }
    
    public int getEvalIndex () {
        return _evalAttr;
    }
    
    /**
     * This should be divided and better organized
     */
    
    double evaluate (Chromosome chromosome) {
        double fitnessValue = Double.MAX_VALUE;
        //System.out.println(chromosome.toString());
        
        //Change AS IT IS ASSIGNED TWICE
        //_instances.setClassIndex(_instancesClassIndex);
        int numGenes = chromosome.getNumGenes();
        
        //ArrayList<Instances> 
        arrayInst= new ArrayList<Instances>();
        for (int i=0; i<= numGenes; i++) {
            arrayInst.add(new Instances(_instances, _instances.numInstances()));
        }
                      
        //Populate sub-sets
        _instances.sort(_instances.classIndex()); //or _instancesClassIndex
        //System.out.println("no. of inst: " + _instances.numInstances());
        int interval = 0; int cutPoint; double valFP;
        for (int i=0; i < _instances.numInstances(); i++){
            valFP = _instances.instance(i).value(_instances.classIndex());
            if (interval < numGenes) { 
                cutPoint = chromosome.getChromosome().get(interval);
            } else {
                cutPoint = Integer.MAX_VALUE;
            }
            //System.out.println(i + " fp: "+ valFP + 
            //       ". cutpoint: " + cutPoint +
            //       ". interval: " + interval);
            
            if (valFP > cutPoint && interval < numGenes) {
                    interval++;
                    //System.out.println("Inteval increased: " + interval);
                
            } 
            arrayInst.get(interval).add(_instances.instance(i));
            //_instances.add(_instances.instance(i));
        }
        
        
        for (int i=0; i<= numGenes; i++) {
            arrayInst.get(i).setClassIndex(_evalAttr);
            //System.out.println("\nNum of Instaces: "
            //        + arrayInst.get(i).numInstances() + "\nInstances: \n"
            //        + arrayInst.get(i));
        }

        //Generate linear regression models
        ArrayList<LinearRegression> arrayReg= new ArrayList<LinearRegression>();
        for (int i=0; i<= numGenes; i++) {
            arrayReg.add(new  LinearRegression());
        }
        
        try {
            for (int i=0; i<= numGenes; i++) {
                arrayReg.get(i).buildClassifier(arrayInst.get(i));
            }
            
            //for (int i=0; i<= numGenes; i++) {
            //    System.out.println(arrayReg.get(i).toString());
            //}
            
            
            fitnessValue = 0;
            ArrayList<Evaluation> arrayEval = new ArrayList<Evaluation>();
            for (int i=0; i<= numGenes; i++) {
                // Model is created using all instances in that subset
                arrayEval.add(new Evaluation(arrayInst.get(i)));
                // and the evaluation is perfomed using the same dataset
                arrayEval.get(i).evaluateModel(arrayReg.get(i), arrayInst.get(i));
                //System.out.println("Error LR " + i + ":" + arrayEval.get(i).toSummaryString());
                //System.out.println(arrayEval.get(i).toSummaryString());
                fitnessValue = fitnessValue + arrayEval.get(i).relativeAbsoluteError();
                //System.out.println("fitnessValue: " + fitnessValue);
            }
            
            fitnessValue = fitnessValue/(numGenes+1);
            //System.out.println("fitnessValue FINAL : " + fitnessValue);
            /* fitnessValue = 0;
            for (int i=0; i<= numGenes; i++) {
                fitnessValue = 
                    fitnessValue + arrayEval.get(i).relativeAbsoluteError();
            }
            fitnessValue = fitnessValue/(numGenes+1);
            */
            
        } catch(Exception e){System.out.println("Error while creating LR:"+e);}
        
        return fitnessValue;    
    }
    
    
    
    public static void main(String[] args) {
        //For testing pourposes only.
        Instances inst = null;
        Chromosome chrom = new Chromosome(1);
        System.out.println(chrom);
        FileReader reader=null;
        try{
            reader = new FileReader("C:\\Projects\\GAClusters\\data\\Reality.arff");
            //reader = new FileReader("C:\\Projects\\GAClusters\\data\\NormWE.arff");
            inst = new Instances(reader);
            inst.setClassIndex(0);
	}catch (Exception e){System.out.println(e); System.exit(-3);}
        
        FitnessFunction ff = new FitnessFunction (inst, 6, 5);
        //FitnessFunction ff = new FitnessFunction (inst, 0, 13);
        double val = ff.evaluate(chrom);
        chrom.setFitnessValue(val);
        System.out.println(chrom.toString());
        
    }
}
