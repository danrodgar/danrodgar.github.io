
package  clustersGA;

import  java.io.*;
import  java.util.*;
import  weka.core.*;

//For evaluation with MMRE and Pred25
import weka.classifiers.functions.LinearRegression;
//import java.lang.Math;

/*
 */
public class ClustersGAEstimation {

  /** the current population */
//  private Population  _population;
  Instances _instances;
  int _instancesClassIndex;
  int _evalIndex;
  int _cutPoints;
    
  /** the number of individual solutions - PopulationSize */
  private int _popSize;

  private Population _population;
  /** the best population member found during the search */
  //private Population _best; Aqui Chomosome, population ya es un array

  /** the probability of crossover occuring */
  private double _pCrossover;

  /** the probability of mutation occuring */
  private double _pMutation;
  
  /** 
   * No. of Parents that are copied in the next generation
   * 0 if no elitism is used
   * inv: 0<= _numEliteParents < _populationSize 
   */
  private int _numEliteParents; 

  /** sum of the current population fitness */
  //private double _sumFitness;
  //private double _maxFitness;
  //private double _minFitness;
  //private double _avgFitness;

  /** the maximum number of generations to evaluate */
  private int _maxGenerations;

  /** how often reports are generated */
  //private int _reportFrequency;

  /** holds the generation reports */
  //private StringBuffer _generationReports;


  /**
   * set the probability of mutation
   * @param m the probability for mutation occuring
   */
  public void setMutationProb(double m) {
    _pMutation = m;
  }

  /**
   * get the probability of mutation
   * @return the probability of mutation occuring
   */
  public double getMutationProb() {
    return _pMutation;
  }


  /**
   * set the probability of crossover
   * @param c the probability that two population members will exchange
   * genetic material
   */
  public void setCrossoverProb(double c) {
    _pCrossover = c;
  }

  /**
   * get the probability of crossover
   * @return the probability of crossover
   */
  public double getCrossoverProb() {
    return _pCrossover;
  }


  /**
   * set the number of generations to evaluate
   * @param m the number of generations
   */
  public void setMaxGenerations(int m) {
    _maxGenerations = m;
  }

  /**
   * get the number of generations
   * @return the maximum number of generations
   */
  public int getMaxGenerations() {
    return _maxGenerations;
  }


  /**
   * set the population size
   * @param p the size of the population
   */
  public void setPopulationSize(int p) {
    _popSize = p;
  }

  /**
   * get the size of the population
   * @return the population size
   */
  public int getPopulationSize() {
    return _popSize;
  }


  /**
   * Constructor. Make a new GeneticSearch object
   */
  public ClustersGAEstimation () {
    resetOptions();
  }

  /**
   * Constructor. Make a new GeneticSearch object
   */
  public ClustersGAEstimation (String arffFile, int instClassIndex, int evalIndex, int cutPoints) 
    throws Exception {
      _instancesClassIndex = instClassIndex;
      _evalIndex = evalIndex;
      _cutPoints = cutPoints;
      FileReader reader=null;
        try{
            reader = new FileReader(arffFile);
            _instances = new Instances(reader); 
	}catch (Exception e){System.out.println(e); System.exit(-3);}
      resetOptions();
      
      //set the class attribute  _instances.numAttributes()
      _instances.setClassIndex(_instancesClassIndex); 
      //_instances.sort(_instancesClassIndex);    

       GAMain(_instances);
  }

  /**
   * returns a description of the search
   * @return a description of the search as a String
   
  public String toString() {
    StringBuffer GAString = new StringBuffer();
    GAString.append("\n\tStart set: ");

    //if (_?? == null) {GAString.append("empty.\n")} else   
    GAString.append("\tPopulation size: "+_popSize);
    GAString.append("\n\tNumber of generations: "+_maxGenerations);
    GAString.append("\n\tProbability of crossover: "
		+Utils.doubleToString(_pCrossover,6,3));
    GAString.append("\n\tProbability of mutation: "
		+Utils.doubleToString(_pMutation,6,3));
    //GAString.append("\n\tReport frequency: "+_reportFrequency);
    //GAString.append(_generationReports.toString());
    return GAString.toString();
  }
  */
  
  
  /**
   * Main class
   */
  public void GAMain (Instances data) //{ //data IS NOT USED
       throws Exception {
      
    // set up random initial population
    _population = new Population( _cutPoints);
    _population.setPopulationSize(_popSize);
    _population.generateInitialPopulation();
 
    FitnessFunction fitnessFunction = 
            new FitnessFunction(_instances, _instancesClassIndex, _evalIndex);
    _population.evaluatePopulation(fitnessFunction);
    _population.sortPopulation();
    
    //checkBest();
    //_generationReports.append(populationReport(0));

    //boolean converged; 
    int i=0;
    while (i<=_maxGenerations) {//|| !converged) {
      //System.out.println("Generation: " + i);
      //System.out.println(_population); 
      generation(); //performs a single generation---selection, crossover, and mutation
      _population.evaluatePopulation(fitnessFunction);
      _population.sortPopulation();
      // Check for convergence
      //converged = checkBest();
      /*if ((i == _maxGenerations) || 
	  ((i % _reportFrequency) == 0) ||
	  (converged == true)) {
	_generationReports.append(populationReport(i));
	if (converged == true) {
	  break;
	}*/
     
      //System.out.println("Generation: " + (i));
      //System.out.println(_population);
      i++;
    }
    System.out.println("Final Generation: " + (i-1));
    System.out.println(_population.getChromosome(0).toString());
    
    //Evaluate using MMRE and PRED
    
    
    evaluateMMREandPred (_population.getChromosome(0));
    //First using the same dataset as testing
    
    
    
  }



  /**
   * performs a single generation---selection, crossover, and mutation
   * @exception Exception if an error occurs
   */
  private void generation () throws Exception {
      
    Population newPopulation = new Population(_cutPoints);
    newPopulation.setPopulationSize(_population.getPopulationSize());
   
    /* First ensure that the population best
     * is propogated into the new generation */
    for (int i=0; i<=_numEliteParents-1; i++) {
        newPopulation.addChromosome(_population.getChromosome(i));
    }
    
    for (int i=_numEliteParents; i<_popSize ;i++){
      if (java.lang.Math.random()<_pCrossover) {
          // crossover
          Chromosome c = _population.crossover(i, (int)((_popSize * java.lang.Math.random()-1)));
          // mutate
          if (java.lang.Math.random()<_pMutation) {
              c.mutate();
          }
          newPopulation.addChromosome(c);
          //_population.replaceChromosome(_popSize-1, c);
      } else {
          newPopulation.addChromosome(_population.getChromosome(i));          
      }
    }  
    _population = newPopulation;
  }

 

  /**
   * generates a report on the current population
   * @return a report as a String
   */
  private String populationReport (int genNum) {
    int i;
    StringBuffer temp = new StringBuffer();

    if (genNum == 0) {
      temp.append("\nInitial population\n");
    }
    else {
      temp.append("\nGeneration: "+genNum+"\n");
    }
    for (i=0;i<_popSize;i++) {
      ///...
    }
    return temp.toString();
  }


  /**
   * reset to default values for options
   */
  private void resetOptions () {
    _population = null;
    _popSize = 20;
    _pCrossover = 0.6;
    _pMutation = 0.10; //0.033;
    _maxGenerations = 50;
    _numEliteParents = 1;
    //_reportFrequency = _maxGenerations;
  }
  
/**********************************************************************
 *
 */
  
    void evaluateMMREandPred (Chromosome chromosome) {
        double fitnessValue = Double.MAX_VALUE;
        System.out.println("Evaluate with MMRE and Pred 25");
        System.out.println(chromosome.toString());
        
        //System.out.println("Instances Ori:" + _instances.toString());
       
        int numGenes = chromosome.getNumGenes();
        //System.out.println("Num of genes: " + numGenes);
        //System.out.println("Class index: " + _instancesClassIndex + " o " + _instances.classIndex());
        //System.out.println("Eval Index: " + _evalIndex);
        
        //Inicializar array of instances
        ArrayList<Instances>  arrayInst= new ArrayList<Instances>();
        for (int i=0; i<= numGenes; i++) {
            arrayInst.add(new Instances(_instances, _instances.numInstances()));
        }
                      
        //Populate sub-sets
        _instances.sort(_instances.classIndex()); //or _instancesClassIndex
        //System.out.println("no. of inst: " + _instances.numInstances());
        //System.out.println("Instances after sorting:" + _instances.toString());
        
        int interval = 0; int cutPoint; double valFP;
        for (int i=0; i < _instances.numInstances(); i++){
            valFP = _instances.instance(i).value(_instances.classIndex()); //ins
            if (interval < numGenes) { 
                cutPoint = chromosome.getChromosome().get(interval);
            } else {
                cutPoint = Integer.MAX_VALUE;
            }
            //System.out.println(i + " fp: "+ valFP + 
            //        ". cutpoint: " + cutPoint +
            //        ". interval: " + interval);
            if (valFP > cutPoint && interval < numGenes) {
                    interval++;
                    //System.out.println("Inteval increased: " + interval);
                
            } 
            arrayInst.get(interval).add(_instances.instance(i));
            //_instances.add(_instances.instance(i));
        }
        
        //Generate linear regression models
        for (int i=0; i<= numGenes; i++) {
            arrayInst.get(i).setClassIndex(_evalIndex);
            //System.out.println("Instaces: \n" 
            //        + arrayInst.get(i).numInstances()
            //        + arrayInst.get(i));
        }
        ArrayList<LinearRegression> arrayReg= new ArrayList<LinearRegression>();
        for (int i=0; i<= numGenes; i++) {
            arrayReg.add(new  LinearRegression());
        }
        try {
            for (int i=0; i<= numGenes; i++) {
                arrayReg.get(i).buildClassifier(arrayInst.get(i));
                System.out.println(arrayReg.get(i).toString());
            }
            //for (int i=0; i<= numGenes; i++) {
            //    System.out.println(arrayReg.get(i).toString());
            //}         
            double actual, predicted, diff, pred25, mmre;
            int numInst;
            double[] arrPred;
            double[] arrMMRE;
            for (int i=0; i<= numGenes; i++) {
                System.out.println("Set: " + i);
                pred25 = 0; mmre = 0;
                numInst = arrayInst.get(i).numInstances();
                arrPred = new double[numInst];
                arrMMRE = new double[numInst];
                for (int j=0; j<numInst; j++) {
                    Instance instance = arrayInst.get(i).instance(j);
                    //System.out.println("Instance: " + instance.toString());
                    System.out.print("FP: " + instance.value(_instancesClassIndex));
                    actual = instance.value(_evalIndex);
                    System.out.print(", Actual: " + actual);
                    predicted = arrayReg.get(i).classifyInstance(instance);
                    System.out.print(", Predicted: " + predicted);
                    diff = Math.abs(predicted-actual);
                    System.out.print(", Diff: " + diff);
                    arrMMRE[j] = diff/actual;
                    if ((predicted >= (0.75 * actual) && (predicted <= (1.25 * actual)))){
                        arrPred[j] = 1; System.out.print(", Pred(25): " + 1);
                    }
                    else {
                        arrPred[j] = 0; System.out.print(", Pred(25): " + 0);                  
                    }
                    System.out.println(", MMRE: " + diff/actual);
                }   
                for (int a=0; a < numInst; a++) {
                        mmre = mmre + arrMMRE[a];
                        pred25 = pred25 + arrPred[a];
                }
                System.out.println("MMRE: " + mmre/numInst);
                System.out.println("Pred25: " + pred25/numInst);
    
                System.out.println("========================================");                
            }
        } catch(Exception e){System.out.println("Error while creating LR:"+e);}           
    }
  
  
  
  /**********************************************************************
 * end
 */
  
  
  
  
  public static void main(String[] args) {
    //Just for testing pourposes
    try {
        for (int i=1; i<=10; i++) {
            for (int j=1; j<=3; j++) {
                System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                System.out.println("CutPoints: " + i +  ". Run no.: " + j);
                ClustersGAEstimation cGA =  
                        new ClustersGAEstimation 
                        ("C:\\Projects\\GAClusters\\data\\NormWE.arff", 0, 13, i);
            }
        }
        
        //ClustersGAEstimation cGA =  
        /* Usage: ClustersGAEstimation (file.arff, 
         *                              classIndex (eg FP), 
         *                              evalIndex (eg Effort)
         *                              numOfCutPoints)
         */                              
        //new ClustersGAEstimation ("C:\\Projects\\GAClusters\\data\\Reality.arff", 5, 4, 2);
        
        new ClustersGAEstimation ("C:\\Projects\\GAClusters\\data\\NormWE.arff", 0, 13, 2);
    } catch(Exception e) {System.out.println("Error GA. "+e);}
  }
 
}


