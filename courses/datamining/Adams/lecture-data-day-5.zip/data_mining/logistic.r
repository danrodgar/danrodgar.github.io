#based on R script of Nicolas Bettenburg, SAIL (Queen's University), nicbet AT cs DOT queensu DOT ca

library("moments")
library("xtable")
library("reshape")
library("ggplot2")
library("BiodiversityR")
library("car")

# Load data
d1 <- read.csv('ant-1.7-pop.r')

# Descriptive Statistics
means <- lapply(d1[,-c(1,2,3,4,11)], FUN=mean)
sds <- lapply(d1[,-c(1,2,3,4,11)], FUN=sd)
mins <- lapply(d1[,-c(1,2,3,4,11)], FUN=min)
maxs <- lapply(d1[,-c(1,2,3,4,11)], FUN=max)
skews <- lapply(d1[,-c(1,2,3,4,11)], FUN=skewness)

descriptive <- cbind(Mean=means, SD=sds, Min=mins, Max=maxs, Skew=skews)


# Transformation logic
p=function(v,power){
  if(power==0){
    return(log(v+1))
  }else{
    if(power==1){
      return(v)
    }else{
      return((v+1)**power) #avoid infinity for zero
    }
  }
}

symmetry=function(v){
  quartiles=as.vector(summary(v))
  HU=quartiles[5]
  MED=quartiles[3]
  HL=quartiles[2]

  cat("(",HU,MED,HL,"): ",sep=" ")
  return((HU-MED)/(MED-HL))
}

plotform=function(v,i){
    pdf(file=paste("pow",i,".pdf",sep=""));
    hist(p(v,i),main=paste("p=",i,sep=""));
    dev.off()
}

plotforms=function(v){
  for(i in c(4,3,2,1,1/2,1/3,1/4,0,-1/4,-1/3,-1/2,-1)){
    plotform(v,i);
    cat(i,": ",symmetry(p(v,i)),"\n",sep="")
  }
}

compare=function(v){
  for(i in 1:ncol(v)){
    cat("=====\n",names(v)[i],"\n",sep="")
    plotforms(v[,i])
  }
}

plotforms(d1[,7])
compare(d1[,-c(1,2,3,4,11,12)])


# Intercorrelation tables
cor.pvalues <- function(X){
    nc <- ncol(X) 
    res <- matrix(0, nc, nc) 
    for (i in 2:nc){
        for (j in 1:(i - 1)){
            res[i, j] <- res[j, i] <- cor.test(X[,i], X[,j])$p.value
            }
        }
    res 
}

c <- cor(d1[,-c(1,2,3,4,11)])
p <- cor.pvalues(d1[,-c(1,2,3,4,11)])

stars <- as.character(symnum(p, cutpoints=c(0,0.001,0.01,0.05,1),   
                      symbols=c('***', '**', '*', '' ),  
                      legend=F))

molten.d1 <- cbind(melt(c), stars)
names(molten.d1) <- c("M1", "M2", "corr", "pvalue")
x <- ggplot(molten.d1, aes(M1, M2, fill=corr))

mi.ids <- subset(molten.d1, M1 == M2)
mi.lower <- subset(molten.d1[lower.tri(c),], M1 != M2)
mi.upper <- subset(molten.d1[upper.tri(c),], M1 != M2)


# now plot just these values, adding labels (geom_text) for the names and the values
(p1 <- x +  geom_tile(data=mi.lower) + 
     geom_text(data=mi.lower, aes(label=paste(pvalue))) 
)
meas <- as.character(unique(molten.d1$M2))
pdf(file="correlations.pdf", height=10, width=18)
(p2 <- p1 + scale_colour_identity() + 
     scale_fill_gradientn(colours= c("red", "white", "blue"), limits=c(1,-1)) +
     scale_x_discrete(limits=meas[length(meas):1]) + #flip the x axis 
     scale_y_discrete(limits=meas) 
)

dev.off()

xtable(cor(d1[,-c(1,2,3,4,11)]))


# Models

#NoM has high VIF
model <- glm(Bugs>0 ~ Type + log(Getters+1) + log(Setters+1) + log(NoM+1) + log(InDegrees+1) + log(OutDegrees+1) + log(ClusteringCoefficient+1) + log(LOC + 1), data=d1, family=binomial())

summary(model)
vif(model)

#without NoM
model <- glm(Bugs>0 ~ Type + log(Getters+1) + log(Setters+1) + log(InDegrees+1) + log(OutDegrees+1) + log(ClusteringCoefficient+1), data=d1, family=binomial())

summary(model)
vif(model)


# Stepwise Hierarchical Modeling

# 1. Build Baseline Model
baseline <- glm ( (Bugs>0) ~ Type, data=d1, family=binomial() )
summary(baseline)
deviancepercentage(baseline, data=d1[,-c(1,2,3,4,11)])
exp(coef(baseline)) #odds ratios of coefficients
exp(confint(baseline)) #CI of odds ratios of coefficients

#possible dispersion, so check for that
qbaseline <- glm ( (Bugs>0) ~ Type, data=d1, family=quasibinomial() )
pchisq(summary(qbaseline)$dispersion * baseline$df.residual, baseline$df.residual, lower = F)
#no dispersion problem, it seems, so ignore

#residuals vs. predicted values
plot(predict(baseline, type="response"), residuals(baseline, type= "deviance"))

#States above lines on the vertical axis are outliers, states above lines on the horizontal axis have high leverage (unusual combinations of predictor values). Circle size is proportional to influence (disproportionate influence on the parameters estimates of the model).
influencePlot(baseline)


# 2. Add getters/setters
model1 <- glm ( (Bugs>0) ~ Type + log(Getters + 1) + log(Setters + 1), data=d1, family=binomial() )
summary(model1)
deviancepercentage(model1, data=d1[,-c(1,2,3,4,11)])
exp(coef(model1)) #odds ratios of coefficients
exp(confint(model1)) #CI of odds ratios of coefficients

# Compare Model 1 to Baseline
anova(baseline,model1, test="Chisq")
AIC(baseline,model1)

plot(predict(model1, type="response"), residuals(model1, type= "deviance"))
influencePlot(model1,id.method="identify")


# 3. Add degrees
model2 <- glm ( (Bugs>0) ~ Type + log(Getters + 1) + log(Setters + 1) + log(InDegrees + 1) + log(OutDegrees + 1), data=d1, family=binomial() )
summary(model2)
deviancepercentage(model2, data=d1[,-c(1,2,3,4,11)])
exp(coef(model2)) #odds ratios of coefficients
exp(confint(model2)) #CI of odds ratios of coefficients

# Compare Model 2 to Model 1
anova(model1,model2, test="Chisq")
AIC(model1,model2)

plot(predict(model2, type="response"), residuals(model2, type= "deviance"))
influencePlot(model2,id.method="identify")


# 4. Add clustering information
model3 <- glm ( (Bugs>0) ~ Type + log(Getters + 1) + log(Setters + 1) + log(InDegrees + 1) + log(OutDegrees + 1) + log(ClusteringCoefficient + 1), data=d1, family=binomial() )
summary(model3)
deviancepercentage(model3, data=d1[,-c(1,2,3,4,11)])
exp(coef(model3)) #odds ratios of coefficients
exp(confint(model3)) #CI of odds ratios of coefficients

# Compare Model 3 to Model 2
anova(model2,model3, test="Chisq")
AIC(model2,model3)

plot(predict(model3, type="response"), residuals(model3, type= "deviance"))
influencePlot(model3,id.method="identify")


# 5. Final model
final <- glm ( (Bugs>0) ~ log(Setters + 1) + log(OutDegrees + 1), data=d1, family=binomial() )
summary(final)
deviancepercentage(final, data=d1[,-c(1,2,3,4,11)])
exp(coef(final)) #odds ratios of coefficients
exp(confint(final)) #CI of odds ratios of coefficients

# Compare Model 3 to Model 2
AIC(baseline,final)

plot(predict(final, type="response"), residuals(final, type= "deviance"))
influencePlot(final,id.method="identify")


# 6. Remove too influential data points
finalp <- glm ( (Bugs>0) ~ log(Setters + 1) + log(OutDegrees + 1), data=d1[-c(66,79,157,329),], family=binomial() )
summary(finalp)
deviancepercentage(finalp, data=d1[-c(66,79,157,329),-c(1,2,3,4,11)])
exp(coef(finalp)) #odds ratios of coefficients
exp(confint(finalp)) #CI of odds ratios of coefficients

anova(final,finalp, test="Chisq")
AIC(final,finalp)

plot(predict(finalp, type="response"), residuals(finalp, type= "deviance"))
influencePlot(finalp,id.method="identify")
